# Talend → PySpark Logic Mapping — CustomerOrders

_Agent 3 · Logic Mapping & Traceability (deterministic, no LLM)_

## 1. Conversion summary

| Metric | Value |
| --- | --- |
| Total business rules | 14 |
| Converted to PySpark | 14 |
| Require manual review | 0 |
| Fully convertible | Yes |
| Operations | 6 |

## 2. Traceability matrix

Each row maps one Talend construct to the PySpark construct that implements it. Rows flagged **Manual review** could not be fully converted automatically.

| BR | Component | Category | Talend logic | PySpark logic | Intent | Status |
| --- | --- | --- | --- | --- | --- | --- |
| BR-01 | customers_lookup | input | `tFileInputDelimited read "customers.csv"` | `spark.read.schema(...).csv(path)` | Read delimited source into 'customers_lookup' (3 columns). | Converted |
| BR-02 | orders_in | input | `tFileInputDelimited read "orders.csv"` | `spark.read.schema(...).csv(path)` | Read delimited source into 'orders_in' (4 columns). | Converted |
| BR-03 | tMap_1 | transform | `tMap col order_id = row1.order_id` | `F.col("order_id").alias("order_id")` | Direct column pass-through. | Converted |
| BR-04 | tMap_1 | transform | `tMap col customer_id = row1.customer_id` | `F.col("customer_id").alias("customer_id")` | Direct column pass-through. | Converted |
| BR-05 | tMap_1 | transform | `tMap col customer_name = StringHandling.TRIM(row2.name)` | `F.trim(F.col("name")).alias("customer_name")` | Trim whitespace. | Converted |
| BR-06 | tMap_1 | transform | `tMap col country = StringHandling.UPCASE(row2.country)` | `F.upper(F.col("country")).alias("country")` | Upper-case. | Converted |
| BR-07 | tMap_1 | transform | `tMap col amount = Math.round(row1.amount * 100.0) / 100.0` | `F.round(F.col("amount"), 2).alias("amount")` | Round to 2 decimals. | Converted |
| BR-08 | tMap_1 | transform | `tMap lookup join row2 on customer_id=customer_id` | `df.join(df_customers_lookup, ..., "inner")` | inner join with lookup row2. | Converted |
| BR-09 | tMap_1 | transform | `tMap filter row1.amount > 0` | `df.filter((F.col("amount") > F.lit(0)))` | Output row filter. | Converted |
| BR-10 | tAggregateRow_1 | aggregate | `tAggregateRow group by ['country']` | `df.groupBy(['country']).agg(...)` | Group by [country] and aggregate 2 measure(s). | Converted |
| BR-11 | tAggregateRow_1 | aggregate | `agg sum(amount) -> total_amount` | `F.sum(F.col("amount")).alias("total_amount")` | sum aggregation. | Converted |
| BR-12 | tAggregateRow_1 | aggregate | `agg count(order_id) -> order_count` | `F.count(F.col("order_id")).alias("order_count")` | count aggregation. | Converted |
| BR-13 | tSortRow_1 | sort | `tSortRow [{'col': 'total_amount', 'order': 'desc'}]` | `df.orderBy(...)` | Order rows by total_amount desc | Converted |
| BR-14 | summary_out | output | `tFileOutputDelimited write "country_summary.csv"` | `write_single_csv(df, output_path)` | Write pipeline result to "country_summary.csv". | Converted |

## 3. Items requiring manual review

None — every Talend construct was converted to PySpark.

## 4. Business-logic analysis

| Category | Operations |
| --- | --- |
| input | 2 |
| transform | 1 |
| aggregate | 1 |
| sort | 1 |
| output | 1 |
