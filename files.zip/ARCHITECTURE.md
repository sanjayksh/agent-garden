# Technical Architecture — Deterministic Talend → PySpark Multi-Agent Converter

**Application:** `talend2pyspark`
**Version:** 1.0.0
**Key property:** **No LLM and no network calls at runtime.** Every parsing and
conversion rule is hand-authored Python built into the package.

---

## 1. Purpose

`talend2pyspark` is a **multi-agent orchestrator** that converts an exported
Talend data-processing job into a runnable **PySpark** pipeline and produces the
supporting analysis and traceability artifacts. It understands the logic found
in most Talend pipelines: **filtering, aggregation & grouping, cleansing &
data-quality, and joining & lookup**, plus reads, writes, sorting,
de-duplication and file moves.

The work is performed by **four agents chained by hand-off** (each agent calls
the next):

| # | Agent | Reads | Writes (to its own folder) |
|---|-------|-------|----------------------------|
| 1 | **Parser / Logic Extractor** | the Talend job export folder | **JSON** business-logic analysis |
| 2 | **Code Generator** | the analysis JSON | a runnable **PySpark** `.py` pipeline |
| 3 | **Logic Mapper** | analysis + generated code | a **Markdown** mapping table (proof of conversion; lists anything not convertible) |
| 4 | **Validator** | the generated pipeline | a **Markdown** validation report (executes the pipeline on a temp copy) |

> The brief names three agents explicitly (Parser → Generator → Mapper) but asks
> for four. The fourth is a **Validator** that runs the generated PySpark and
> verifies it reproduces the Talend behaviour. It is a one-line change in the
> orchestrator to remove or replace.

---

## 2. Why there is no runtime LLM

The conversion capability is implemented as a **deterministic engine** authored
into the package (the `talend/` sub-package). The same engine is exercised by
the unit tests and runs identically on any machine, offline, with no API keys.
When a Talend construct falls outside the supported vocabulary, the engine does
**not** guess — it emits a clearly-marked `TODO[manual]` placeholder and the
Mapper lists the item in the "manual review" section of the mapping table, which
is exactly the required behaviour for anything the application cannot convert.

---

## 3. High-level component diagram

```
                       ┌─────────────────────────────────────────────┐
                       │            CLI / VS Code / run.py            │
                       └───────────────────────┬─────────────────────┘
                                               │ load_config()
                                               ▼
                       ┌─────────────────────────────────────────────┐
                       │                 Orchestrator                │
                       │   prepare workspace · build chain · run()   │
                       └───────────────────────┬─────────────────────┘
       hand-off chain (Agent N calls Agent N+1)│ starts Agent 1
   ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
   │  Agent 1  │───▶│  Agent 2  │───▶│  Agent 3  │───▶│  Agent 4  │
   │  Parser   │    │ Generator │    │  Mapper   │    │ Validator │
   └─────┬─────┘    └─────┬─────┘    └─────┬─────┘    └─────┬─────┘
         ▼                ▼                ▼                ▼
   01_parsed_logic   02_pyspark_code  03_mapping       04_validation
   <job>_analysis    generated_       <job>_logic_     <job>_validation
   .json             pipeline.py      mapping.md       _report.md
         │                │                │                │
         └────────────────┴───────┬────────┴────────────────┘
                                   ▼
              ┌──────────────────────────────────────────────┐
              │      Deterministic engine  (talend/)         │
              │  expressions · model · components ·          │
              │  parser · codegen · mapping     (NO LLM)     │
              └──────────────────────────────────────────────┘
```

---

## 4. Package structure

```
talend-pyspark-converter/
├── pyproject.toml                  # packaging + console script (talend2pyspark)
├── requirements.txt                # PyYAML (core); pyspark optional
├── run.py                          # zero-install entry point
├── config/settings.yaml            # folders + IO + run behaviour
│
├── src/talend2pyspark/
│   ├── cli.py · __main__.py        # command line
│   ├── config.py · context.py      # configuration + shared run context
│   ├── orchestrator.py             # builds + runs the 4-agent chain
│   │
│   ├── agents/                     # thin agents over the engine (hand-off chain)
│   │   ├── base.py                 # BaseAgent.set_next / run / execute
│   │   ├── parser_agent.py         # Agent 1  -> JSON analysis
│   │   ├── generator_agent.py      # Agent 2  -> PySpark code
│   │   ├── mapper_agent.py         # Agent 3  -> Markdown mapping
│   │   └── validator_agent.py      # Agent 4  -> Markdown validation (+ live run)
│   │
│   ├── talend/                     # THE DETERMINISTIC ENGINE (no LLM)
│   │   ├── expressions.py          # Talend/Java expression -> PySpark Column
│   │   ├── model.py                # XML helpers, category map, TABLE parser
│   │   ├── components.py           # per-component analyze_* + generate_*
│   │   ├── parser.py               # export -> ordered plan -> analysis JSON
│   │   ├── codegen.py              # analysis -> runnable PySpark module
│   │   └── mapping.py              # analysis -> mapping rows + Markdown
│   │
│   ├── docgen/markdown.py          # tiny Markdown table/code helpers
│   └── utils/                      # logging + filesystem helpers
│
├── sample_jobs/
│   ├── MoveCsvFile/                # REQUIRED sample (move CSV input->output)
│   │   ├── process/MoveCsvFile_0.1.item
│   │   ├── process/MoveCsvFile_0.1.properties
│   │   └── talend.project
│   └── CustomerOrders/             # richer demo: join+filter+aggregate+cleanse
│       └── process/CustomerOrders_0.1.{item,properties}
│
├── data/
│   ├── input/customers.csv             # data for MoveCsvFile
│   ├── customer_orders/{orders,customers}.csv   # data for CustomerOrders
│   └── output/
│
├── workspace/                      # agent outputs (created at run time)
│   ├── 01_parsed_logic/  02_pyspark_code/
│   ├── 03_mapping/       04_validation/
│
├── .vscode/                        # launch.json · tasks.json · settings.json
├── tests/                          # pytest: translator, parser, e2e, generated runs
└── docs/                           # ARCHITECTURE.md · DEPLOYMENT.md
```

---

## 5. The deterministic engine (`talend/`)

### 5.1 `expressions.py` — the translation vocabulary
Translates individual Talend/Java expressions and conditions into PySpark
`Column` source. Supported today: column references (`row1.col → F.col("col")`),
string literals/numbers/booleans/null, `StringHandling.TRIM/UPCASE/DOWNCASE/
LEN/LEFT/CHANGE`, `Math.round/abs/ceil/floor`, `TalendDate.getCurrentDate`,
`Relational.ISNULL`, casts (`Integer.parseInt`, `Double.parseDouble`),
arithmetic, string concatenation, ternaries (`?:` → `F.when().otherwise()`),
comparisons and `&&`/`||`/`!`. Unknown constructs return `supported=False` with
a `TODO` placeholder so they can be flagged rather than mis-converted.

### 5.2 `model.py` — Talend XML primitives
Namespace-agnostic element access, the **component → category** map, schema
reading, and the generic **Talend TABLE-parameter parser** that rebuilds
flattened `<elementValue elementRef=… />` rows (used by tFilterRow,
tAggregateRow, tSortRow, tReplace, tConvertType).

### 5.3 `components.py` — per-component knowledge
For each supported component an `analyze_*` function (translates the logic once
and stores both Talend source and PySpark result) and a `generate_*` function
(emits PySpark from those stored translations). Co-locating them guarantees the
generated code and the mapping table never disagree. Supported components:

| Category | Components |
|---|---|
| input / output | `tFileInputDelimited`, `tFileInputCSV`, `tFileOutputDelimited`, `tFileOutputCSV` |
| move | `tFileDelete` |
| transform / cleanse | `tMap`, `tFilterColumns`, `tReplace`, `tConvertType` |
| filter | `tFilterRow`, tMap output filters |
| aggregate & group | `tAggregateRow` |
| join & lookup | `tMap` lookups, `tJoin` |
| sort / dedup / log | `tSortRow`, `tUniqRow`, `tLogRow` |
| anything else | flagged for manual review |

### 5.4 `parser.py` — Agent-1 engine
Finds the `.item`/`.properties` (recursively, so the Talend `process/` export
layout works), reads context variables, components and connections, builds a
**topologically-ordered plan** (main flow before lookups), runs the analyzers,
assigns `OP-xx`/`BR-xx` ids, and emits the **analysis JSON** including a
`business_logic_analysis` summary and an `unsupported` list.

### 5.5 `codegen.py` — Agent-2 engine
Walks the ordered operations and assembles one self-contained PySpark module
(`build_spark`, `write_single_csv` for Talend single-file semantics,
`finalize_move`, an explicit `StructType` per input, a `run()` body, and a
`main()` CLI).

### 5.6 `mapping.py` — Agent-3 engine
Produces the **Markdown** mapping: a conversion summary, the full traceability
matrix (BR → component → Talend logic → PySpark logic → status), an explicit
**"items requiring manual review"** section, and the business-logic category
counts.

---

## 6. Agent model

`BaseAgent` implements the hand-off chain: `set_next()` links Agent N→N+1, and
`run()` executes the agent then calls the next. The orchestrator links
`a1→a2→a3→a4` and starts `a1`. State flows through a single `RunContext`
(`analysis`, `analysis_json_path`, `pyspark_code(_path)`, `mapping_rows(_path)`,
`validation_result(_path)`).

---

## 7. Data flow (one run)

1. `load_config()` resolves the job folder, the four workspace sub-folders and
   the generated-pipeline IO folders.
2. Orchestrator prepares the workspace and builds the chain.
3. **Agent 1** parses the export → `01_parsed_logic/<job>_analysis.json`.
4. **Agent 2** generates PySpark → `02_pyspark_code/generated_pipeline.py`.
5. **Agent 3** writes the mapping → `03_mapping/<job>_logic_mapping.md`.
6. **Agent 4** copies the sample input to a temp folder, runs the generated
   pipeline, reconciles row counts and per-rule checks → `04_validation/<job>_
   validation_report.md`. The canonical sample data is never modified.

---

## 8. Extensibility

Add a Talend component: implement `analyze_<x>` and `generate_<x>` in
`components.py`, register them in the `ANALYZERS`/`GENERATORS` dicts and add the
category in `model.COMPONENT_CATEGORY`. Add an expression: extend
`expressions.py`. No other layer changes. Anything still unrecognised degrades
gracefully and is listed in the mapping for manual review.
