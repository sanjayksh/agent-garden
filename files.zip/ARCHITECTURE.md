# Technical Architecture — Talend → PySpark Multi-Agent Orchestrator

**Application:** `talend2pyspark`
**Version:** 1.0.0
**Audience:** application architects, data engineers, platform engineers

---

## 1. Purpose

`talend2pyspark` is a **multi-agent orchestrator** that converts a Talend
Standard Job (a data-processing pipeline exported as `.properties` + `.item`
files) into a runnable **PySpark** pipeline, and produces the supporting
migration documentation automatically.

The conversion is performed by **four chained Copilot agents**:

| # | Agent | Input | Output |
|---|-------|-------|--------|
| 1 | **Parser / Logic Extractor** | Talend `.properties` + `.item` | `logic.json` + a **business-logic Word document** |
| 2 | **PySpark Code Generator** | `logic.json` | a runnable **PySpark `.py` pipeline** |
| 3 | **Logic Mapper / Traceability** | logic + generated code | a **Talend→PySpark mapping Word document** (proof table) |
| 4 | **Validator / Test** | generated code | executes it and writes a **validation-report Word document** |

Each agent does its work and then **hands off to the next agent** — the first
agent literally calls the second, the second calls the third, and so on. An
**orchestrator** builds the chain, selects the AI backend, prepares the
workspace, and starts Agent 1.

---

## 2. High-level component diagram

```
                          ┌──────────────────────────────────────────────┐
                          │                  CLI / VS Code                │
                          │     run.py · python -m talend2pyspark · ext   │
                          └───────────────────────┬──────────────────────┘
                                                  │ load_config()
                                                  ▼
                          ┌──────────────────────────────────────────────┐
                          │                 Orchestrator                  │
                          │  build_provider()  prepare_workspace()        │
                          │  build_chain()     run()                      │
                          └───────────────────────┬──────────────────────┘
        handoff chain                             │ starts Agent 1
        (Agent N calls Agent N+1)                 ▼
   ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
   │  Agent 1  │───▶│  Agent 2  │───▶│  Agent 3  │───▶│  Agent 4  │
   │  Parser   │    │ Generator │    │  Mapper   │    │ Validator │
   └─────┬─────┘    └─────┬─────┘    └─────┬─────┘    └─────┬─────┘
         │                │                │                │
         ▼                ▼                ▼                ▼
   logic.json +     generated_       mapping.docx     validation.docx
   logic.docx       pipeline.py                       (+ live run)
         │                │                │                │
         └────────────────┴───────┬────────┴────────────────┘
                                   ▼
                  ┌────────────────────────────────────────┐
                  │            LLM provider layer           │
                  │  offline · github_copilot · openai      │
                  └────────────────────────────────────────┘
                                   │
        ┌──────────────────────────┼───────────────────────────┐
        ▼                          ▼                            ▼
  deterministic            GitHub Models /               any OpenAI-compatible
  converter (no            Copilot inference             endpoint (OpenAI,
  credentials)             API (PAT, models:read)        Azure, Ollama, …)
```

Cross-cutting building blocks the agents reuse:

- **`talend/`** — Talend XML parsing, expression translation, code generation,
  and mapping (the deterministic "engine").
- **`docgen/`** — Word-document rendering (python-docx).
- **`prompts/`** — the actual prompt templates submitted to Copilot.
- **`config.py` / `context.py` / `utils/`** — configuration, the shared run
  context threaded through all agents, and small helpers.

---

## 3. Package structure

```
talend-to-pyspark-orchestrator/
├── pyproject.toml                 # packaging + console script (talend2pyspark)
├── requirements.txt               # core runtime deps
├── run.py                         # zero-install entry point
├── config/
│   └── settings.yaml              # folders, IO, provider, behaviour
├── .env.example                   # backend credentials / model selection
│
├── src/talend2pyspark/            # the application package
│   ├── __init__.py
│   ├── __main__.py                # `python -m talend2pyspark`
│   ├── cli.py                     # argparse CLI + run summary
│   ├── config.py                  # settings.yaml + .env + CLI overrides
│   ├── context.py                 # RunContext (shared state between agents)
│   ├── orchestrator.py            # builds provider + chain, runs Agent 1
│   │
│   ├── agents/                    # the four Copilot agents
│   │   ├── base.py                # BaseAgent: handoff chaining + parsing helpers
│   │   ├── parser_agent.py        # Agent 1
│   │   ├── generator_agent.py     # Agent 2
│   │   ├── mapper_agent.py        # Agent 3
│   │   └── validator_agent.py     # Agent 4
│   │
│   ├── prompts/                   # the prompts submitted to the LLM/Copilot
│   │   ├── parser_prompt.py
│   │   ├── generator_prompt.py
│   │   ├── mapper_prompt.py
│   │   └── validator_prompt.py
│   │
│   ├── llm/                       # pluggable AI backend
│   │   ├── base.py                # LLMProvider interface + Message
│   │   ├── offline.py             # deterministic, no credentials (default)
│   │   ├── github_copilot.py      # GitHub Models / Copilot inference API
│   │   ├── openai_compatible.py   # generic OpenAI-compatible endpoint
│   │   └── __init__.py            # build_provider() factory
│   │
│   ├── talend/                    # deterministic Talend engine
│   │   ├── parser.py              # .item/.properties -> logic spec (dict)
│   │   ├── translate.py           # Talend expr -> PySpark column expr
│   │   ├── codegen.py             # logic spec -> runnable PySpark source
│   │   ├── mapping.py             # logic spec -> traceability rows
│   │   └── narrative.py           # templated prose (offline narratives)
│   │
│   ├── docgen/                    # Word-document builders (python-docx)
│   │   ├── style.py               # shared styling (headings, tables, code)
│   │   ├── logic_doc.py           # Agent 1 document
│   │   ├── mapping_doc.py         # Agent 3 document
│   │   └── validation_doc.py      # Agent 4 document
│   │
│   └── utils/                     # logging + filesystem helpers
│
├── sample_talend_job/MoveCsvFile/ # SAMPLE Talend job (test input)
│   ├── MoveCsvFile_0.1.properties
│   └── MoveCsvFile_0.1.item
│
├── data/
│   ├── input/customers.csv        # sample data the generated pipeline reads
│   └── output/                    # the generated pipeline writes here
│
├── workspace/                     # agent artifacts (created at run time)
│   ├── 01_extracted_logic/        # Agent 1: logic.json + business-logic.docx
│   ├── 02_pyspark_code/           # Agent 2: generated_pipeline.py
│   ├── 03_mapping/                # Agent 3: logic_mapping.docx
│   └── 04_validation/             # Agent 4: validation_report.docx
│
├── vscode-extension/              # OPTIONAL VS Code Copilot companion
│   ├── package.json · tsconfig.json · README.md
│   └── src/extension.ts           # uses native vscode.lm Copilot API
│
├── .vscode/                       # launch.json · tasks.json · settings.json
├── tests/                         # pytest: parser, e2e offline, generated run
└── docs/                          # ARCHITECTURE.md · DEPLOYMENT.md
```

---

## 4. The agent model

### 4.1 Chaining (handoff)

`BaseAgent` implements the hand-off pattern:

```python
class BaseAgent:
    def set_next(self, agent):      # link Agent N -> Agent N+1
        self.next = agent
    def run(self, ctx):
        self.execute(ctx)           # do my work
        if self.next:               # then call the next agent
            self.next.run(ctx)
```

The orchestrator builds the chain and starts only Agent 1:

```python
a1.set_next(a2); a2.set_next(a3); a3.set_next(a4)
a1.run(ctx)     # Agent 1 -> 2 -> 3 -> 4
```

This satisfies the requirement that *"the first agent calls the next agent"*
while keeping construction in one place. Adding a fifth agent is a one-line
change in `build_chain()`.

### 4.2 Shared state — `RunContext`

A single `RunContext` instance is threaded through every agent. Each agent reads
the previous agent's output from it and writes its own:

```
logic_spec, logic_json_path, logic_doc_path     <- Agent 1
pyspark_code, pyspark_code_path                 <- Agent 2
mapping_rows, mapping_doc_path                  <- Agent 3
validation_result, validation_doc_path          <- Agent 4
```

### 4.3 Prompt-driven, backend-agnostic

Every agent builds a **real prompt** (system + user) from `prompts/` and calls
`self.ask(...)` → `LLMProvider.complete(...)`. The agent code is **identical**
regardless of backend:

- With **github_copilot** / **openai**, the prompt text drives a real model and
  the agent parses the model's reply (code fence for Agent 2, JSON for Agent 3).
- With **offline**, the same call is routed by a structured `task`/`payload`
  to a deterministic builder that returns output in the **same shape** the
  prompt requests, so parsing is shared.

Each agent also has a **deterministic safety net**: if a live model returns
invalid Python (Agent 2) or unparseable JSON (Agent 3), the agent falls back to
the built-in converter so a run never produces a broken artifact.

---

## 5. The deterministic Talend engine (`talend/`)

Correctness-critical work is **not** left to a probabilistic model:

- **`parser.py`** reads the Talend XML namespace-agnostically and emits a
  structured *logic spec* (context vars, source schema, ordered business rules
  `BR-01…BR-NN`, filters, target, post-actions, connections).
- **`translate.py`** maps individual Talend constructs to PySpark columns:
  `StringHandling.TRIM → F.trim`, `StringHandling.UPCASE → F.upper`,
  `Math.round(x*100)/100 → F.round(col, 2)`,
  `TalendDate.getCurrentDate() → F.current_date()`, comparisons/filters, type
  mapping `id_Integer → IntegerType`, etc. Unrecognised expressions become a
  `TODO` placeholder so nothing is silently dropped.
- **`codegen.py`** assembles a self-contained PySpark module
  (`build_spark / read_source / transform / write_single_csv / finalize_move /
  run / main`) with explicit schema, single-file output (mirroring Talend), and
  move semantics. Every line carries its `BR-xx` id for traceability.
- **`mapping.py`** derives the traceability rows used in the proof table.

This engine is what makes the package **runnable and testable with zero
credentials**, and it doubles as the offline backend and the fallback path.

---

## 6. AI backend abstraction (`llm/`)

```
LLMProvider (ABC)
 ├─ OfflineProvider           deterministic; no network, no keys  (DEFAULT)
 ├─ GitHubCopilotProvider     POST https://models.github.ai/inference/chat/completions
 │                            Authorization: Bearer <PAT models:read>
 │                            X-GitHub-Api-Version: 2026-03-10
 └─ OpenAICompatibleProvider  POST {base_url}/chat/completions  (OpenAI/Azure/Ollama)
```

`build_provider(cfg.llm)` selects the implementation from
`T2P_LLM_PROVIDER` / `settings.yaml` / `--provider`. Switching backends requires
**no code change** in the agents.

---

## 7. VS Code integration

Two layers, both optional but supported:

1. **Workspace config** (`.vscode/`) — `launch.json` (debug the orchestrator and
   the generated pipeline), `tasks.json` (one-click convert / test / run),
   `settings.json` (sets `PYTHONPATH=src`, pytest).
2. **Companion extension** (`vscode-extension/`) — registers commands and uses
   the **native Copilot language-model API** (`vscode.lm.selectChatModels(
   {vendor:'copilot'})` + `model.sendRequest(...)`) to explain a Talend job
   in-editor, plus commands that launch the Python orchestrator and run the
   generated pipeline.

The Python CLI is the primary, fully-tested path; the extension is a thin
convenience/Copilot-demonstration layer on top of it.

---

## 8. Data & control flow (one run)

1. `load_config()` resolves folders, IO and the LLM backend.
2. Orchestrator builds the provider and the 4-agent chain; cleans/creates the
   workspace sub-folders.
3. **Agent 1** parses the job → `logic.json`; asks the backend for a narrative →
   `..._business_logic.docx`; hands off.
4. **Agent 2** asks the backend to generate PySpark → validates it is parseable
   → `generated_pipeline.py`; hands off.
5. **Agent 3** asks the backend for the mapping (JSON) → renders the proof table
   → `..._logic_mapping.docx`; hands off.
6. **Agent 4** runs the generated pipeline against a **temporary copy** of the
   sample input (so the canonical data is preserved), reconciles row counts and
   per-rule checks, → `..._validation_report.docx`.
7. CLI prints a summary of every artifact path and the validation verdict.

---

## 9. Design principles & extension points

- **Separation of concerns** — agents orchestrate; the `talend/` engine does the
  deterministic heavy lifting; `docgen/` only renders; `llm/` only talks to
  models.
- **Backend-agnostic agents** — one interface, three backends, easy to add more.
- **Deterministic correctness with optional AI uplift** — never depends on a
  model being available or correct to produce a valid artifact.
- **Traceability first** — `BR-xx` ids flow from parser → code comments →
  mapping table → validation checks.

**To extend:** add a Talend component in `parser.py` + a rule in `translate.py`;
add a backend in `llm/` + a branch in `build_provider`; add an agent class and
one `set_next` line; add a document type in `docgen/`.
