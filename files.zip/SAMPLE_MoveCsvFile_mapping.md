# Talend → PySpark Logic Mapping — MoveCsvFile

_Agent 3 · Logic Mapping & Traceability (deterministic, no LLM)_

## 1. Conversion summary

| Metric | Value |
| --- | --- |
| Total business rules | 10 |
| Converted to PySpark | 10 |
| Require manual review | 0 |
| Fully convertible | Yes |
| Operations | 4 |

## 2. Traceability matrix

Each row maps one Talend construct to the PySpark construct that implements it. Rows flagged **Manual review** could not be fully converted automatically.

| BR | Component | Category | Talend logic | PySpark logic | Intent | Status |
| --- | --- | --- | --- | --- | --- | --- |
| BR-01 | tFileInputDelimited_1 | input | `tFileInputDelimited read context.INPUT_FOLDER + "/" + context.FILE_NAME` | `spark.read.schema(...).csv(path)` | Read delimited source into 'tFileInputDelimited_1' (5 columns). | Converted |
| BR-02 | tMap_1 | transform | `tMap col customer_id = row1.customer_id` | `F.col("customer_id").alias("customer_id")` | Direct column pass-through. | Converted |
| BR-03 | tMap_1 | transform | `tMap col name = StringHandling.TRIM(row1.name)` | `F.trim(F.col("name")).alias("name")` | Trim whitespace. | Converted |
| BR-04 | tMap_1 | transform | `tMap col country = StringHandling.UPCASE(row1.country)` | `F.upper(F.col("country")).alias("country")` | Upper-case. | Converted |
| BR-05 | tMap_1 | transform | `tMap col signup_date = row1.signup_date` | `F.col("signup_date").alias("signup_date")` | Direct column pass-through. | Converted |
| BR-06 | tMap_1 | transform | `tMap col balance = Math.round(row1.balance * 100.0) / 100.0` | `F.round(F.col("balance"), 2).alias("balance")` | Round to 2 decimals. | Converted |
| BR-07 | tMap_1 | transform | `tMap col load_date = TalendDate.getCurrentDate()` | `F.current_date().alias("load_date")` | Current date. | Converted |
| BR-08 | tMap_1 | transform | `tMap filter row1.balance >= 0` | `df.filter((F.col("balance") >= F.lit(0)))` | Output row filter. | Converted |
| BR-09 | tFileOutputDelimited_1 | output | `tFileOutputDelimited write context.OUTPUT_FOLDER + "/" + context.FILE_NAME` | `write_single_csv(df, output_path)` | Write pipeline result to context.OUTPUT_FOLDER + "/" + context.FILE_NAME. | Converted |
| BR-10 | tFileDelete_1 | move | `tFileDelete delete context.INPUT_FOLDER + "/" + context.FILE_NAME` | `os.remove(source) if delete_source` | Delete the source file after write (move semantics). | Converted |

## 3. Items requiring manual review

None — every Talend construct was converted to PySpark.

## 4. Business-logic analysis

| Category | Operations |
| --- | --- |
| input | 1 |
| transform | 1 |
| output | 1 |
| move | 1 |
