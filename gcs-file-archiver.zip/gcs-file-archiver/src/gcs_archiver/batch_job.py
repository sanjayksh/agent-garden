"""
Batch orchestrator.

Workflow (per the functional specification):
 1. Read the configuration file (Module A).
 2. Insert ARCHIVAL_JOB_LOG row with JOB_STATUS='STARTED' (Module C).
 3. Recursively walk the source directory; upload each file to GCS.
 4. After every upload, insert an ARCHIVAL_FILE_LOG row (Module D).
 5. When all files are processed, update ARCHIVAL_JOB_LOG with
    JOB_STATUS='COMPLETE', counters and JOB_END_TS.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterator, List

from gcs_archiver.config.app_config import AppConfig
from gcs_archiver.db.connection import Db2ConnectionManager
from gcs_archiver.db.file_log_repository import FileLogRecord, FileLogRepository
from gcs_archiver.db.job_log_repository import JobLogRepository
from gcs_archiver.gcs.uploader import GcsUploader, UploadResult
from gcs_archiver.utils.exceptions import (
    ArchiverError,
    Db2Error,
    SourceDirectoryError,
)

logger = logging.getLogger(__name__)


class ArchivalBatchJob:
    """End-to-end batch: scan -> upload -> log."""

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._cm = Db2ConnectionManager(config)
        self._job_repo = JobLogRepository(self._cm, config.db2_schema)
        self._file_repo = FileLogRepository(self._cm, config.db2_schema)
        self._uploader = GcsUploader(config)

    # ------------------------------------------------------------------ #
    def _select_files(self) -> List[Path]:
        root = Path(self._config.source_directory)
        if not root.is_dir():
            raise SourceDirectoryError(
                f"Source directory does not exist or is not readable: {root}"
            )
        pattern = self._config.file_pattern or "*"
        files = sorted(p for p in root.rglob(pattern) if p.is_file())
        logger.info("Selected %d file(s) under %s (pattern=%s)", len(files), root, pattern)
        return files

    # ------------------------------------------------------------------ #
    def run(self) -> int:
        """
        Execute the batch. Returns a process exit code:
        0 = complete with no failures, 2 = complete with file failures,
        1 = job-level failure.
        """
        cfg = self._config
        job_id = None
        try:
            # Step 3: create job record
            job_id = self._job_repo.create_job(
                job_name=cfg.job_name,
                config_file=cfg.config_file,
                source_directory=cfg.source_directory,
                target_bucket=cfg.target_bucket,
                target_folder=cfg.target_folder,
                triggered_by=cfg.triggered_by,
            )

            # Step 4: recursive scan + upload + per-file logging
            files = self._select_files()
            files_selected = len(files)
            files_uploaded = files_failed = 0
            bytes_uploaded = 0
            root = Path(cfg.source_directory)

            for file_path in files:
                result = self._uploader.upload_file(root, file_path)
                self._log_file_result(job_id, result)
                if result.upload_status == "SUCCESS":
                    files_uploaded += 1
                    bytes_uploaded += result.file_size_bytes
                else:
                    files_failed += 1

            # Step 5: finalize job record
            status = "COMPLETE"
            self._job_repo.complete_job(
                job_id=job_id,
                files_uploaded=files_uploaded,
                files_selected=files_selected,
                files_failed=files_failed,
                bytes_uploaded=bytes_uploaded,
                job_status=status,
                error_message=(
                    f"{files_failed} file(s) failed" if files_failed else None
                ),
            )
            logger.info(
                "Job %s finished: selected=%d uploaded=%d failed=%d bytes=%d",
                job_id, files_selected, files_uploaded, files_failed, bytes_uploaded,
            )
            return 0 if files_failed == 0 else 2

        except (Db2Error, ArchiverError) as exc:
            logger.exception("Batch job failed: %s", exc)
            if job_id:
                self._try_fail_job(job_id, str(exc))
            return 1
        except Exception as exc:  # noqa: BLE001 - last-resort guard
            logger.exception("Unexpected error in batch job: %s", exc)
            if job_id:
                self._try_fail_job(job_id, f"Unexpected error: {exc}")
            return 1
        finally:
            self._cm.close()

    # ------------------------------------------------------------------ #
    def _log_file_result(self, job_id: str, result: UploadResult) -> None:
        record = FileLogRecord(
            job_id=job_id,
            file_name=result.file_name,
            source_path=result.source_path,
            target_object=result.target_object,
            file_size_bytes=result.file_size_bytes,
            source_sha512=result.source_sha512,
            destination_sha512=result.destination_sha512,
            checksum_match=result.checksum_match,
            upload_status=result.upload_status,
            gcs_generation=result.gcs_generation,
            retry_count=result.retry_count,
            upload_start_ts=result.upload_start_ts,
            upload_end_ts=result.upload_end_ts,
            error_message=result.error_message,
        )
        try:
            self._file_repo.create_file_log(record)
        except Db2Error as exc:
            # Do not abort the whole batch because one log insert failed.
            logger.error(
                "Failed to write ARCHIVAL_FILE_LOG for %s: %s",
                result.source_path, exc,
            )

    def _try_fail_job(self, job_id: str, message: str) -> None:
        try:
            self._job_repo.fail_job(job_id, message)
        except Db2Error as exc:
            logger.error("Could not mark job %s as FAILED: %s", job_id, exc)
