"""
Application entry point.

Usage:
    gcs-archiver                       # uses config/App.config
    gcs-archiver --config /path/App.config
    python -m gcs_archiver.main --config config/App.config
"""

from __future__ import annotations

import argparse
import logging
import sys

from gcs_archiver.batch_job import ArchivalBatchJob
from gcs_archiver.config.app_config import AppConfig
from gcs_archiver.utils.exceptions import ArchiverError


def _setup_logging(level: str, log_file: str) -> None:
    fmt = "%(asctime)s %(levelname)-8s %(name)s - %(message)s"
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    logging.basicConfig(level=getattr(logging, level, logging.INFO),
                        format=fmt, handlers=handlers)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="gcs-archiver",
        description="Upload on-premise files to GCS with DB2 batch logging.",
    )
    parser.add_argument(
        "--config",
        default="config/App.config",
        help="Path to the application configuration file "
             "(default: config/App.config)",
    )
    args = parser.parse_args(argv)

    try:
        config = AppConfig.load(args.config)
    except ArchiverError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 1

    _setup_logging(config.log_level, config.log_file)
    logging.getLogger(__name__).info("Starting %s with %s", config.job_name, config)

    job = ArchivalBatchJob(config)
    return job.run()


if __name__ == "__main__":
    sys.exit(main())
