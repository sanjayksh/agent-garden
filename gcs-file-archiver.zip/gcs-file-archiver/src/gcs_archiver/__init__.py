"""
gcs_archiver
============

Batch application that reads files from an on-premise server and uploads
them to a Google Cloud Storage bucket, logging batch metadata into DB2
tables ARCHIVAL_JOB_LOG and ARCHIVAL_FILE_LOG.

Public API
----------
- AppConfig            : typed configuration loaded from config/App.config
- Db2ConnectionManager : reusable DB2 connection factory / context manager
- JobLogRepository     : CRUD operations for ARCHIVAL_JOB_LOG
- FileLogRepository    : CRUD operations for ARCHIVAL_FILE_LOG
- ArchivalBatchJob     : orchestrates the end-to-end batch run
"""

from gcs_archiver.config.app_config import AppConfig
from gcs_archiver.db.connection import Db2ConnectionManager
from gcs_archiver.db.job_log_repository import JobLogRepository
from gcs_archiver.db.file_log_repository import FileLogRepository
from gcs_archiver.batch_job import ArchivalBatchJob

__version__ = "1.0.0"

__all__ = [
    "AppConfig",
    "Db2ConnectionManager",
    "JobLogRepository",
    "FileLogRepository",
    "ArchivalBatchJob",
    "__version__",
]
