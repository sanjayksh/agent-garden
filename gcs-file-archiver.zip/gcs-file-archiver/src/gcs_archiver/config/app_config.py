"""
Module A: Configuration module.

Reads the application configuration file (INI format, default:
``config/App.config``) and loads it into the :class:`AppConfig` class so
that every setting can be read as a *property* of the class, e.g.::

    cfg = AppConfig.load("config/App.config")
    print(cfg.source_directory)
    print(cfg.target_bucket)
    print(cfg.db2_user_id)

The DB2 password can either be stored in the file (``[db2] password``)
or - preferably - supplied through the environment variable named by
``[db2] password_env_var``.
"""

from __future__ import annotations

import configparser
import os
from pathlib import Path
from typing import Optional

from gcs_archiver.utils.exceptions import ConfigurationError


class AppConfig:
    """Typed, read-only view over the application configuration file."""

    def __init__(self, parser: configparser.ConfigParser, config_path: Path) -> None:
        self._parser = parser
        self._config_path = config_path
        self._validate()

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #
    @classmethod
    def load(cls, config_file: str | os.PathLike = "config/App.config") -> "AppConfig":
        """Load and validate the configuration file."""
        path = Path(config_file)
        if not path.is_file():
            raise ConfigurationError(f"Configuration file not found: {path}")

        parser = configparser.ConfigParser(inline_comment_prefixes=(";", "#"))
        try:
            with path.open("r", encoding="utf-8") as fh:
                parser.read_file(fh)
        except (configparser.Error, OSError) as exc:
            raise ConfigurationError(f"Failed to parse configuration file {path}: {exc}") from exc

        return cls(parser, path)

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _get(self, section: str, option: str, fallback: Optional[str] = None) -> str:
        try:
            value = self._parser.get(section, option, fallback=fallback)
        except configparser.Error as exc:
            raise ConfigurationError(f"Error reading [{section}] {option}: {exc}") from exc
        if value is None:
            raise ConfigurationError(f"Missing required configuration: [{section}] {option}")
        return value.strip()

    def _get_int(self, section: str, option: str, fallback: int) -> int:
        raw = self._get(section, option, fallback=str(fallback))
        try:
            return int(raw)
        except ValueError as exc:
            raise ConfigurationError(
                f"Configuration [{section}] {option} must be an integer, got '{raw}'"
            ) from exc

    def _validate(self) -> None:
        required = [
            ("job", "job_name"),
            ("source", "source_directory"),
            ("gcs", "target_bucket"),
            ("gcs", "gcp_key_file"),
            ("db2", "database"),
            ("db2", "hostname"),
            ("db2", "port"),
            ("db2", "schema"),
            ("db2", "user_id"),
        ]
        missing = [
            f"[{s}] {o}"
            for s, o in required
            if not self._parser.get(s, o, fallback="").strip()
        ]
        if missing:
            raise ConfigurationError(
                "Missing required configuration values: " + ", ".join(missing)
            )

    # ------------------------------------------------------------------ #
    # General
    # ------------------------------------------------------------------ #
    @property
    def config_file(self) -> str:
        """Name of the configuration file (logged in ARCHIVAL_JOB_LOG.CONFIG_FILE)."""
        return self._config_path.name

    @property
    def config_path(self) -> Path:
        return self._config_path

    # ------------------------------------------------------------------ #
    # [job]
    # ------------------------------------------------------------------ #
    @property
    def job_name(self) -> str:
        return self._get("job", "job_name", "File_Uploader_Batch")

    @property
    def triggered_by(self) -> str:
        return self._get("job", "triggered_by", "BATCH_ID")

    # ------------------------------------------------------------------ #
    # [source]
    # ------------------------------------------------------------------ #
    @property
    def source_directory(self) -> str:
        return self._get("source", "source_directory")

    @property
    def file_pattern(self) -> str:
        return self._get("source", "file_pattern", "*")

    # ------------------------------------------------------------------ #
    # [gcs]
    # ------------------------------------------------------------------ #
    @property
    def target_bucket(self) -> str:
        return self._get("gcs", "target_bucket")

    @property
    def target_folder(self) -> str:
        return self._get("gcs", "target_folder", "").strip("/")

    @property
    def gcp_key_file(self) -> str:
        return self._get("gcs", "gcp_key_file")

    @property
    def upload_timeout_seconds(self) -> int:
        return self._get_int("gcs", "upload_timeout_seconds", 300)

    # ------------------------------------------------------------------ #
    # [db2]
    # ------------------------------------------------------------------ #
    @property
    def db2_database(self) -> str:
        return self._get("db2", "database")

    @property
    def db2_hostname(self) -> str:
        return self._get("db2", "hostname")

    @property
    def db2_port(self) -> int:
        return self._get_int("db2", "port", 50000)

    @property
    def db2_schema(self) -> str:
        return self._get("db2", "schema")

    @property
    def db2_user_id(self) -> str:
        return self._get("db2", "user_id")

    @property
    def db2_password(self) -> str:
        """Password from env var (preferred) or config file."""
        env_var = self._get("db2", "password_env_var", "DB2_PASSWORD")
        env_value = os.environ.get(env_var, "").strip()
        if env_value:
            return env_value
        file_value = self._get("db2", "password", "")
        if file_value:
            return file_value
        raise ConfigurationError(
            f"DB2 password not found: set environment variable '{env_var}' "
            "or [db2] password in the configuration file."
        )

    @property
    def db2_security(self) -> str:
        return self._get("db2", "security", "")

    @property
    def db2_ssl_server_certificate(self) -> str:
        return self._get("db2", "ssl_server_certificate", "")

    # ------------------------------------------------------------------ #
    # [retry]
    # ------------------------------------------------------------------ #
    @property
    def max_retries(self) -> int:
        return self._get_int("retry", "max_retries", 3)

    @property
    def retry_backoff_seconds(self) -> int:
        return self._get_int("retry", "retry_backoff_seconds", 5)

    # ------------------------------------------------------------------ #
    # [logging]
    # ------------------------------------------------------------------ #
    @property
    def log_level(self) -> str:
        return self._get("logging", "log_level", "INFO").upper()

    @property
    def log_file(self) -> str:
        return self._get("logging", "log_file", "gcs_archiver.log")

    def __repr__(self) -> str:  # never expose the password
        return (
            f"AppConfig(config_file={self.config_file!r}, "
            f"source_directory={self.source_directory!r}, "
            f"target_bucket={self.target_bucket!r}, "
            f"db2_database={self.db2_database!r}, "
            f"db2_user_id={self.db2_user_id!r})"
        )
