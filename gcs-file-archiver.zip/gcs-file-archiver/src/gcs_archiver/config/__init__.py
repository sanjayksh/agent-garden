"""Configuration package (Module A)."""
from gcs_archiver.config.app_config import AppConfig

__all__ = ["AppConfig"]
