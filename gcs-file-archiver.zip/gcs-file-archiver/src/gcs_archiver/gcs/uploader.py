"""
GCS uploader module.

Uploads a local file to a Google Cloud Storage bucket with:
* SHA-512 source checksum computed while streaming the file,
* MD5/CRC32C integrity enforced by the client library during upload,
* destination SHA-512 verification by re-hashing the uploaded object,
* configurable retry with linear backoff,
* result object carrying everything ARCHIVAL_FILE_LOG needs.
"""

from __future__ import annotations

import base64
import hashlib
import logging
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from gcs_archiver.config.app_config import AppConfig
from gcs_archiver.utils.exceptions import GcsUploadError

logger = logging.getLogger(__name__)

_CHUNK = 8 * 1024 * 1024  # 8 MiB


@dataclass
class UploadResult:
    file_name: str
    source_path: str
    target_object: str
    file_size_bytes: int
    source_sha512: Optional[str]
    destination_sha512: Optional[str]
    checksum_match: str          # 'Y' / 'N'
    upload_status: str           # 'SUCCESS' / 'FAILURE'
    gcs_generation: Optional[str]
    retry_count: int
    upload_start_ts: datetime
    upload_end_ts: datetime
    error_message: Optional[str] = None


def sha512_of_file(path: Path) -> str:
    """Stream a file and return its hex SHA-512 digest."""
    digest = hashlib.sha512()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(_CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


class GcsUploader:
    """Uploads files to the configured bucket with verification and retries."""

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._client = None
        self._bucket = None

    # ------------------------------------------------------------------ #
    def _ensure_client(self):
        if self._client is None:
            try:
                from google.cloud import storage  # lazy import
            except ImportError as exc:  # pragma: no cover
                raise GcsUploadError(
                    "google-cloud-storage is not installed. "
                    "Install it with: pip install google-cloud-storage"
                ) from exc
            try:
                self._client = storage.Client.from_service_account_json(
                    self._config.gcp_key_file
                )
                self._bucket = self._client.bucket(self._config.target_bucket)
            except Exception as exc:  # noqa: BLE001
                raise GcsUploadError(
                    f"Failed to initialise GCS client with key file "
                    f"{self._config.gcp_key_file}: {exc}"
                ) from exc
        return self._bucket

    # ------------------------------------------------------------------ #
    def build_object_name(self, source_root: Path, file_path: Path) -> str:
        """Preserve the relative directory structure under target_folder."""
        rel = file_path.relative_to(source_root).as_posix()
        folder = self._config.target_folder
        return f"{folder}/{rel}" if folder else rel

    # ------------------------------------------------------------------ #
    def upload_file(self, source_root: Path, file_path: Path) -> UploadResult:
        """
        Upload one file. Never raises for per-file failures: all outcomes
        are captured in the returned :class:`UploadResult` so the batch can
        continue and the failure is recorded in ARCHIVAL_FILE_LOG.
        """
        start_ts = datetime.now()
        target_object = self.build_object_name(source_root, file_path)
        size = file_path.stat().st_size
        source_sha512: Optional[str] = None
        error: Optional[str] = None
        generation: Optional[str] = None
        dest_sha512: Optional[str] = None
        attempts = 0

        try:
            source_sha512 = sha512_of_file(file_path)
        except OSError as exc:
            error = f"Cannot read source file: {exc}"

        if error is None:
            max_retries = self._config.max_retries
            backoff = self._config.retry_backoff_seconds
            while attempts <= max_retries:
                try:
                    bucket = self._ensure_client()
                    blob = bucket.blob(target_object)
                    blob.upload_from_filename(
                        str(file_path),
                        checksum="md5",  # transport integrity check
                        timeout=self._config.upload_timeout_seconds,
                    )
                    blob.reload()
                    generation = str(blob.generation)
                    dest_sha512 = self._destination_sha512(blob)
                    error = None
                    break
                except Exception as exc:  # noqa: BLE001
                    attempts += 1
                    error = f"Upload attempt {attempts} failed: {exc}"
                    logger.warning("%s (%s)", error, file_path)
                    if attempts <= max_retries:
                        time.sleep(backoff * attempts)

        end_ts = datetime.now()
        checksum_match = (
            "Y"
            if source_sha512 and dest_sha512 and source_sha512 == dest_sha512
            else "N"
        )
        status = "SUCCESS" if error is None and checksum_match == "Y" else "FAILURE"
        if status == "FAILURE" and error is None:
            error = (
                f"Checksum mismatch: source={source_sha512} "
                f"destination={dest_sha512}"
            )

        return UploadResult(
            file_name=file_path.name,
            source_path=str(file_path),
            target_object=target_object,
            file_size_bytes=size,
            source_sha512=source_sha512,
            destination_sha512=dest_sha512,
            checksum_match=checksum_match,
            upload_status=status,
            gcs_generation=generation,
            retry_count=max(attempts - 1, 0) if error else attempts,
            upload_start_ts=start_ts,
            upload_end_ts=end_ts,
            error_message=error,
        )

    # ------------------------------------------------------------------ #
    def _destination_sha512(self, blob) -> Optional[str]:
        """
        GCS does not store SHA-512 natively, so verify by streaming the
        uploaded object back and hashing it. For very large objects this
        doubles transfer cost; the MD5 transport check already guarantees
        wire integrity, but the batch spec requires DESTINATION_SHA512.
        """
        try:
            digest = hashlib.sha512()
            with blob.open("rb") as fh:
                for chunk in iter(lambda: fh.read(_CHUNK), b""):
                    digest.update(chunk)
            return digest.hexdigest()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Could not compute destination SHA-512 for %s: %s", blob.name, exc
            )
            return None
