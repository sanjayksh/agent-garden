"""
Module B: DB2 connection module.

Provides :class:`Db2ConnectionManager`, a reusable connection factory
shared by all repository modules. Features:

* Builds the DB2 connection string from :class:`AppConfig` (SSL aware).
* Lazily opens a single shared connection and reuses it.
* Auto-reconnects if the connection was dropped.
* Context-manager support (``with Db2ConnectionManager(cfg) as conn:``).
* ``transaction()`` context manager with commit/rollback semantics.
* All failures are surfaced as classified :class:`Db2Error` subclasses.

The ``ibm_db`` driver is imported lazily so the package can be imported
(e.g. for unit tests with mocks) on machines without the DB2 client.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Iterator, Optional

from gcs_archiver.config.app_config import AppConfig
from gcs_archiver.utils.exceptions import (
    Db2ConnectionError,
    classify_db2_error,
)

logger = logging.getLogger(__name__)


def _ibm_db():
    """Lazy import of the ibm_db driver."""
    try:
        import ibm_db  # type: ignore
        return ibm_db
    except ImportError as exc:  # pragma: no cover
        raise Db2ConnectionError(
            "ibm_db driver is not installed. Install it with: pip install ibm-db"
        ) from exc


class Db2ConnectionManager:
    """Reusable DB2 connection manager shared across all repositories."""

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._conn: Optional[Any] = None

    # ------------------------------------------------------------------ #
    # Connection string
    # ------------------------------------------------------------------ #
    def _build_connection_string(self) -> str:
        cfg = self._config
        parts = [
            f"DATABASE={cfg.db2_database}",
            f"HOSTNAME={cfg.db2_hostname}",
            f"PORT={cfg.db2_port}",
            "PROTOCOL=TCPIP",
            f"UID={cfg.db2_user_id}",
            f"PWD={cfg.db2_password}",
        ]
        if cfg.db2_security:
            parts.append(f"SECURITY={cfg.db2_security}")
        if cfg.db2_ssl_server_certificate:
            parts.append(f"SSLServerCertificate={cfg.db2_ssl_server_certificate}")
        return ";".join(parts) + ";"

    # ------------------------------------------------------------------ #
    # Connection lifecycle
    # ------------------------------------------------------------------ #
    def get_connection(self) -> Any:
        """Return a live connection, opening or re-opening as required."""
        ibm_db = _ibm_db()
        if self._conn is not None:
            try:
                if ibm_db.active(self._conn):
                    return self._conn
            except Exception:  # noqa: BLE001
                logger.warning("Existing DB2 connection is stale; reconnecting.")
                self._conn = None

        conn_str = self._build_connection_string()
        try:
            # Turn autocommit OFF; commits are managed via transaction().
            options = {ibm_db.SQL_ATTR_AUTOCOMMIT: ibm_db.SQL_AUTOCOMMIT_OFF}
            self._conn = ibm_db.connect(conn_str, "", "", options)
            logger.info(
                "Connected to DB2 database %s@%s:%s as %s",
                self._config.db2_database,
                self._config.db2_hostname,
                self._config.db2_port,
                self._config.db2_user_id,
            )
            return self._conn
        except Exception as exc:  # noqa: BLE001
            raw = self._safe_conn_errormsg()
            raise Db2ConnectionError(
                f"Failed to connect to DB2: {raw or exc}"
            ) from exc

    def close(self) -> None:
        """Close the shared connection if open."""
        if self._conn is None:
            return
        ibm_db = _ibm_db()
        try:
            ibm_db.close(self._conn)
            logger.info("DB2 connection closed.")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Error while closing DB2 connection: %s", exc)
        finally:
            self._conn = None

    # ------------------------------------------------------------------ #
    # Transactions
    # ------------------------------------------------------------------ #
    @contextmanager
    def transaction(self) -> Iterator[Any]:
        """
        Context manager yielding a connection inside a transaction.
        Commits on success, rolls back on any exception.
        """
        ibm_db = _ibm_db()
        conn = self.get_connection()
        try:
            yield conn
            ibm_db.commit(conn)
        except Exception as exc:  # noqa: BLE001
            try:
                ibm_db.rollback(conn)
                logger.warning("Transaction rolled back due to: %s", exc)
            except Exception as rb_exc:  # noqa: BLE001
                logger.error("Rollback failed: %s", rb_exc)
            raise

    # ------------------------------------------------------------------ #
    # Statement helpers (shared by repositories)
    # ------------------------------------------------------------------ #
    def execute(self, conn: Any, sql: str, params: tuple = ()) -> Any:
        """Prepare and execute a parameterised statement; return the stmt handle."""
        ibm_db = _ibm_db()
        try:
            stmt = ibm_db.prepare(conn, sql)
            ibm_db.execute(stmt, params)
            return stmt
        except Exception as exc:  # noqa: BLE001
            raw = _ibm_db().stmt_errormsg() or str(exc)
            raise classify_db2_error(raw, operation=sql.split(None, 1)[0]) from exc

    def _safe_conn_errormsg(self) -> str:
        try:
            return _ibm_db().conn_errormsg() or ""
        except Exception:  # noqa: BLE001
            return ""

    # ------------------------------------------------------------------ #
    # Context manager protocol
    # ------------------------------------------------------------------ #
    def __enter__(self) -> "Db2ConnectionManager":
        self.get_connection()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
