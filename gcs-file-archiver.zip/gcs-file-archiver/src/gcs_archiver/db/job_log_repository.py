"""
Module C: DB2 module for creating and updating ARCHIVAL_JOB_LOG records.

Table schema:
    ARCHIVAL_JOB_LOG(
        JOB_ID, JOB_NAME, CONFIG_FILE, SOURCE_DIRECTORY, TARGET_BUCKET,
        TARGET_FOLDER, JOB_STATUS, FILES_UPLOADED, FILES_SELECTED,
        FILES_FAILED, BYTES_UPLOADED, TRIGGERED_BY, JOB_START_TS,
        JOB_END_TS, ERROR_MESSAGE, CREATED_TS
    )
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Optional

from gcs_archiver.db.connection import Db2ConnectionManager
from gcs_archiver.utils.exceptions import handle_db2_errors

logger = logging.getLogger(__name__)


@dataclass
class JobLogRecord:
    """In-memory representation of an ARCHIVAL_JOB_LOG row."""

    job_id: str
    job_name: str
    config_file: str
    source_directory: str
    target_bucket: str
    target_folder: str
    job_status: str = "STARTED"
    triggered_by: str = "BATCH_ID"


class JobLogRepository:
    """Create/update rows in <schema>.ARCHIVAL_JOB_LOG."""

    def __init__(self, conn_manager: Db2ConnectionManager, schema: str) -> None:
        self._cm = conn_manager
        self._table = f"{schema}.ARCHIVAL_JOB_LOG"

    # ------------------------------------------------------------------ #
    # Step 3: create job record when the batch starts
    # ------------------------------------------------------------------ #
    @handle_db2_errors("insert ARCHIVAL_JOB_LOG")
    def create_job(
        self,
        job_name: str,
        config_file: str,
        source_directory: str,
        target_bucket: str,
        target_folder: str,
        triggered_by: str,
    ) -> str:
        """
        Insert a new job row with JOB_STATUS='STARTED',
        JOB_START_TS=CURRENT TIMESTAMP. Returns the generated JOB_ID (UUID).
        """
        job_id = str(uuid.uuid4())
        sql = f"""
            INSERT INTO {self._table} (
                JOB_ID, JOB_NAME, CONFIG_FILE, SOURCE_DIRECTORY,
                TARGET_BUCKET, TARGET_FOLDER, JOB_STATUS, TRIGGERED_BY,
                JOB_START_TS, CREATED_TS
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT TIMESTAMP, CURRENT TIMESTAMP)
        """
        with self._cm.transaction() as conn:
            self._cm.execute(
                conn,
                sql,
                (
                    job_id,
                    job_name,
                    config_file,
                    source_directory,
                    target_bucket,
                    target_folder,
                    "STARTED",
                    triggered_by,
                ),
            )
        logger.info("ARCHIVAL_JOB_LOG created: JOB_ID=%s status=STARTED", job_id)
        return job_id

    # ------------------------------------------------------------------ #
    # Step 5: finalize the job when all files are processed
    # ------------------------------------------------------------------ #
    @handle_db2_errors("update ARCHIVAL_JOB_LOG completion")
    def complete_job(
        self,
        job_id: str,
        files_uploaded: int,
        files_selected: int,
        files_failed: int,
        bytes_uploaded: int,
        job_status: str = "COMPLETE",
        error_message: Optional[str] = None,
    ) -> None:
        """Update the job row with final counters and JOB_END_TS."""
        sql = f"""
            UPDATE {self._table}
               SET JOB_STATUS     = ?,
                   FILES_UPLOADED = ?,
                   FILES_SELECTED = ?,
                   FILES_FAILED   = ?,
                   BYTES_UPLOADED = ?,
                   JOB_END_TS     = CURRENT TIMESTAMP,
                   ERROR_MESSAGE  = ?
             WHERE JOB_ID = ?
        """
        with self._cm.transaction() as conn:
            self._cm.execute(
                conn,
                sql,
                (
                    job_status,
                    files_uploaded,
                    files_selected,
                    files_failed,
                    bytes_uploaded,
                    _truncate(error_message, 1024),
                    job_id,
                ),
            )
        logger.info(
            "ARCHIVAL_JOB_LOG updated: JOB_ID=%s status=%s uploaded=%d failed=%d bytes=%d",
            job_id, job_status, files_uploaded, files_failed, bytes_uploaded,
        )

    # ------------------------------------------------------------------ #
    # Failure path: mark the whole job failed
    # ------------------------------------------------------------------ #
    @handle_db2_errors("update ARCHIVAL_JOB_LOG failure")
    def fail_job(self, job_id: str, error_message: str) -> None:
        sql = f"""
            UPDATE {self._table}
               SET JOB_STATUS    = 'FAILED',
                   JOB_END_TS    = CURRENT TIMESTAMP,
                   ERROR_MESSAGE = ?
             WHERE JOB_ID = ?
        """
        with self._cm.transaction() as conn:
            self._cm.execute(conn, sql, (_truncate(error_message, 1024), job_id))
        logger.error("ARCHIVAL_JOB_LOG updated: JOB_ID=%s status=FAILED", job_id)


def _truncate(text: Optional[str], limit: int) -> Optional[str]:
    if text is None:
        return None
    return text if len(text) <= limit else text[: limit - 3] + "..."
