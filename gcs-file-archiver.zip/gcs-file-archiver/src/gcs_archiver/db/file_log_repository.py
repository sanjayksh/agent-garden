"""
Module D: DB2 module for creating and updating ARCHIVAL_FILE_LOG records.

Table schema:
    ARCHIVAL_FILE_LOG(
        FILE_LOG_ID, JOB_ID, FILE_NAME, SOURCE_PATH, TARGET_OBJECT,
        FILE_SIZE_BYTES, SOURCE_SHA512, DESTINATION_SHA512, CHECKSUM_MATCH,
        UPLOAD_STATUS, GCS_GENERATION, RETRY_COUNT, UPLOAD_START_TS,
        UPLOAD_END_TS, ERROR_MESSAGE
    )
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from gcs_archiver.db.connection import Db2ConnectionManager
from gcs_archiver.utils.exceptions import handle_db2_errors

logger = logging.getLogger(__name__)

_TS_FMT = "%Y-%m-%d %H:%M:%S.%f"


@dataclass
class FileLogRecord:
    """In-memory representation of an ARCHIVAL_FILE_LOG row."""

    job_id: str
    file_name: str
    source_path: str
    target_object: str
    file_size_bytes: int
    source_sha512: Optional[str] = None
    destination_sha512: Optional[str] = None
    checksum_match: str = "N"                  # 'Y' or 'N'
    upload_status: str = "FAILURE"             # 'SUCCESS' or 'FAILURE'
    gcs_generation: Optional[str] = None
    retry_count: int = 0
    upload_start_ts: Optional[datetime] = None
    upload_end_ts: Optional[datetime] = None
    error_message: Optional[str] = None
    file_log_id: str = field(default_factory=lambda: str(uuid.uuid4()))


class FileLogRepository:
    """Create/update rows in <schema>.ARCHIVAL_FILE_LOG."""

    def __init__(self, conn_manager: Db2ConnectionManager, schema: str) -> None:
        self._cm = conn_manager
        self._table = f"{schema}.ARCHIVAL_FILE_LOG"

    # ------------------------------------------------------------------ #
    # Step 4: insert a record after each file upload finishes
    # ------------------------------------------------------------------ #
    @handle_db2_errors("insert ARCHIVAL_FILE_LOG")
    def create_file_log(self, record: FileLogRecord) -> str:
        """Insert one file-upload result row; returns FILE_LOG_ID."""
        sql = f"""
            INSERT INTO {self._table} (
                FILE_LOG_ID, JOB_ID, FILE_NAME, SOURCE_PATH, TARGET_OBJECT,
                FILE_SIZE_BYTES, SOURCE_SHA512, DESTINATION_SHA512,
                CHECKSUM_MATCH, UPLOAD_STATUS, GCS_GENERATION, RETRY_COUNT,
                UPLOAD_START_TS, UPLOAD_END_TS, ERROR_MESSAGE
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        with self._cm.transaction() as conn:
            self._cm.execute(
                conn,
                sql,
                (
                    record.file_log_id,
                    record.job_id,
                    record.file_name,
                    record.source_path,
                    record.target_object,
                    record.file_size_bytes,
                    record.source_sha512,
                    record.destination_sha512,
                    record.checksum_match,
                    record.upload_status,
                    record.gcs_generation,
                    record.retry_count,
                    _fmt_ts(record.upload_start_ts),
                    _fmt_ts(record.upload_end_ts),
                    _truncate(record.error_message, 1024),
                ),
            )
        logger.info(
            "ARCHIVAL_FILE_LOG created: FILE_LOG_ID=%s file=%s status=%s",
            record.file_log_id, record.file_name, record.upload_status,
        )
        return record.file_log_id

    # ------------------------------------------------------------------ #
    # Optional update path (e.g. post-verification or reprocessing)
    # ------------------------------------------------------------------ #
    @handle_db2_errors("update ARCHIVAL_FILE_LOG")
    def update_file_log(
        self,
        file_log_id: str,
        upload_status: Optional[str] = None,
        destination_sha512: Optional[str] = None,
        checksum_match: Optional[str] = None,
        gcs_generation: Optional[str] = None,
        retry_count: Optional[int] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Update selected columns of an existing file log row."""
        sets, params = [], []
        for column, value in (
            ("UPLOAD_STATUS", upload_status),
            ("DESTINATION_SHA512", destination_sha512),
            ("CHECKSUM_MATCH", checksum_match),
            ("GCS_GENERATION", gcs_generation),
            ("RETRY_COUNT", retry_count),
            ("ERROR_MESSAGE", _truncate(error_message, 1024)),
        ):
            if value is not None:
                sets.append(f"{column} = ?")
                params.append(value)
        if not sets:
            return
        sets.append("UPLOAD_END_TS = CURRENT TIMESTAMP")
        sql = f"UPDATE {self._table} SET {', '.join(sets)} WHERE FILE_LOG_ID = ?"
        params.append(file_log_id)

        with self._cm.transaction() as conn:
            self._cm.execute(conn, sql, tuple(params))
        logger.info("ARCHIVAL_FILE_LOG updated: FILE_LOG_ID=%s", file_log_id)


def _fmt_ts(ts: Optional[datetime]) -> Optional[str]:
    return ts.strftime(_TS_FMT) if ts else None


def _truncate(text: Optional[str], limit: int) -> Optional[str]:
    if text is None:
        return None
    return text if len(text) <= limit else text[: limit - 3] + "..."
