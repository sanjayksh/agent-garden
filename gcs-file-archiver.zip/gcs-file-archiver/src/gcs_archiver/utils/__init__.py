"""Utility package: exceptions and DB2 error handling (Module E)."""
from gcs_archiver.utils.exceptions import (
    ArchiverError, ConfigurationError, SourceDirectoryError,
    GcsUploadError, ChecksumMismatchError,
    Db2Error, Db2ConnectionError, Db2DeadlockError, Db2DuplicateKeyError,
    Db2ObjectNotFoundError, Db2DataError, Db2SqlError,
    handle_db2_errors, classify_db2_error, parse_db2_message,
)
