"""
Module E: Database-specific error handling.

Defines the application exception hierarchy and a decorator
(:func:`handle_db2_errors`) that translates low-level ``ibm_db`` driver
failures into rich, classified exceptions carrying SQLCODE / SQLSTATE.

DB2 error classification (by SQLCODE):
    -30081, -1224, -1229           -> Db2ConnectionError (communication)
    -911, -913                      -> Db2DeadlockError (deadlock/timeout, retryable)
    -803                            -> Db2DuplicateKeyError
    -204, -206                      -> Db2ObjectNotFoundError (table/column missing)
    -407, -302, -530, -545          -> Db2DataError (nulls, truncation, RI, check)
    anything else                   -> Db2SqlError
"""

from __future__ import annotations

import functools
import logging
import re
import time
from typing import Any, Callable, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# --------------------------------------------------------------------- #
# Application-level exceptions
# --------------------------------------------------------------------- #
class ArchiverError(Exception):
    """Base class for all application errors."""


class ConfigurationError(ArchiverError):
    """Raised when the configuration file is missing or invalid."""


class SourceDirectoryError(ArchiverError):
    """Raised when the source directory cannot be read."""


class GcsUploadError(ArchiverError):
    """Raised when a file upload to GCS fails after all retries."""


class ChecksumMismatchError(GcsUploadError):
    """Raised when source and destination SHA-512 checksums differ."""


# --------------------------------------------------------------------- #
# DB2-specific exceptions
# --------------------------------------------------------------------- #
class Db2Error(ArchiverError):
    """Base class for all DB2 errors. Carries SQLCODE and SQLSTATE."""

    def __init__(
        self,
        message: str,
        sqlcode: Optional[int] = None,
        sqlstate: Optional[str] = None,
        operation: Optional[str] = None,
    ) -> None:
        self.sqlcode = sqlcode
        self.sqlstate = sqlstate
        self.operation = operation
        detail = message
        if sqlcode is not None:
            detail += f" [SQLCODE={sqlcode}]"
        if sqlstate:
            detail += f" [SQLSTATE={sqlstate}]"
        if operation:
            detail += f" [operation={operation}]"
        super().__init__(detail)


class Db2ConnectionError(Db2Error):
    """Connection could not be established or was lost (e.g. SQL30081N)."""


class Db2DeadlockError(Db2Error):
    """Deadlock or lock timeout (-911 / -913). Safe to retry."""


class Db2DuplicateKeyError(Db2Error):
    """Unique constraint violation (-803)."""


class Db2ObjectNotFoundError(Db2Error):
    """Table, view or column does not exist (-204 / -206)."""


class Db2DataError(Db2Error):
    """Data integrity error: null constraint, truncation, RI violation."""


class Db2SqlError(Db2Error):
    """Any other SQL failure."""


# --------------------------------------------------------------------- #
# SQLCODE / SQLSTATE extraction and classification
# --------------------------------------------------------------------- #
_SQLCODE_RE = re.compile(r"SQLCODE\s*=\s*(-?\d+)", re.IGNORECASE)
_SQLSTATE_RE = re.compile(r"SQLSTATE\s*=?\s*([0-9A-Z]{5})", re.IGNORECASE)

_RETRYABLE_SQLCODES = {-911, -913}
_CONNECTION_SQLCODES = {-30081, -1224, -1229, -1024, -1042}
_NOT_FOUND_SQLCODES = {-204, -206}
_DATA_SQLCODES = {-407, -302, -530, -531, -532, -545}


def parse_db2_message(raw_message: str) -> tuple[Optional[int], Optional[str]]:
    """Extract (sqlcode, sqlstate) from an ibm_db driver error string."""
    sqlcode = None
    sqlstate = None
    if raw_message:
        m = _SQLCODE_RE.search(raw_message)
        if m:
            sqlcode = int(m.group(1))
        s = _SQLSTATE_RE.search(raw_message)
        if s:
            sqlstate = s.group(1)
    return sqlcode, sqlstate


def classify_db2_error(raw_message: str, operation: str = "") -> Db2Error:
    """Turn a raw driver message into the most specific Db2Error subclass."""
    sqlcode, sqlstate = parse_db2_message(raw_message)
    kwargs = {"sqlcode": sqlcode, "sqlstate": sqlstate, "operation": operation}

    if sqlcode in _CONNECTION_SQLCODES or (sqlstate and sqlstate.startswith("08")):
        return Db2ConnectionError(raw_message, **kwargs)
    if sqlcode in _RETRYABLE_SQLCODES or sqlstate in ("40001", "57033"):
        return Db2DeadlockError(raw_message, **kwargs)
    if sqlcode == -803 or sqlstate == "23505":
        return Db2DuplicateKeyError(raw_message, **kwargs)
    if sqlcode in _NOT_FOUND_SQLCODES or sqlstate in ("42704", "42703"):
        return Db2ObjectNotFoundError(raw_message, **kwargs)
    if sqlcode in _DATA_SQLCODES or (sqlstate and sqlstate.startswith("23")):
        return Db2DataError(raw_message, **kwargs)
    return Db2SqlError(raw_message, **kwargs)


# --------------------------------------------------------------------- #
# Decorator: uniform DB2 error handling with deadlock retry
# --------------------------------------------------------------------- #
def handle_db2_errors(
    operation: str,
    retries_on_deadlock: int = 2,
    backoff_seconds: float = 1.0,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator for repository methods.

    * Converts raw driver exceptions into classified :class:`Db2Error`s.
    * Automatically retries on deadlock / lock-timeout errors.
    * Logs every failure with SQLCODE / SQLSTATE context.
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            attempt = 0
            while True:
                try:
                    return func(*args, **kwargs)
                except Db2Error:
                    raise  # already classified deeper in the stack
                except Exception as exc:  # noqa: BLE001 - driver raises bare Exception
                    db2_exc = classify_db2_error(str(exc), operation)
                    if isinstance(db2_exc, Db2DeadlockError) and attempt < retries_on_deadlock:
                        attempt += 1
                        wait = backoff_seconds * attempt
                        logger.warning(
                            "Deadlock/timeout during %s (attempt %d/%d), retrying in %.1fs: %s",
                            operation, attempt, retries_on_deadlock, wait, db2_exc,
                        )
                        time.sleep(wait)
                        continue
                    logger.error("DB2 error during %s: %s", operation, db2_exc)
                    raise db2_exc from exc

        return wrapper

    return decorator
