# GCS File Archiver

Batch application that reads files from an on-premise server and uploads them
recursively to a Google Cloud Storage bucket, logging batch metadata into the
DB2 tables `ARCHIVAL_JOB_LOG` and `ARCHIVAL_FILE_LOG`.

## Workflow

1. Reads the configuration file (`config/App.config`).
2. Inserts an `ARCHIVAL_JOB_LOG` row (`JOB_STATUS='STARTED'`, `JOB_ID=UUID`,
   `JOB_START_TS=CURRENT TIMESTAMP`).
3. Recursively walks the source directory and uploads each file to the
   configured bucket/folder, preserving relative paths.
4. After every upload (success or failure) it inserts an `ARCHIVAL_FILE_LOG`
   row with SHA-512 source/destination checksums, checksum match flag,
   GCS object generation, retry count, timestamps and error message.
5. When all files are processed it updates the job row with
   `JOB_STATUS='COMPLETE'`, `FILES_UPLOADED`, `FILES_SELECTED`,
   `FILES_FAILED`, `BYTES_UPLOADED` and `JOB_END_TS`.
   On a fatal error the job is marked `FAILED` with the error message.

## Package layout

```
gcs-file-archiver/
├── pyproject.toml                  # F: standard Python packaging (PEP 621, src layout)
├── README.md
├── config/
│   └── App.config                  # sample configuration
├── sql/
│   └── create_tables.sql           # DB2 DDL for both tables
└── src/
    └── gcs_archiver/
        ├── main.py                 # CLI entry point (console script: gcs-archiver)
        ├── batch_job.py            # orchestrator (steps 2–5)
        ├── config/
        │   └── app_config.py       # A: configuration as class properties
        ├── db/
        │   ├── connection.py       # B: reusable DB2 connection manager
        │   ├── job_log_repository.py   # C: ARCHIVAL_JOB_LOG create/update
        │   └── file_log_repository.py  # D: ARCHIVAL_FILE_LOG create/update
        ├── gcs/
        │   └── uploader.py         # GCS upload + SHA-512 verification + retry
        └── utils/
            └── exceptions.py       # E: DB2-specific error handling
```

## Installation

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install .
```

Dependencies: `ibm-db` (DB2 driver), `google-cloud-storage`.

## Database setup

Run `sql/create_tables.sql` against your DB2 database (adjust the schema
name if it is not `ARCHIVE`).

## Configuration

Edit `config/App.config`. Key settings:

| Section  | Key                | Purpose                              |
|----------|--------------------|--------------------------------------|
| job      | job_name           | `ARCHIVAL_JOB_LOG.JOB_NAME`          |
| job      | triggered_by       | `ARCHIVAL_JOB_LOG.TRIGGERED_BY`      |
| source   | source_directory   | root folder scanned recursively      |
| gcs      | target_bucket      | destination bucket                   |
| gcs      | target_folder      | prefix inside the bucket             |
| gcs      | gcp_key_file       | GCP service-account JSON key path    |
| db2      | database/hostname/port/schema/user_id | DB2 connection    |
| db2      | password_env_var   | env var holding the DB2 password (preferred over storing it in the file) |
| retry    | max_retries        | per-file upload retries              |

Set the DB2 password via environment variable:

```bash
export DB2_PASSWORD='***'          # Windows: set DB2_PASSWORD=***
```

## Running

```bash
gcs-archiver --config config/App.config
# or
python -m gcs_archiver.main --config config/App.config
```

Exit codes: `0` complete without failures, `2` complete with per-file
failures, `1` job-level failure (config, DB2 connection, source dir, etc.).

## Error handling (Module E)

All DB2 failures are converted into a typed exception hierarchy in
`gcs_archiver.utils.exceptions`, with SQLCODE/SQLSTATE parsed from the
driver message:

- `Db2ConnectionError` — communication failures (SQL30081N, SQLSTATE 08xxx)
- `Db2DeadlockError` — `-911`/`-913`; automatically retried by the
  `handle_db2_errors` decorator
- `Db2DuplicateKeyError` — `-803` unique-key violations
- `Db2ObjectNotFoundError` — `-204`/`-206` missing table/column
- `Db2DataError` — null/truncation/referential-integrity errors
- `Db2SqlError` — everything else

Per-file upload failures never abort the batch: they are logged to
`ARCHIVAL_FILE_LOG` with `UPLOAD_STATUS='FAILURE'` and counted in
`FILES_FAILED`. A failed file-log insert is logged and skipped so one bad
row cannot kill the run.
