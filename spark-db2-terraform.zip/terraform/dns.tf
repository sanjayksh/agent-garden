#############################################
# Cloud DNS (host project)
#############################################

# Private zones: *.googleapis.com / *.pkg.dev / *.gcr.io -> Google APIs VIP
resource "google_dns_managed_zone" "google_apis" {
  for_each    = local.google_api_domains
  project     = var.host_project_id
  name        = "pz-${each.key}"
  dns_name    = each.value
  description = "Private Google Access: ${each.value} -> ${local.google_vip.hostname}"
  visibility  = "private"
  labels      = var.labels

  private_visibility_config {
    networks { network_url = data.google_compute_network.shared_vpc.id }
  }
}

resource "google_dns_record_set" "google_apis_a" {
  for_each     = local.google_api_domains
  project      = var.host_project_id
  managed_zone = google_dns_managed_zone.google_apis[each.key].name
  name         = each.key == "googleapis" ? local.google_vip.hostname : each.value
  type         = "A"
  ttl          = 300
  rrdatas      = local.google_vip.ips
}

resource "google_dns_record_set" "google_apis_cname" {
  for_each     = local.google_api_domains
  project      = var.host_project_id
  managed_zone = google_dns_managed_zone.google_apis[each.key].name
  name         = "*.${each.value}"
  type         = "CNAME"
  ttl          = 300
  rrdatas      = [each.key == "googleapis" ? local.google_vip.hostname : each.value]
}

# Outbound forwarding: Spark VMs resolve DB2 hostnames via on-prem DNS.
resource "google_dns_managed_zone" "onprem_forwarding" {
  project     = var.host_project_id
  name        = "fz-onprem-${replace(trimsuffix(var.onprem_dns_domain, "."), ".", "-")}"
  dns_name    = "${trimsuffix(var.onprem_dns_domain, ".")}."
  description = "Forward ${var.onprem_dns_domain} to on-prem DNS over HA VPN"
  visibility  = "private"
  labels      = var.labels

  private_visibility_config {
    networks { network_url = data.google_compute_network.shared_vpc.id }
  }

  forwarding_config {
    dynamic "target_name_servers" {
      for_each = var.onprem_dns_servers
      content {
        ipv4_address    = target_name_servers.value
        forwarding_path = "private" # always route via VPN, never the internet
      }
    }
  }
}

# Inbound forwarding: on-prem DNS conditionally forwards googleapis.com to these
# per-subnet inbound forwarder IPs so Autosys resolves dataproc.googleapis.com to the VIP.
resource "google_dns_policy" "inbound" {
  project                   = var.host_project_id
  name                      = "dnspol-inbound-onprem"
  enable_inbound_forwarding = true
  enable_logging            = true

  networks { network_url = data.google_compute_network.shared_vpc.id }
}

data "google_compute_addresses" "dns_inbound" {
  project = var.host_project_id
  region  = var.region
  filter  = "purpose=\"DNS_RESOLVER\""

  depends_on = [google_dns_policy.inbound, google_compute_subnetwork.spark]
}
