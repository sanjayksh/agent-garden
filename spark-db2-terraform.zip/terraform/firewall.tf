#############################################
# Firewall rules (host project)
# NOTE: The auto-created system firewall policy for serverless Spark does NOT support
# Shared VPC, so the intra-subnet rules below are mandatory.
#############################################

# 1. Spark driver <-> executor communication: all protocols/ports inside the subnet.
resource "google_compute_firewall" "spark_internal_ingress" {
  project     = var.host_project_id
  name        = "fw-allow-spark-internal-ingress"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "INGRESS"
  priority    = 1000
  description = "Spark serverless: driver/executor/shuffle traffic between VMs in the Spark subnet"

  source_ranges = [var.spark_subnet_cidr]
  target_tags   = [var.spark_network_tag]

  allow { protocol = "tcp" }
  allow { protocol = "udp" }
  allow { protocol = "icmp" }

  log_config { metadata = "INCLUDE_ALL_METADATA" }
}

resource "google_compute_firewall" "spark_internal_egress" {
  project     = var.host_project_id
  name        = "fw-allow-spark-internal-egress"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "EGRESS"
  priority    = 1000
  description = "Spark serverless: egress to other VMs inside the Spark subnet"

  destination_ranges = [var.spark_subnet_cidr]
  target_tags        = [var.spark_network_tag]

  allow { protocol = "tcp" }
  allow { protocol = "udp" }
  allow { protocol = "icmp" }
}

# 2. Spark -> on-prem DB2 (JDBC) over HA VPN.
resource "google_compute_firewall" "spark_to_db2" {
  project     = var.host_project_id
  name        = "fw-allow-spark-egress-db2"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "EGRESS"
  priority    = 1000
  description = "Spark executors -> on-prem DB2 listener(s) via HA VPN"

  destination_ranges = var.db2_server_cidrs
  target_tags        = [var.spark_network_tag]

  allow {
    protocol = "tcp"
    ports    = var.db2_ports
  }

  log_config { metadata = "INCLUDE_ALL_METADATA" }
}

# 3. Spark -> Google APIs VIP (GCS, Secret Manager, Logging, Artifact Registry, Dataproc control plane).
resource "google_compute_firewall" "spark_to_google_apis" {
  project     = var.host_project_id
  name        = "fw-allow-spark-egress-google-apis"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "EGRESS"
  priority    = 1000
  description = "Spark VMs -> ${var.google_apis_vip}.googleapis.com VIP (Private Google Access)"

  destination_ranges = [local.google_vip.cidr]
  target_tags        = [var.spark_network_tag]

  allow {
    protocol = "tcp"
    ports    = ["443"]
  }
}

# 4. Spark -> metadata server / Cloud DNS resolver (169.254.169.254 is always allowed implicitly,
#    rule kept explicit for clarity when egress lockdown is on).
resource "google_compute_firewall" "spark_to_metadata" {
  project     = var.host_project_id
  name        = "fw-allow-spark-egress-metadata"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "EGRESS"
  priority    = 1000
  description = "Spark VMs -> metadata server and DNS"

  destination_ranges = ["169.254.169.254/32"]
  target_tags        = [var.spark_network_tag]

  allow {
    protocol = "tcp"
    ports    = ["53", "80"]
  }
  allow {
    protocol = "udp"
    ports    = ["53"]
  }
}

# 5. Optional ICMP from on-prem for troubleshooting connectivity (ping/traceroute).
resource "google_compute_firewall" "onprem_icmp" {
  project     = var.host_project_id
  name        = "fw-allow-onprem-icmp-to-spark"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "INGRESS"
  priority    = 1100
  description = "ICMP from on-prem to the Spark subnet for diagnostics"

  source_ranges = var.onprem_cidrs
  target_tags   = [var.spark_network_tag]

  allow { protocol = "icmp" }
}

# 6. Default-deny egress for Spark VMs (everything not explicitly allowed above).
resource "google_compute_firewall" "spark_deny_all_egress" {
  count       = var.enable_egress_lockdown ? 1 : 0
  project     = var.host_project_id
  name        = "fw-deny-spark-egress-all"
  network     = data.google_compute_network.shared_vpc.id
  direction   = "EGRESS"
  priority    = 65000
  description = "Deny all other egress from Spark VMs (no internet, no lateral movement)"

  destination_ranges = ["0.0.0.0/0"]
  target_tags        = [var.spark_network_tag]

  deny { protocol = "all" }

  log_config { metadata = "INCLUDE_ALL_METADATA" }
}
