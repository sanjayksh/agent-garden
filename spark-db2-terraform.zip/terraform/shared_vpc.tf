#############################################
# Shared VPC host / service project wiring
#############################################
resource "google_compute_shared_vpc_host_project" "host" {
  count   = var.enable_shared_vpc_host ? 1 : 0
  project = var.host_project_id
}

resource "google_compute_shared_vpc_service_project" "spark" {
  count           = var.attach_service_project ? 1 : 0
  host_project    = var.host_project_id
  service_project = var.service_project_id

  depends_on = [google_compute_shared_vpc_host_project.host]
}

# Subnet-level (not project-level) networkUser - least privilege.
# 1. Dataproc service agent of the service project  -> creates the Spark VMs in the shared subnet
# 2. Google APIs service agent                       -> managed instance operations
# 3. Spark runtime service account                   -> runs on the VMs
resource "google_compute_subnetwork_iam_member" "spark_network_users" {
  for_each = {
    dataproc_agent = local.dataproc_service_agent
    apis_agent     = local.google_apis_agent
    runtime_sa     = "serviceAccount:${google_service_account.spark_runtime.email}"
  }

  project    = var.host_project_id
  region     = var.region
  subnetwork = google_compute_subnetwork.spark.name
  role       = "roles/compute.networkUser"
  member     = each.value

  depends_on = [google_project_service.service_apis]
}
