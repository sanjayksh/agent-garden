#############################################
# HA VPN + Cloud Router (host project)
# Topology: 1 HA VPN gateway (2 interfaces) -> 2 tunnels -> on-prem peer (1 or 2 interfaces)
# Satisfies the 99.99% HA VPN SLA.
#############################################

resource "google_compute_ha_vpn_gateway" "onprem" {
  project    = var.host_project_id
  name       = "havpn-gw-onprem-${var.region}"
  region     = var.region
  network    = data.google_compute_network.shared_vpc.id
  stack_type = "IPV4_ONLY"
}

resource "google_compute_external_vpn_gateway" "onprem" {
  project         = var.host_project_id
  name            = "peer-gw-onprem-datacenter"
  redundancy_type = length(var.peer_vpn_gateway_ips) == 2 ? "TWO_IPS_REDUNDANCY" : "SINGLE_IP_INTERNALLY_REDUNDANT"
  description     = "On-premises VPN device(s) in front of the DB2 / Autosys network"
  labels          = var.labels

  dynamic "interface" {
    for_each = var.peer_vpn_gateway_ips
    content {
      id         = interface.key
      ip_address = interface.value
    }
  }
}

resource "google_compute_router" "onprem" {
  project = var.host_project_id
  name    = "cr-havpn-onprem-${var.region}"
  region  = var.region
  network = data.google_compute_network.shared_vpc.id

  bgp {
    asn                = var.cloud_router_asn
    advertise_mode     = "CUSTOM"
    advertised_groups  = ["ALL_SUBNETS"]
    keepalive_interval = 20

    dynamic "advertised_ip_ranges" {
      for_each = local.advertised_ranges
      content {
        range       = advertised_ip_ranges.key
        description = advertised_ip_ranges.value
      }
    }
  }
}

# Pre-shared key: generated, stored in Secret Manager for hand-off to the on-prem network team.
resource "random_password" "vpn_psk" {
  for_each = local.tunnels
  length   = 32
  special  = false
}

resource "google_secret_manager_secret" "vpn_psk" {
  for_each  = local.tunnels
  project   = var.host_project_id
  secret_id = "${each.value.name}-psk"
  labels    = var.labels

  replication {
    user_managed {
      replicas { location = var.region }
    }
  }
}

resource "google_secret_manager_secret_version" "vpn_psk" {
  for_each    = local.tunnels
  secret      = google_secret_manager_secret.vpn_psk[each.key].id
  secret_data = random_password.vpn_psk[each.key].result
}

resource "google_compute_vpn_tunnel" "onprem" {
  for_each = local.tunnels

  project                         = var.host_project_id
  name                            = each.value.name
  region                          = var.region
  vpn_gateway                     = google_compute_ha_vpn_gateway.onprem.id
  vpn_gateway_interface           = each.value.ha_interface
  peer_external_gateway           = google_compute_external_vpn_gateway.onprem.id
  peer_external_gateway_interface = each.value.peer_interface
  shared_secret                   = random_password.vpn_psk[each.key].result
  router                          = google_compute_router.onprem.id
  ike_version                     = 2
  labels                          = var.labels
}

resource "google_compute_router_interface" "onprem" {
  for_each = local.tunnels

  project    = var.host_project_id
  name       = "if-${each.value.name}"
  region     = var.region
  router     = google_compute_router.onprem.name
  ip_range   = each.value.bgp_ip_cidr
  vpn_tunnel = google_compute_vpn_tunnel.onprem[each.key].name
}

resource "google_compute_router_peer" "onprem" {
  for_each = local.tunnels

  project         = var.host_project_id
  name            = "bgp-${each.value.name}"
  region          = var.region
  router          = google_compute_router.onprem.name
  interface       = google_compute_router_interface.onprem[each.key].name
  peer_ip_address = each.value.bgp_peer_ip
  peer_asn        = var.peer_asn
  # Active/active (equal priority, ECMP) by default; active/passive makes tunnel 1 standby.
  advertised_route_priority = var.vpn_active_active ? 100 : 100 + tonumber(each.key) * 100

  bfd {
    session_initialization_mode = var.enable_bfd ? "ACTIVE" : "DISABLED"
    min_receive_interval        = 1000
    min_transmit_interval       = 1000
    multiplier                  = 5
  }
}
