"""
PySpark job: read from on-prem DB2, transform, write back to DB2 (idempotent staging + MERGE).
Runs on Managed Service for Apache Spark (serverless) in the service project, reaching DB2 over HA VPN.
"""
import argparse
import json

from google.cloud import secretmanager
from pyspark.sql import SparkSession, functions as F

DB2_DRIVER = "com.ibm.db2.jcc.DB2Driver"


def get_db2_config(secret_name: str) -> dict:
    """Secret payload: {"host":"db2p.corp.acme.com","port":50001,"database":"PRODDB","user":"...","password":"...",
                        "standby_host":"db2s.corp.acme.com"}"""
    client = secretmanager.SecretManagerServiceClient()
    payload = client.access_secret_version(name=f"{secret_name}/versions/latest").payload.data
    return json.loads(payload.decode("utf-8"))


def jdbc_url(cfg: dict) -> str:
    # sslConnection=true -> TLS on 50001; client reroute -> automatic failover to the HADR standby.
    return (
        f"jdbc:db2://{cfg['host']}:{cfg['port']}/{cfg['database']}:"
        "sslConnection=true;"
        f"clientRerouteAlternateServerName={cfg.get('standby_host', cfg['host'])};"
        f"clientRerouteAlternatePortNumber={cfg['port']};"
        "maxRetriesForClientReroute=3;retryIntervalForClientReroute=10;"
        "blockingReadConnectionTimeout=600;loginTimeout=30;"
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-date", required=True)
    ap.add_argument("--job", required=True)
    ap.add_argument("--secret", default="projects/acme-data-spark-prod/secrets/sparkdb2-db2-credentials")
    args = ap.parse_args()

    spark = SparkSession.builder.appName(f"db2-pipeline-{args.job}-{args.run_date}").getOrCreate()
    cfg = get_db2_config(args.secret)
    url = jdbc_url(cfg)
    props = {"user": cfg["user"], "password": cfg["password"], "driver": DB2_DRIVER}

    # ---- Parallel, bounded read (numPartitions == max concurrent DB2 connections) ----
    src = (
        spark.read.format("jdbc")
        .option("url", url)
        .option("dbtable", f"(SELECT * FROM SALES.ORDERS WHERE ORDER_DATE = '{args.run_date}') AS T")
        .option("partitionColumn", "ORDER_ID")
        .option("lowerBound", "1")
        .option("upperBound", "50000000")
        .option("numPartitions", "8")
        .option("fetchsize", "10000")
        .options(**props)
        .load()
    )

    out = (
        src.filter(F.col("STATUS") != "CANCELLED")
        .groupBy("ORDER_DATE", "REGION_CD")
        .agg(F.sum("AMOUNT").alias("TOTAL_AMOUNT"), F.count("*").alias("ORDER_CNT"))
        .withColumn("LOAD_TS", F.current_timestamp())
    )

    # ---- Write to a staging table (truncate+insert -> re-runnable) ----
    (
        out.coalesce(4)
        .write.format("jdbc")
        .option("url", url)
        .option("dbtable", "STG.DAILY_SALES_SUMMARY")
        .option("truncate", "true")
        .option("batchsize", "5000")
        .option("isolationLevel", "READ_COMMITTED")
        .options(**props)
        .mode("overwrite")
        .save()
    )

    # ---- Single-statement MERGE from staging into target (atomic, idempotent) ----
    jvm = spark.sparkContext._gateway.jvm
    conn = jvm.java.sql.DriverManager.getConnection(url, cfg["user"], cfg["password"])
    try:
        conn.setAutoCommit(False)
        stmt = conn.createStatement()
        stmt.executeUpdate(
            """
            MERGE INTO MART.DAILY_SALES_SUMMARY T
            USING STG.DAILY_SALES_SUMMARY S
              ON T.ORDER_DATE = S.ORDER_DATE AND T.REGION_CD = S.REGION_CD
            WHEN MATCHED THEN UPDATE SET TOTAL_AMOUNT = S.TOTAL_AMOUNT, ORDER_CNT = S.ORDER_CNT, LOAD_TS = S.LOAD_TS
            WHEN NOT MATCHED THEN INSERT (ORDER_DATE, REGION_CD, TOTAL_AMOUNT, ORDER_CNT, LOAD_TS)
                 VALUES (S.ORDER_DATE, S.REGION_CD, S.TOTAL_AMOUNT, S.ORDER_CNT, S.LOAD_TS)
            """
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    spark.stop()


if __name__ == "__main__":
    main()
