#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Autosys command-job wrapper: submits a serverless Spark batch through the
# Dataproc REST API (over HA VPN -> restricted.googleapis.com), waits for it,
# and maps the final state to an exit code Autosys understands.
#
#   0 = SUCCEEDED   1 = FAILED   2 = CANCELLED   3 = TIMEOUT   4 = SUBMIT ERROR
#
# Autosys JIL example:
#   insert_job: DB2_SPARK_DAILY   job_type: CMD
#   machine: autosys-agent-01
#   command: /opt/spark-jobs/submit_spark_batch.sh daily-load %%RUN_DATE%%
#   std_out_file: /var/log/autosys/$AUTO_JOB_NAME.$AUTORUN.out
#   std_err_file: /var/log/autosys/$AUTO_JOB_NAME.$AUTORUN.err
#   term_run_time: 240
# -----------------------------------------------------------------------------
set -euo pipefail

JOB_NAME="${1:?job name required}"
RUN_DATE="${2:-$(date +%Y-%m-%d)}"

# shellcheck source=/dev/null
source /opt/spark-jobs/env.conf   # PROJECT, REGION, SUBNET_URI, RUNTIME_SA, IMAGE, CODE_BUCKET, STAGING_BUCKET, WIF_CRED_FILE, NETWORK_TAG
POLL_SECONDS="${POLL_SECONDS:-30}"
MAX_WAIT_SECONDS="${MAX_WAIT_SECONDS:-14400}"

API="https://dataproc.googleapis.com/v1/projects/${PROJECT}/locations/${REGION}/batches"

# Deterministic batch ID from the Autosys run number -> safe re-submission (idempotent).
RAW_ID="${JOB_NAME}-${RUN_DATE}-${AUTORUN:-$(date +%H%M%S)}"
BATCH_ID="$(echo "${RAW_ID}" | tr '[:upper:]_' '[:lower:]-' | tr -cd 'a-z0-9-' | cut -c1-63)"

log() { echo "$(date -u +%FT%TZ) [${BATCH_ID}] $*"; }

# --- Auth: Workload Identity Federation (no service-account keys on the host) ---
token() {
  CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${WIF_CRED_FILE}" gcloud auth print-access-token --quiet
}

# --- Cancel the batch if Autosys kills the job (KILLJOB / term_run_time) ---
cancel_batch() {
  log "Received termination signal - cancelling batch"
  curl -sS -X POST -H "Authorization: Bearer $(token)" "${API}/${BATCH_ID}:cancel" >/dev/null || true
  exit 2
}
trap cancel_batch SIGTERM SIGINT

read -r -d '' BODY <<JSON || true
{
  "pysparkBatch": {
    "mainPythonFileUri": "gs://${CODE_BUCKET}/jobs/db2_pipeline/main.py",
    "pythonFileUris": ["gs://${CODE_BUCKET}/jobs/db2_pipeline/libs.zip"],
    "args": ["--run-date=${RUN_DATE}", "--job=${JOB_NAME}"]
  },
  "runtimeConfig": {
    "version": "2.2",
    "containerImage": "${IMAGE}",
    "properties": {
      "spark.dynamicAllocation.maxExecutors": "10",
      "spark.executor.cores": "4",
      "spark.driver.cores": "4"
    }
  },
  "environmentConfig": {
    "executionConfig": {
      "subnetworkUri": "${SUBNET_URI}",
      "serviceAccount": "${RUNTIME_SA}",
      "networkTags": ["${NETWORK_TAG}"],
      "stagingBucket": "${STAGING_BUCKET}",
      "ttl": "14400s"
    }
  },
  "labels": {"autosys-job": "$(echo "${JOB_NAME}" | tr '[:upper:]_' '[:lower:]-')", "run-date": "${RUN_DATE}"}
}
JSON

log "Submitting batch to ${API}"
HTTP_CODE=$(curl -sS -o /tmp/submit.$$ -w '%{http_code}' -X POST \
  -H "Authorization: Bearer $(token)" -H "Content-Type: application/json" \
  "${API}?batchId=${BATCH_ID}&requestId=${BATCH_ID}" -d "${BODY}")

case "${HTTP_CODE}" in
  200) log "Batch accepted" ;;
  409) log "Batch already exists (Autosys re-run) - attaching to existing batch" ;;
  *)   log "Submit failed HTTP ${HTTP_CODE}: $(cat /tmp/submit.$$)"; rm -f /tmp/submit.$$; exit 4 ;;
esac
rm -f /tmp/submit.$$

ELAPSED=0
while (( ELAPSED < MAX_WAIT_SECONDS )); do
  STATE=$(curl -sS -H "Authorization: Bearer $(token)" "${API}/${BATCH_ID}" \
          | python3 -c 'import sys,json; print(json.load(sys.stdin).get("state","UNKNOWN"))')
  log "state=${STATE}"
  case "${STATE}" in
    SUCCEEDED) exit 0 ;;
    FAILED)    exit 1 ;;
    CANCELLED) exit 2 ;;
  esac
  sleep "${POLL_SECONDS}" & wait $!
  ELAPSED=$(( ELAPSED + POLL_SECONDS ))
done

log "Timed out after ${MAX_WAIT_SECONDS}s - cancelling"
curl -sS -X POST -H "Authorization: Bearer $(token)" "${API}/${BATCH_ID}:cancel" >/dev/null || true
exit 3
