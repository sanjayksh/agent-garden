#############################################
# Service project: APIs
#############################################
resource "google_project_service" "service_apis" {
  for_each = toset([
    "dataproc.googleapis.com",
    "compute.googleapis.com",
    "storage.googleapis.com",
    "secretmanager.googleapis.com",
    "artifactregistry.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com",
    "iam.googleapis.com",
    "iamcredentials.googleapis.com",
    "sts.googleapis.com",
  ])
  project            = var.service_project_id
  service            = each.value
  disable_on_destroy = false
}

resource "google_project_service" "host_apis" {
  for_each = toset([
    "compute.googleapis.com",
    "dns.googleapis.com",
    "secretmanager.googleapis.com",
  ])
  project            = var.host_project_id
  service            = each.value
  disable_on_destroy = false
}

#############################################
# Service accounts
#############################################

# Identity the Spark driver/executors run as.
resource "google_service_account" "spark_runtime" {
  project      = var.service_project_id
  account_id   = "sa-${var.name_prefix}-runtime"
  display_name = "Spark runtime SA - DB2 pipeline"
}

# Identity Autosys uses (via WIF impersonation) to submit/poll/cancel batches.
resource "google_service_account" "autosys_submitter" {
  project      = var.service_project_id
  account_id   = "sa-${var.name_prefix}-submitter"
  display_name = "Autosys batch submitter SA"
}

resource "google_project_iam_member" "runtime_roles" {
  for_each = toset([
    "roles/dataproc.worker",
    "roles/logging.logWriter",
    "roles/monitoring.metricWriter",
  ])
  project = var.service_project_id
  role    = each.value
  member  = "serviceAccount:${google_service_account.spark_runtime.email}"
}

# Least-privilege custom role for Autosys: create / get / list / cancel batches only.
resource "google_project_iam_custom_role" "batch_submitter" {
  project     = var.service_project_id
  role_id     = "${replace(var.name_prefix, "-", "_")}_batchSubmitter"
  title       = "Spark Batch Submitter (Autosys)"
  description = "Submit and monitor serverless Spark batches"
  permissions = [
    "dataproc.batches.create",
    "dataproc.batches.get",
    "dataproc.batches.list",
    "dataproc.batches.cancel",
    "dataproc.operations.get",
    "dataproc.operations.list",
  ]
}

resource "google_project_iam_member" "submitter_role" {
  project = var.service_project_id
  role    = google_project_iam_custom_role.batch_submitter.id
  member  = "serviceAccount:${google_service_account.autosys_submitter.email}"
}

# Submitter may attach (actAs) the runtime SA to batches.
resource "google_service_account_iam_member" "submitter_actas_runtime" {
  service_account_id = google_service_account.spark_runtime.name
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${google_service_account.autosys_submitter.email}"
}

#############################################
# Workload Identity Federation for on-prem Autosys (no SA keys)
#############################################
resource "google_iam_workload_identity_pool" "onprem" {
  count                     = var.enable_wif ? 1 : 0
  project                   = var.service_project_id
  workload_identity_pool_id = "wif-onprem-autosys"
  display_name              = "On-prem Autosys"
  description               = "Federated identities for on-prem schedulers"
}

resource "google_iam_workload_identity_pool_provider" "onprem_oidc" {
  count                              = var.enable_wif ? 1 : 0
  project                            = var.service_project_id
  workload_identity_pool_id          = google_iam_workload_identity_pool.onprem[0].workload_identity_pool_id
  workload_identity_pool_provider_id = "onprem-idp-oidc"
  display_name                       = "On-prem IdP (OIDC)"

  attribute_mapping = {
    "google.subject" = "assertion.sub"
  }
  attribute_condition = "assertion.sub == \"${var.wif_autosys_subject}\""

  oidc {
    issuer_uri        = var.wif_oidc_issuer_uri
    allowed_audiences = var.wif_allowed_audiences
  }
}

resource "google_service_account_iam_member" "wif_impersonate_submitter" {
  count              = var.enable_wif ? 1 : 0
  service_account_id = google_service_account.autosys_submitter.name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principal://iam.googleapis.com/${google_iam_workload_identity_pool.onprem[0].name}/subject/${var.wif_autosys_subject}"
}

#############################################
# Storage: code/artifacts + staging/temp
#############################################
resource "google_storage_bucket" "code" {
  project                     = var.service_project_id
  name                        = "${var.service_project_id}-${var.name_prefix}-code"
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  labels                      = var.labels

  versioning { enabled = true }
}

resource "google_storage_bucket" "staging" {
  project                     = var.service_project_id
  name                        = "${var.service_project_id}-${var.name_prefix}-staging"
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  labels                      = var.labels

  lifecycle_rule {
    condition { age = 14 }
    action { type = "Delete" }
  }
}

resource "google_storage_bucket_iam_member" "runtime_code_reader" {
  bucket = google_storage_bucket.code.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.spark_runtime.email}"
}

resource "google_storage_bucket_iam_member" "runtime_staging_admin" {
  bucket = google_storage_bucket.staging.name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.spark_runtime.email}"
}

#############################################
# Secret Manager: DB2 credentials (value loaded out-of-band, never in TF state)
#############################################
resource "google_secret_manager_secret" "db2_credentials" {
  project   = var.service_project_id
  secret_id = "${var.name_prefix}-db2-credentials"
  labels    = var.labels

  replication {
    user_managed {
      replicas { location = var.region }
    }
  }

  depends_on = [google_project_service.service_apis]
}

resource "google_secret_manager_secret_iam_member" "runtime_db2_secret" {
  project   = var.service_project_id
  secret_id = google_secret_manager_secret.db2_credentials.secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.spark_runtime.email}"
}

#############################################
# Artifact Registry: custom Spark container (DB2 JDBC driver + Python deps baked in)
#############################################
resource "google_artifact_registry_repository" "spark_images" {
  project       = var.service_project_id
  location      = var.region
  repository_id = "${var.name_prefix}-spark-images"
  format        = "DOCKER"
  description   = "Custom container images for serverless Spark (IBM DB2 JDBC driver baked in)"
  labels        = var.labels

  depends_on = [google_project_service.service_apis]
}

resource "google_artifact_registry_repository_iam_member" "runtime_reader" {
  for_each = {
    runtime  = "serviceAccount:${google_service_account.spark_runtime.email}"
    dataproc = local.dataproc_service_agent
  }
  project    = var.service_project_id
  location   = var.region
  repository = google_artifact_registry_repository.spark_images.name
  role       = "roles/artifactregistry.reader"
  member     = each.value
}
