terraform {
  required_version = ">= 1.5.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = ">= 6.0, < 8.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.5"
    }
  }

  # Remote state - bucket must exist before `terraform init`.
  # backend "gcs" {
  #   bucket = "tf-state-<org>-network"
  #   prefix = "spark-db2-hybrid"
  # }
}

provider "google" {
  region = var.region
}
