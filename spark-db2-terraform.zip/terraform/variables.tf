#############################################
# Projects / region
#############################################
variable "host_project_id" {
  description = "Shared VPC host project that owns the VPC, subnets, firewall, Cloud Router and HA VPN."
  type        = string
}

variable "service_project_id" {
  description = "Service project where the Spark batch workloads run."
  type        = string
}

variable "region" {
  description = "Region for the subnet, Cloud Router, HA VPN and Spark workloads."
  type        = string
  default     = "northamerica-northeast1"
}

variable "enable_shared_vpc_host" {
  description = "Set true only if the host project is NOT yet enabled as a Shared VPC host."
  type        = bool
  default     = false
}

variable "attach_service_project" {
  description = "Attach the service project to the Shared VPC host (set false if already attached)."
  type        = bool
  default     = true
}

variable "labels" {
  description = "Common labels applied to all labellable resources."
  type        = map(string)
  default = {
    app         = "spark-db2-pipeline"
    environment = "prod"
    managed_by  = "terraform"
  }
}

#############################################
# Network
#############################################
variable "vpc_name" {
  description = "Name of the EXISTING Shared VPC network in the host project."
  type        = string
}

variable "spark_subnet_name" {
  description = "Name of the subnet dedicated to Spark serverless workloads."
  type        = string
  default     = "snet-spark-batch"
}

variable "spark_subnet_cidr" {
  description = "Primary CIDR for the Spark subnet. Must not overlap on-prem ranges. /22 gives ~1,000 IPs (driver + executors across concurrent batches)."
  type        = string
  default     = "10.120.0.0/22"
}

variable "spark_network_tag" {
  description = "Network tag set on Spark batches (execution_config.network_tags); used to target firewall rules."
  type        = string
  default     = "spark-batch"
}

variable "onprem_cidrs" {
  description = "On-premises CIDR ranges reachable over the HA VPN (DB2 servers, Autosys hosts, DNS servers)."
  type        = list(string)
}

variable "db2_server_cidrs" {
  description = "Narrow CIDRs/hosts of the DB2 servers (used for the DB2 egress rule)."
  type        = list(string)
}

variable "db2_ports" {
  description = "DB2 listener ports. 50000 = plain TCP, 50001 = SSL/TLS (recommended)."
  type        = list(string)
  default     = ["50001"]
}

variable "google_apis_vip" {
  description = "Which Private Google Access VIP to use: 'restricted' (VPC-SC compatible) or 'private'."
  type        = string
  default     = "restricted"
  validation {
    condition     = contains(["restricted", "private"], var.google_apis_vip)
    error_message = "google_apis_vip must be 'restricted' or 'private'."
  }
}

variable "enable_egress_lockdown" {
  description = "Create a low-priority deny-all egress rule for Spark VMs so only explicitly allowed flows leave the subnet."
  type        = bool
  default     = true
}

variable "enable_flow_logs" {
  description = "Enable VPC flow logs on the Spark subnet."
  type        = bool
  default     = true
}

#############################################
# HA VPN / Cloud Router
#############################################
variable "cloud_router_asn" {
  description = "Private ASN for the GCP Cloud Router."
  type        = number
  default     = 64514
}

variable "peer_asn" {
  description = "ASN of the on-premises VPN/BGP device(s)."
  type        = number
  default     = 65010
}

variable "peer_vpn_gateway_ips" {
  description = "Public IPs of the on-prem VPN device interfaces. 1 IP (single device) or 2 IPs (two devices / interfaces). Both give 2 tunnels for the 99.99% SLA."
  type        = list(string)
  validation {
    condition     = length(var.peer_vpn_gateway_ips) == 1 || length(var.peer_vpn_gateway_ips) == 2
    error_message = "Provide 1 or 2 peer VPN gateway IPs."
  }
}

variable "bgp_link_local_ranges" {
  description = "Link-local /30 per tunnel. GCP side uses .1, on-prem side uses .2."
  type        = list(string)
  default     = ["169.254.10.0/30", "169.254.20.0/30"]
}

variable "enable_bfd" {
  description = "Enable BFD on the BGP sessions (on-prem device must support it)."
  type        = bool
  default     = false
}

variable "vpn_active_active" {
  description = "true = both tunnels carry traffic (ECMP). false = tunnel 1 is standby (use if on-prem stateful firewalls cannot handle asymmetric flows)."
  type        = bool
  default     = true
}

variable "additional_advertised_ranges" {
  description = "Extra custom ranges advertised to on-prem besides all subnets, the Google APIs VIP and the Cloud DNS forwarding range."
  type        = map(string)
  default     = {}
}

#############################################
# DNS
#############################################
variable "onprem_dns_domain" {
  description = "On-prem DNS domain that holds the DB2 hostnames (e.g. corp.example.com)."
  type        = string
}

variable "onprem_dns_servers" {
  description = "On-prem DNS server IPs used as forwarding targets for onprem_dns_domain."
  type        = list(string)
}

#############################################
# Service project workload resources
#############################################
variable "name_prefix" {
  description = "Short prefix for resource names (lowercase, no spaces)."
  type        = string
  default     = "sparkdb2"
}

variable "enable_wif" {
  description = "Create a Workload Identity Federation pool/provider so on-prem Autosys can authenticate without SA keys."
  type        = bool
  default     = true
}

variable "wif_oidc_issuer_uri" {
  description = "OIDC issuer URI of the on-prem IdP (e.g. ADFS / Entra ID / Ping) that issues tokens to the Autosys service identity."
  type        = string
  default     = ""
}

variable "wif_allowed_audiences" {
  description = "Allowed audiences for the OIDC tokens."
  type        = list(string)
  default     = []
}

variable "wif_autosys_subject" {
  description = "The 'sub' claim of the Autosys service identity token that may impersonate the submitter SA."
  type        = string
  default     = ""
}
