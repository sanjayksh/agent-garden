output "spark_subnet_self_link" {
  description = "Use as environment_config.execution_config.subnetwork_uri when submitting batches."
  value       = google_compute_subnetwork.spark.self_link
}

output "ha_vpn_gateway_public_ips" {
  description = "Give these to the on-prem network team (peer IPs for their VPN devices)."
  value       = [for i in google_compute_ha_vpn_gateway.onprem.vpn_interfaces : i.ip_address]
}

output "onprem_bgp_configuration" {
  description = "Per-tunnel parameters the on-prem side must configure."
  value = {
    for k, t in local.tunnels : t.name => {
      gcp_vpn_public_ip   = google_compute_ha_vpn_gateway.onprem.vpn_interfaces[t.ha_interface].ip_address
      onprem_public_ip    = var.peer_vpn_gateway_ips[t.peer_interface]
      gcp_bgp_ip          = cidrhost(var.bgp_link_local_ranges[tonumber(k)], 1)
      onprem_bgp_ip       = t.bgp_peer_ip
      gcp_asn             = var.cloud_router_asn
      onprem_asn          = var.peer_asn
      ike_version         = 2
      psk_secret_resource = google_secret_manager_secret.vpn_psk[k].id
    }
  }
}

output "dns_inbound_forwarder_ips" {
  description = "On-prem DNS must conditionally forward googleapis.com / pkg.dev / gcr.io to these IPs."
  value       = [for a in data.google_compute_addresses.dns_inbound.addresses : a.address]
}

output "spark_runtime_service_account" {
  value = google_service_account.spark_runtime.email
}

output "autosys_submitter_service_account" {
  value = google_service_account.autosys_submitter.email
}

output "wif_provider_name" {
  description = "Audience / provider resource for the WIF credential configuration file on the Autosys agent."
  value       = var.enable_wif ? google_iam_workload_identity_pool_provider.onprem_oidc[0].name : null
}

output "code_bucket" {
  value = google_storage_bucket.code.name
}

output "staging_bucket" {
  value = google_storage_bucket.staging.name
}

output "spark_image_repo" {
  value = "${var.region}-docker.pkg.dev/${var.service_project_id}/${google_artifact_registry_repository.spark_images.repository_id}"
}

output "db2_secret_id" {
  value = google_secret_manager_secret.db2_credentials.id
}
