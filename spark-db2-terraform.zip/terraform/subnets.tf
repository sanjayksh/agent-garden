#############################################
# Spark subnet in the Shared VPC (host project)
#############################################
resource "google_compute_subnetwork" "spark" {
  project       = var.host_project_id
  name          = var.spark_subnet_name
  region        = var.region
  network       = data.google_compute_network.shared_vpc.id
  ip_cidr_range = var.spark_subnet_cidr
  description   = "Dedicated subnet for Managed Service for Apache Spark (serverless batches) reading/writing on-prem DB2"

  # Mandatory for serverless Spark: VMs have internal IPs only.
  private_ip_google_access = true

  stack_type = "IPV4_ONLY"

  dynamic "log_config" {
    for_each = var.enable_flow_logs ? [1] : []
    content {
      aggregation_interval = "INTERVAL_5_SEC"
      flow_sampling        = 0.5
      metadata             = "INCLUDE_ALL_METADATA"
    }
  }
}

#############################################
# Route for the Google APIs VIP
# Required for Private Google Access when the default internet route has been removed
# (common in enterprise Shared VPCs). Traffic never leaves Google's network.
#############################################
resource "google_compute_route" "google_apis_vip" {
  project          = var.host_project_id
  name             = "rt-${var.google_apis_vip}-googleapis"
  network          = data.google_compute_network.shared_vpc.id
  dest_range       = local.google_vip.cidr
  next_hop_gateway = "default-internet-gateway"
  priority         = 900
  description      = "Route ${var.google_apis_vip}.googleapis.com VIP for Private Google Access"
}
