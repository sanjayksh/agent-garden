locals {
  # Private Google Access VIPs
  google_vip = {
    restricted = {
      cidr     = "199.36.153.4/30"
      hostname = "restricted.googleapis.com."
      ips      = ["199.36.153.4", "199.36.153.5", "199.36.153.6", "199.36.153.7"]
    }
    private = {
      cidr     = "199.36.153.8/30"
      hostname = "private.googleapis.com."
      ips      = ["199.36.153.8", "199.36.153.9", "199.36.153.10", "199.36.153.11"]
    }
  }[var.google_apis_vip]

  # Source range Cloud DNS uses when forwarding queries to on-prem name servers.
  cloud_dns_forwarding_range = "35.199.192.0/19"

  # Domains that must resolve to the Google APIs VIP inside the VPC (and on-prem via inbound forwarding).
  google_api_domains = {
    googleapis = "googleapis.com."
    pkg-dev    = "pkg.dev." # Artifact Registry (custom Spark container images)
    gcr-io     = "gcr.io."
  }

  # Routes advertised by the Cloud Router to on-prem in addition to ALL_SUBNETS.
  advertised_ranges = merge(
    {
      (local.google_vip.cidr)            = "Google APIs VIP (${var.google_apis_vip}.googleapis.com) for on-prem Autosys API calls"
      (local.cloud_dns_forwarding_range) = "Cloud DNS outbound forwarding source range (return path for DNS queries)"
    },
    var.additional_advertised_ranges
  )

  # Tunnel layout: always two tunnels (HA VPN interface 0 and 1) for 99.99% SLA.
  tunnels = {
    for idx in [0, 1] : idx => {
      name           = "vpn-tunnel-onprem-${idx}"
      ha_interface   = idx
      peer_interface = idx % length(var.peer_vpn_gateway_ips)
      bgp_ip_cidr    = "${cidrhost(var.bgp_link_local_ranges[idx], 1)}/30"
      bgp_peer_ip    = cidrhost(var.bgp_link_local_ranges[idx], 2)
    }
  }

  service_project_number = data.google_project.service.number
  dataproc_service_agent = "serviceAccount:service-${local.service_project_number}@dataproc-accounts.iam.gserviceaccount.com"
  google_apis_agent      = "serviceAccount:${local.service_project_number}@cloudservices.gserviceaccount.com"
}

data "google_project" "service" {
  project_id = var.service_project_id
}

data "google_compute_network" "shared_vpc" {
  name    = var.vpc_name
  project = var.host_project_id
}
