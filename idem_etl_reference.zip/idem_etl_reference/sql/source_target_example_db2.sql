-- Example source, staging and target tables (DB2 for LUW syntax).

-- 1) Source: a reliable change column maintained by DB2 itself.
--    ROW CHANGE TIMESTAMP is set by DB2 on every INSERT/UPDATE - applications cannot forget it.
ALTER TABLE APP.ORDERS
  ADD COLUMN LAST_UPD_TS TIMESTAMP NOT NULL
      GENERATED ALWAYS FOR EACH ROW ON UPDATE AS ROW CHANGE TIMESTAMP;
-- (REORG the table afterwards if DB2 puts it in reorg-pending state.)
CREATE INDEX APP.IX_ORDERS_LUT ON APP.ORDERS (LAST_UPD_TS);   -- range scans per window

-- 2) Target: business columns + idempotency metadata.
CREATE TABLE RPT.ORDER_SUMMARY (
    ORDER_ID        BIGINT        NOT NULL,
    CUSTOMER_ID     BIGINT        NOT NULL,
    ORDER_STATUS    VARCHAR(20),
    ORDER_TOTAL     DECIMAL(15,2),
    LAST_UPD_TS     TIMESTAMP,              -- carried from source (version column)
    ROW_HASH        CHAR(64),               -- SHA-256 of business columns
    LAST_RUN_ID     VARCHAR(64),            -- which run last changed the row
    ETL_UPDATED_TS  TIMESTAMP,
    CONSTRAINT PK_ORDER_SUMMARY PRIMARY KEY (ORDER_ID)   -- the natural key MERGE relies on
);

-- 3) Staging: same business columns + ROW_HASH + RUN_ID, no PK (Spark task retries
--    can insert a partition twice; the MERGE source de-duplicates).
CREATE TABLE RPT.ORDER_SUMMARY_STG (
    ORDER_ID        BIGINT        NOT NULL,
    CUSTOMER_ID     BIGINT        NOT NULL,
    ORDER_STATUS    VARCHAR(20),
    ORDER_TOTAL     DECIMAL(15,2),
    LAST_UPD_TS     TIMESTAMP,
    ROW_HASH        CHAR(64),
    RUN_ID          VARCHAR(64)
);
