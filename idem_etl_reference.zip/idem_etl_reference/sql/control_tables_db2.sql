-- ETL control tables for idempotent, watermark-driven jobs (DB2 for LUW / z/OS).
-- Adjust schema, tablespace and security for your site.

CREATE TABLE ETLCTL.ETL_JOB_RUN (
    JOB_NAME       VARCHAR(64)   NOT NULL,
    RUN_KEY        VARCHAR(64)   NOT NULL,   -- logical run identity (e.g. business date)
    RUN_ID         VARCHAR(64)   NOT NULL,   -- unique per attempt (uuid)
    ATTEMPT        INTEGER       NOT NULL,
    STATUS         VARCHAR(16)   NOT NULL,   -- RUNNING | SUCCESS | FAILED
    BATCH_ID       VARCHAR(128),             -- Serverless Spark batch id
    WM_LOW         VARCHAR(40),              -- window processed by this run
    WM_HIGH        VARCHAR(40),
    ROWS_STAGED    BIGINT,
    ROWS_WRITTEN   BIGINT,
    STARTED_TS     TIMESTAMP     NOT NULL,
    HEARTBEAT_TS   TIMESTAMP     NOT NULL,
    ENDED_TS       TIMESTAMP,
    ERROR_MSG      VARCHAR(1000),
    CONSTRAINT PK_ETL_JOB_RUN PRIMARY KEY (JOB_NAME, RUN_KEY),
    CONSTRAINT CK_ETL_JOB_RUN_ST CHECK (STATUS IN ('RUNNING', 'SUCCESS', 'FAILED'))
);

CREATE TABLE ETLCTL.ETL_WATERMARK (
    JOB_NAME       VARCHAR(64)   NOT NULL,
    SOURCE_TABLE   VARCHAR(128)  NOT NULL,
    WM_COLUMN      VARCHAR(128)  NOT NULL,
    WM_TYPE        VARCHAR(16)   NOT NULL,   -- TIMESTAMP | BIGINT
    WM_VALUE       VARCHAR(40)   NOT NULL,   -- last committed high-water mark
    PREV_WM_VALUE  VARCHAR(40),              -- previous value (easy manual rollback)
    LAST_RUN_ID    VARCHAR(64),
    LOCK_RUN_ID    VARCHAR(64),              -- job-level lease holder
    LOCK_TS        TIMESTAMP,
    UPDATED_TS     TIMESTAMP     NOT NULL,
    CONSTRAINT PK_ETL_WATERMARK PRIMARY KEY (JOB_NAME)
);
