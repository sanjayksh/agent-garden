"""Example business transform, plugged in with --transform transforms.orders:transform.

Rules for idempotent transforms:
  * deterministic - no current_timestamp(), rand(), uuid() or monotonically_increasing_id()
    in business columns (the framework stamps ETL_UPDATED_TS inside DB2 instead);
  * keep the business key(s) and the version column in the output;
  * output one row per business key (the framework de-duplicates defensively).
"""
from pyspark.sql import DataFrame
from pyspark.sql import functions as F


def transform(df: DataFrame) -> DataFrame:
    return (df
            .withColumn("ORDER_STATUS", F.upper(F.trim("ORDER_STATUS")))
            .withColumn("ORDER_TOTAL", F.round("ORDER_TOTAL", 2).cast("decimal(15,2)"))
            .where(F.col("ORDER_STATUS") != "TEST"))
