"""Pure-Python checks of the DB2-flavoured SQL (no database needed)."""
from idem_etl.config import JobConfig
from idem_etl.dialect import Db2Dialect
from idem_etl.extract import build_window_query
from idem_etl.watermark import Window, WatermarkStore
from idem_etl.writer import IdempotentWriter


def cfg(**kw):
    base = dict(job_name="ORDERS_DAILY", jdbc_url="jdbc:db2://db2host:50001/PRODDB",
                source_table="APP.ORDERS", watermark_column="LAST_UPD_TS",
                source_columns=["ORDER_ID", "STATUS", "LAST_UPD_TS"],
                target_table="RPT.ORDER_SUMMARY", staging_table="RPT.ORDER_SUMMARY_STG",
                key_columns=["ORDER_ID"], version_column="LAST_UPD_TS")
    base.update(kw)
    return JobConfig(**base)


def test_window_query_is_half_open_and_uses_db2_literals():
    c = cfg(source_filter="REGION = 'WEST'")
    wm = WatermarkStore(None, c, Db2Dialect())
    w = Window("2026-09-23 00:00:00.000000", "2026-09-22 23:45:00.000000",
               "2026-09-24 00:00:00.000000", "TIMESTAMP")
    sql = build_window_query(c, wm, w)
    assert "LAST_UPD_TS > TIMESTAMP('2026-09-22 23:45:00.000000')" in sql
    assert "LAST_UPD_TS <= TIMESTAMP('2026-09-24 00:00:00.000000')" in sql
    assert "WITH UR" not in sql and "(REGION = 'WEST')" in sql


def test_db2_merge_dedupes_source_and_guards_versions():
    c = cfg()
    wr = IdempotentWriter(None, c, Db2Dialect())
    wr._cols = ["ORDER_ID", "STATUS", "LAST_UPD_TS"]
    sql = wr.merge_sql()
    assert sql.startswith("MERGE INTO RPT.ORDER_SUMMARY T USING (SELECT")
    assert "ROW_NUMBER() OVER (PARTITION BY ORDER_ID ORDER BY ROW_HASH DESC)" in sql
    assert "WHEN MATCHED AND (T.ROW_HASH IS NULL OR T.ROW_HASH <> S.ROW_HASH)" in sql
    assert "S.LAST_UPD_TS >= T.LAST_UPD_TS" in sql
    assert "WHEN NOT MATCHED THEN INSERT" in sql


def test_bigint_literal_rejects_injection():
    c = cfg(watermark_type="BIGINT", initial_watermark="0")
    wm = WatermarkStore(None, c, Db2Dialect())
    assert wm.literal("42") == "42"
    try:
        wm.literal("1; DROP TABLE X")
        raise AssertionError("should fail")
    except ValueError:
        pass


def test_invalid_identifier_rejected():
    try:
        cfg(target_table="RPT.T; DELETE FROM X")
        raise AssertionError("should fail")
    except ValueError:
        pass
