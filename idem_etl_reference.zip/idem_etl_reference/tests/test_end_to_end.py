"""End-to-end tests against an in-memory Apache Derby database (bundled with Spark).

Derby stands in for DB2 so the full flow - control tables, JDBC extract, staging,
MERGE, watermark compare-and-set, failure/retry - runs on a laptop or in CI.

    pip install pyspark==3.5.* pytest   &&   pytest -q tests/
"""
from __future__ import annotations

import datetime as dt
import pathlib
import uuid

import pytest
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from idem_etl import IncrementalJob, JobConfig, JobLockedError, RunInProgressError
from idem_etl.db_client import DbClient

ROOT = pathlib.Path(__file__).resolve().parents[1]
DRIVER = "org.apache.derby.jdbc.EmbeddedDriver"


@pytest.fixture(scope="session")
def spark():
    s = (SparkSession.builder.master("local[2]").appName("idem-etl-tests")
         .config("spark.sql.shuffle.partitions", "2")
         .config("spark.ui.enabled", "false")
         .config("spark.sql.session.timeZone", "UTC")
         .getOrCreate())
    yield s
    s.stop()


@pytest.fixture()
def db(spark):
    url = f"jdbc:derby:memory:t{uuid.uuid4().hex[:8]};create=true"
    client = DbClient(spark, url, DRIVER, {})
    client.execute("CREATE SCHEMA ETLCTL")
    for stmt in (ROOT / "sql" / "control_tables_db2.sql").read_text().split(";"):
        body = "\n".join(l for l in stmt.splitlines() if not l.strip().startswith("--"))
        if body.strip():
            client.execute(body)
    client.execute("""CREATE TABLE APP_ORDERS (ORDER_ID BIGINT NOT NULL PRIMARY KEY,
        CUSTOMER_ID BIGINT NOT NULL, ORDER_STATUS VARCHAR(20), ORDER_TOTAL DECIMAL(15,2),
        LAST_UPD_TS TIMESTAMP NOT NULL)""")
    cols = """ORDER_ID BIGINT NOT NULL, CUSTOMER_ID BIGINT NOT NULL, ORDER_STATUS VARCHAR(20),
        ORDER_TOTAL DECIMAL(15,2), LAST_UPD_TS TIMESTAMP, ROW_HASH CHAR(64)"""
    client.execute(f"""CREATE TABLE ORDER_SUMMARY ({cols}, LAST_RUN_ID VARCHAR(64),
        ETL_UPDATED_TS TIMESTAMP, PRIMARY KEY (ORDER_ID))""")
    client.execute(f"CREATE TABLE ORDER_SUMMARY_STG ({cols}, RUN_ID VARCHAR(64))")
    return client


def make_cfg(db, **over) -> JobConfig:
    base = dict(job_name="ORDERS_TEST", jdbc_url=db._url, jdbc_driver=DRIVER, dialect="derby",
                source_table="APP_ORDERS",
                source_columns=["ORDER_ID", "CUSTOMER_ID", "ORDER_STATUS", "ORDER_TOTAL",
                                "LAST_UPD_TS"],
                watermark_column="LAST_UPD_TS", safety_lag_seconds=0,
                target_table="ORDER_SUMMARY", staging_table="ORDER_SUMMARY_STG",
                key_columns=["ORDER_ID"], version_column="LAST_UPD_TS",
                write_partitions=2, read_partitions=2)
    base.update(over)
    return JobConfig(**base)


def ts(minutes_ago: float) -> dt.datetime:
    return dt.datetime.now() - dt.timedelta(minutes=minutes_ago)


def insert_orders(db, rows):
    for r in rows:
        db.execute("INSERT INTO APP_ORDERS VALUES (?, ?, ?, ?, ?)", r)


def target(db):
    return {r["ORDER_ID"]: r for r in db.query("SELECT * FROM ORDER_SUMMARY ORDER BY ORDER_ID")}


def run_row(db, key):
    return db.query("SELECT * FROM ETLCTL.ETL_JOB_RUN WHERE RUN_KEY = ?", (key,))[0]


def wm_value(db):
    return db.query("SELECT WM_VALUE FROM ETLCTL.ETL_WATERMARK")[0]["WM_VALUE"]


# ---------------------------------------------------------------------------
def test_first_load_and_same_key_rerun_is_noop(spark, db):
    insert_orders(db, [(i, 100 + i, "NEW", 10.5 * i, ts(60 - i)) for i in range(1, 6)])
    job = IncrementalJob(spark, make_cfg(db))

    r1 = job.run("2026-09-24")
    assert r1.status == "SUCCESS" and r1.rows_staged == 5 and r1.rows_written == 5
    assert len(target(db)) == 5
    first_wm = wm_value(db)

    r2 = job.run("2026-09-24")                       # scheduler resubmits same run key
    assert r2.status == "SKIPPED"
    assert wm_value(db) == first_wm and len(target(db)) == 5
    assert run_row(db, "2026-09-24")["ATTEMPT"] == 1


def test_incremental_picks_only_new_and_changed_rows(spark, db):
    insert_orders(db, [(i, 100 + i, "NEW", 10.0, ts(60)) for i in range(1, 4)])
    job = IncrementalJob(spark, make_cfg(db))
    job.run("k1")

    db.execute("UPDATE APP_ORDERS SET ORDER_STATUS = 'SHIPPED', LAST_UPD_TS = ? "
               "WHERE ORDER_ID = 2", (dt.datetime.now(),))
    insert_orders(db, [(4, 104, "NEW", 40.0, dt.datetime.now())])
    r = job.run("k2")
    assert r.rows_staged == 2 and r.rows_written == 2
    t = target(db)
    assert t[2]["ORDER_STATUS"] == "SHIPPED" and 4 in t and len(t) == 4
    assert t[1]["LAST_RUN_ID"] != t[2]["LAST_RUN_ID"]


def test_failure_before_commit_leaves_no_trace_and_retry_replays_window(
        spark, db, monkeypatch):
    insert_orders(db, [(i, 1, "NEW", 1.0, ts(30)) for i in range(1, 4)])
    job = IncrementalJob(spark, make_cfg(db))
    start_wm = wm_value(db) if db.query("SELECT 1 FROM ETLCTL.ETL_WATERMARK") else None

    def boom(tx):
        raise RuntimeError("DB2 connection reset")      # crash after staging, in commit
    monkeypatch.setattr(job.writer, "apply", boom)
    with pytest.raises(RuntimeError):
        job.run("k-fail")

    failed = run_row(db, "k-fail")
    assert failed["STATUS"] == "FAILED" and failed["WM_HIGH"]
    assert target(db) == {}                           # nothing half-written
    assert wm_value(db) == "1900-01-01 00:00:00.000000" or wm_value(db) == start_wm
    assert db.query("SELECT LOCK_RUN_ID FROM ETLCTL.ETL_WATERMARK")[0]["LOCK_RUN_ID"] is None

    monkeypatch.undo()
    job2 = IncrementalJob(spark, make_cfg(db))
    r = job2.run("k-fail")                             # scheduler retry
    assert r.status == "SUCCESS" and r.attempt == 2 and len(target(db)) == 3
    assert r.wm_high == failed["WM_HIGH"]             # exact same window replayed


def test_crash_after_commit_rerun_is_harmless(spark, db):
    """Simulate: DB2 commit succeeded but the scheduler never saw the result."""
    insert_orders(db, [(i, 1, "NEW", 1.0, ts(30)) for i in range(1, 4)])
    job = IncrementalJob(spark, make_cfg(db))
    job.run("k1")
    before = target(db)
    forced = job.run("k1", force=True)                # operator forces a re-run
    assert forced.status in ("SUCCESS", "EMPTY") and forced.rows_written == 0
    assert target(db) == before


def test_overlapping_lookback_is_absorbed_by_merge(spark, db):
    insert_orders(db, [(i, 1, "NEW", 1.0, ts(10)) for i in range(1, 6)])
    job = IncrementalJob(spark, make_cfg(db, lookback_seconds=3600))
    job.run("k1")
    r = job.run("k2")                                  # re-reads the same 5 rows
    assert r.rows_staged == 5 and r.rows_written == 0  # hash unchanged -> no updates
    assert len(target(db)) == 5


def test_late_arriving_row_needs_lookback(spark, db):
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db))
    job.run("k1")
    # A long transaction commits a row stamped *before* the watermark:
    insert_orders(db, [(2, 1, "NEW", 1.0, ts(5))])
    job.run("k2")
    assert 2 not in target(db)                         # missed without look-back
    job_lb = IncrementalJob(spark, make_cfg(db, lookback_seconds=900))
    job_lb.run("k3")
    assert 2 in target(db)                             # caught by overlap window


def test_older_replay_cannot_overwrite_newer_target_row(spark, db):
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db))
    job.run("k1")
    db.execute("UPDATE ORDER_SUMMARY SET ORDER_STATUS='CLOSED', LAST_UPD_TS=? "
               "WHERE ORDER_ID=1", (dt.datetime.now() + dt.timedelta(hours=1),))
    db.execute("UPDATE ETLCTL.ETL_WATERMARK SET WM_VALUE='1900-01-01 00:00:00.000000'")
    job.run("k-backfill")                              # reprocess old window
    assert target(db)[1]["ORDER_STATUS"] == "CLOSED"   # version guard held


def test_concurrent_run_of_same_key_is_rejected(spark, db):
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db))
    job.runs.claim("k1", job.db_now())                 # someone else is RUNNING k1
    with pytest.raises(RunInProgressError):
        job.run("k1")


def test_different_key_while_job_lease_held_is_rejected(spark, db):
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db))
    job.wm.ensure_row()
    job.wm.acquire("other-run", job.db_now())          # another key holds the lease
    with pytest.raises(JobLockedError):
        job.run("k2")
    assert run_row(db, "k2")["STATUS"] == "FAILED"     # retryable later


def test_stale_running_attempt_is_taken_over(spark, db):
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db, stale_run_seconds=60))
    old = job.db_now() - dt.timedelta(hours=2)
    job.runs.claim("k1", old)                          # driver died 2h ago
    r = job.run("k1")
    assert r.status == "SUCCESS" and r.attempt == 2


def test_replace_slice_strategy_is_idempotent(spark, db):
    insert_orders(db, [(i, 7 if i < 3 else 8, "NEW", 1.0, ts(10)) for i in range(1, 5)])
    cfg = make_cfg(db, write_strategy="REPLACE_SLICE", slice_column="CUSTOMER_ID",
                   lookback_seconds=3600)
    job = IncrementalJob(spark, cfg)
    job.run("k1")
    job.run("k2")                                      # same rows again
    assert len(target(db)) == 4


def test_transform_hook_and_empty_window(spark, db):
    job = IncrementalJob(spark, make_cfg(db))
    assert job.run("k-empty").status in ("EMPTY", "SUCCESS")
    insert_orders(db, [(1, 1, "new", 1.0, dt.datetime.now())])
    job.run("k1", transform=lambda df: df.withColumn("ORDER_STATUS", F.upper("ORDER_STATUS")))
    assert target(db)[1]["ORDER_STATUS"] == "NEW"


def test_heartbeat_thread_refreshes_run(spark, db):
    import time
    insert_orders(db, [(1, 1, "NEW", 1.0, ts(10))])
    job = IncrementalJob(spark, make_cfg(db, heartbeat_seconds=1))
    orig = job.writer.stage

    def slow_stage(df):
        time.sleep(2.5)
        return orig(df)
    job.writer.stage = slow_stage
    r = job.run("k1")
    row = run_row(db, "k1")
    assert r.status == "SUCCESS" and row["HEARTBEAT_TS"] > row["STARTED_TS"]
