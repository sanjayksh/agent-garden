# idem_etl_reference

Idempotent, watermark-driven DB2 <-> PySpark framework for Serverless Spark.
See the accompanying Word document for design rationale and usage.

- `sql/` – DB2 DDL (control, staging, target)
- `idem_etl/` – framework package (zip and ship via python_file_uris)
- `main.py` – batch entry point
- `scheduler/submit_batch.py` – idempotent submission for the on-prem scheduler
- `tests/` – `pip install pyspark==3.5.* pytest && pytest -q tests/`
