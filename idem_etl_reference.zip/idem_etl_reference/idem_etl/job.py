"""Orchestrates one idempotent, watermark-driven run.

    claim run key -> take job lease -> compute window -> extract -> transform
    -> stage -> [ MERGE + advance watermark + mark SUCCESS ] (one DB2 commit)
"""
from __future__ import annotations

import datetime as dt
import logging
import threading
from dataclasses import asdict, dataclass
from typing import Callable, Optional

from pyspark.sql import DataFrame, SparkSession

from .config import JobConfig
from .db_client import DbClient
from .dialect import get_dialect
from .extract import read_window
from .run_control import RunController
from .watermark import WatermarkStore, Window
from .writer import IdempotentWriter

log = logging.getLogger(__name__)

Transform = Callable[[DataFrame], DataFrame]


@dataclass
class JobResult:
    job_name: str
    run_key: str
    status: str                      # SUCCESS | SKIPPED | EMPTY
    run_id: str
    attempt: int
    wm_low: Optional[str] = None
    wm_high: Optional[str] = None
    rows_staged: int = 0
    rows_written: int = 0

    def as_dict(self):
        return asdict(self)


class _Heartbeat(threading.Thread):
    """Keeps RUNNING rows and the lease fresh so long runs are not taken over."""

    def __init__(self, fn: Callable[[], None], every: int):
        super().__init__(daemon=True, name="etl-heartbeat")
        self._fn, self._every, self._halt = fn, every, threading.Event()

    def run(self):
        while not self._halt.wait(self._every):
            try:
                self._fn()
            except Exception:
                log.warning("Heartbeat failed", exc_info=True)

    def stop(self):
        self._halt.set()


class IncrementalJob:
    def __init__(self, spark: SparkSession, cfg: JobConfig):
        self.spark, self.cfg = spark, cfg
        self.dialect = get_dialect(cfg.dialect)
        self.db = DbClient(spark, cfg.jdbc_url, cfg.jdbc_driver, cfg.jdbc_properties)
        self.runs = RunController(self.db, cfg.run_table, cfg.job_name, cfg.stale_run_seconds)
        self.wm = WatermarkStore(self.db, cfg, self.dialect)
        self.writer = IdempotentWriter(self.db, cfg, self.dialect)

    def db_now(self) -> dt.datetime:
        with self.db.transaction() as tx:
            return tx.scalar(self.dialect.current_timestamp_sql())

    # ------------------------------------------------------------------ run
    def run(self, run_key: str, transform: Transform = lambda df: df,
            batch_id: str = "", force: bool = False) -> JobResult:
        cfg = self.cfg
        self.wm.ensure_row()
        decision = self.runs.claim(run_key, self.db_now(), batch_id, force)
        if decision.action == "SKIP":
            return JobResult(cfg.job_name, run_key, "SKIPPED", decision.run_id, decision.attempt)

        run_id = decision.run_id
        hb = _Heartbeat(lambda: self._beat(run_key, run_id), cfg.heartbeat_seconds)
        hb.start()
        try:
            low = self.wm.acquire(run_id, self.db_now())
            window = self._window(decision, low)
            self.runs.record_window(run_key, run_id, window.low, window.high)
            log.info("Window %s: (%s, %s] read_low=%s", run_key, window.low, window.high,
                     window.read_low)

            if window.is_empty:
                with self.db.transaction() as tx:
                    self.wm.release_in_tx(tx, run_id)
                    self.runs.mark_success(tx, run_key, run_id, 0, 0)
                return JobResult(cfg.job_name, run_key, "EMPTY", run_id, decision.attempt,
                                 window.low, window.high)

            source_df = read_window(self.spark, cfg, self.wm, window)
            out = self.writer.prepare(transform(source_df), run_id)
            staged = self.writer.stage(out)
            written = self._commit(run_key, run_id, window, staged)
            self.writer.cleanup()
            return JobResult(cfg.job_name, run_key, "SUCCESS", run_id, decision.attempt,
                             window.low, window.high, staged, written)
        except Exception as exc:
            self.runs.mark_failed(run_key, run_id, f"{type(exc).__name__}: {exc}")
            self.wm.release(run_id)
            raise
        finally:
            hb.stop()

    # -------------------------------------------------------------- helpers
    def _window(self, decision, low: str) -> Window:
        # A retry of a failed attempt replays the exact same window (deterministic
        # re-run) as long as the committed watermark has not moved since.
        if decision.prior_high and decision.prior_low == low:
            log.info("Replaying window recorded by previous attempt")
            w = self.wm.compute_window(low, self.db_now())
            return Window(low, w.read_low, decision.prior_high, w.wm_type)
        return self.wm.compute_window(low, self.db_now())

    def _commit(self, run_key: str, run_id: str, window: Window, staged: int) -> int:
        """The single atomic step: data + watermark + run status, or nothing."""
        with self.db.transaction() as tx:
            written = self.writer.apply(tx)
            self.wm.advance(tx, window, run_id)
            self.runs.mark_success(tx, run_key, run_id, staged, written)
        log.info("Committed run %s: rows_written=%d new watermark=%s", run_id, written,
                 window.high)
        return written

    def _beat(self, run_key: str, run_id: str) -> None:
        now = self.db_now()
        self.runs.heartbeat(run_key, run_id, now)
        self.wm.heartbeat(run_id, now)
