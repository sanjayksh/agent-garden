"""Job configuration for idempotent, watermark-driven DB2 <-> Spark jobs."""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

_ENV_REF = re.compile(r"\$\{ENV:([A-Za-z_][A-Za-z0-9_]*)\}")
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")


def _resolve_env(value):
    """Replace ${ENV:NAME} placeholders so secrets never live in the config file."""
    if isinstance(value, str):
        return _ENV_REF.sub(lambda m: os.environ[m.group(1)], value)
    return value


def _check_ident(name: str, what: str) -> str:
    if not _IDENT.match(name or ""):
        raise ValueError(f"Invalid SQL identifier for {what}: {name!r}")
    return name


@dataclass
class JobConfig:
    # --- identity -------------------------------------------------------
    job_name: str                               # stable logical name, e.g. ORDERS_DAILY_LOAD

    # --- DB2 connectivity ----------------------------------------------
    jdbc_url: str
    jdbc_driver: str = "com.ibm.db2.jcc.DB2Driver"
    jdbc_properties: Dict[str, str] = field(default_factory=dict)
    dialect: str = "db2"                        # "db2" in production, "derby" for local tests
    control_schema: str = "ETLCTL"              # schema holding ETL_JOB_RUN / ETL_WATERMARK

    # --- source + watermark --------------------------------------------
    source_table: str = ""                      # SCHEMA.TABLE (or view)
    source_columns: List[str] = field(default_factory=lambda: ["*"])
    source_filter: Optional[str] = None         # extra static predicate, optional
    watermark_column: str = ""                  # e.g. LAST_UPD_TS (ROW CHANGE TIMESTAMP)
    watermark_type: str = "TIMESTAMP"           # TIMESTAMP | BIGINT
    initial_watermark: str = "1900-01-01 00:00:00.000000"
    safety_lag_seconds: int = 300               # ignore rows younger than this (in-flight txns)
    lookback_seconds: int = 0                   # re-read overlap; safe because sink is idempotent
    max_window_seconds: Optional[int] = None    # cap a single run's window (backlog catch-up)

    # --- parallel read --------------------------------------------------
    read_partitions: int = 1
    fetch_size: int = 10000

    # --- target / write -------------------------------------------------
    target_table: str = ""
    staging_table: str = ""
    key_columns: List[str] = field(default_factory=list)
    write_strategy: str = "MERGE"               # MERGE | REPLACE_SLICE
    slice_column: Optional[str] = None          # for REPLACE_SLICE, e.g. BUSINESS_DATE
    version_column: Optional[str] = None        # out-of-order guard for MERGE (e.g. SRC_CHANGE_TS)
    hash_exclude_columns: List[str] = field(default_factory=list)
    write_batch_size: int = 5000
    write_partitions: int = 4

    # --- run control ----------------------------------------------------
    stale_run_seconds: int = 1800               # RUNNING with no heartbeat for this long => dead
    heartbeat_seconds: int = 60

    def __post_init__(self):
        self.jdbc_url = _resolve_env(self.jdbc_url)
        self.jdbc_properties = {k: _resolve_env(v) for k, v in self.jdbc_properties.items()}
        for attr in ("source_table", "target_table", "staging_table", "watermark_column",
                     "control_schema"):
            _check_ident(getattr(self, attr), attr)
        for col in self.key_columns:
            _check_ident(col, "key_columns")
        if not self.key_columns:
            raise ValueError("key_columns is required")
        self.watermark_type = self.watermark_type.upper()
        if self.watermark_type not in ("TIMESTAMP", "BIGINT"):
            raise ValueError("watermark_type must be TIMESTAMP or BIGINT")
        self.write_strategy = self.write_strategy.upper()
        if self.write_strategy not in ("MERGE", "REPLACE_SLICE"):
            raise ValueError("write_strategy must be MERGE or REPLACE_SLICE")
        if self.write_strategy == "REPLACE_SLICE" and not self.slice_column:
            raise ValueError("slice_column is required for REPLACE_SLICE")
        if not re.match(r"^[A-Za-z0-9_\-]{1,64}$", self.job_name):
            raise ValueError("job_name must be 1-64 chars of [A-Za-z0-9_-]")

    @property
    def run_table(self) -> str:
        return f"{self.control_schema}.ETL_JOB_RUN"

    @property
    def watermark_table(self) -> str:
        return f"{self.control_schema}.ETL_WATERMARK"

    @classmethod
    def from_json(cls, path: str) -> "JobConfig":
        with open(path, "r", encoding="utf-8") as fh:
            return cls(**json.load(fh))
