"""Thin JDBC client that runs on the Spark *driver* via Py4J.

Spark's DataFrame JDBC API can read and bulk-insert, but it cannot run MERGE,
UPDATE, DELETE or multi-statement transactions. Control-table updates and the
final atomic commit therefore go through this client, re-using the DB2 JCC jar
that is already on the Spark classpath (no extra Python driver to install on
Serverless Spark).
"""
from __future__ import annotations

import datetime as dt
import logging
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional, Sequence

log = logging.getLogger(__name__)

TS_FMT = "%Y-%m-%d %H:%M:%S.%f"
_JDBC_TIMESTAMP_TYPES = (93, 2014)          # TIMESTAMP, TIMESTAMP_WITH_TIMEZONE
_DUPLICATE_KEY_SQLSTATE = "23505"


class DuplicateKeyError(Exception):
    """Raised when an INSERT violates a primary key / unique constraint."""


def parse_ts(value: str) -> dt.datetime:
    value = value.strip().replace("T", " ")
    if "." in value:
        head, frac = value.split(".", 1)
        value = f"{head}.{frac[:6].ljust(6, '0')}"   # java.sql.Timestamp has 9 digits
    else:
        value = f"{value}.000000"
    return dt.datetime.strptime(value, TS_FMT)


def fmt_ts(value: dt.datetime) -> str:
    return value.strftime(TS_FMT)


class DbClient:
    def __init__(self, spark, url: str, driver: str, properties: Dict[str, str]):
        self._jvm = spark.sparkContext._jvm
        self._gw = spark.sparkContext._gateway
        self._url = url
        self._driver = driver
        self._props = properties

    # ------------------------------------------------------------------ connect
    def connect(self):
        jprops = self._jvm.java.util.Properties()
        for k, v in self._props.items():
            jprops.setProperty(k, str(v))
        try:
            # Loads the driver through Spark's class loader (jars added via --jars /
            # jarFileUris), avoiding "No suitable driver" from DriverManager.
            drv = self._jvm.org.apache.spark.sql.execution.datasources.jdbc.DriverRegistry.get(
                self._driver)
            conn = drv.connect(self._url, jprops)
        except Exception:  # pragma: no cover - fallback for unusual runtimes
            self._jvm.java.lang.Class.forName(self._driver)
            conn = self._jvm.java.sql.DriverManager.getConnection(self._url, jprops)
        if conn is None:
            raise RuntimeError(f"Driver {self._driver} rejected URL {self._url}")
        return conn

    @contextmanager
    def transaction(self) -> Iterator["Tx"]:
        """One DB2 unit of work: commit on success, rollback on any exception."""
        conn = self.connect()
        conn.setAutoCommit(False)
        tx = Tx(self, conn)
        try:
            yield tx
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            finally:
                log.warning("Transaction rolled back")
            raise
        finally:
            conn.close()

    # ---------------------------------------------------- autocommit shortcuts
    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self.transaction() as tx:
            return tx.execute(sql, params)

    def query(self, sql: str, params: Sequence[Any] = ()) -> List[Dict[str, Any]]:
        with self.transaction() as tx:
            return tx.query(sql, params)

    # ----------------------------------------------------------------- helpers
    def _bind(self, stmt, params: Sequence[Any]) -> None:
        for i, p in enumerate(params, start=1):
            if p is None:
                raise ValueError("Bind NULL as a literal in SQL, not as a parameter")
            if isinstance(p, dt.datetime):
                stmt.setTimestamp(i, self._jvm.java.sql.Timestamp.valueOf(fmt_ts(p)))
            elif isinstance(p, bool):
                stmt.setBoolean(i, p)
            elif isinstance(p, int):
                stmt.setLong(i, p)
            elif isinstance(p, float):
                stmt.setDouble(i, p)
            else:
                stmt.setString(i, str(p))

    @staticmethod
    def _is_duplicate(exc: Exception) -> bool:
        text = str(exc)
        return _DUPLICATE_KEY_SQLSTATE in text or "SQLCODE=-803" in text or \
            "duplicate key" in text.lower()


class Tx:
    """Statement helpers bound to one open connection."""

    def __init__(self, client: DbClient, conn):
        self._c = client
        self.conn = conn

    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        stmt = self.conn.prepareStatement(sql)
        try:
            self._c._bind(stmt, params)
            return int(stmt.executeUpdate())
        except Exception as exc:
            if DbClient._is_duplicate(exc):
                raise DuplicateKeyError(str(exc)) from exc
            raise
        finally:
            stmt.close()

    def query(self, sql: str, params: Sequence[Any] = ()) -> List[Dict[str, Any]]:
        stmt = self.conn.prepareStatement(sql)
        try:
            self._c._bind(stmt, params)
            rs = stmt.executeQuery()
            md = rs.getMetaData()
            n = md.getColumnCount()
            names = [md.getColumnLabel(i).upper() for i in range(1, n + 1)]
            types = [md.getColumnType(i) for i in range(1, n + 1)]
            rows = []
            while rs.next():
                row: Dict[str, Optional[Any]] = {}
                for i in range(1, n + 1):
                    if types[i - 1] in _JDBC_TIMESTAMP_TYPES:
                        ts = rs.getTimestamp(i)
                        row[names[i - 1]] = None if ts is None else parse_ts(ts.toString())
                    else:
                        val = rs.getObject(i)
                        row[names[i - 1]] = None if val is None else (
                            val if isinstance(val, (int, float, str)) else str(val))
                rows.append(row)
            rs.close()
            return rows
        finally:
            stmt.close()

    def scalar(self, sql: str, params: Sequence[Any] = ()):
        rows = self.query(sql, params)
        return next(iter(rows[0].values())) if rows else None
