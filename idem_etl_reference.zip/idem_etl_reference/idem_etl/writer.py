"""Idempotent write-back to DB2: stage with Spark JDBC, then apply set-based SQL.

Why not df.write.jdbc(target, mode="append") directly?
  * Spark commits each partition separately - a failure half-way leaves a
    partial load, and a re-run appends the same rows again (duplicates).
  * Task retries / speculative tasks can insert the same partition twice.
Staging + MERGE (or DELETE+INSERT of a slice) turns the write into a single
replayable DB2 unit of work.
"""
from __future__ import annotations

import logging
from typing import List

from pyspark.sql import DataFrame, Window as W
from pyspark.sql import functions as F

from .config import JobConfig
from .db_client import DbClient, Tx
from .dialect import Db2Dialect

log = logging.getLogger(__name__)

META_COLS = ("ROW_HASH", "RUN_ID")


class IdempotentWriter:
    def __init__(self, client: DbClient, cfg: JobConfig, dialect: Db2Dialect):
        self.c, self.cfg, self.d = client, cfg, dialect
        self._cols: List[str] = []

    # ------------------------------------------------------------ Spark side
    def prepare(self, df: DataFrame, run_id: str) -> DataFrame:
        cfg = self.cfg
        df = df.toDF(*[c.upper() for c in df.columns])
        business = [c for c in df.columns if c not in META_COLS]
        hashed = sorted(c for c in business if c not in {h.upper() for h in cfg.hash_exclude_columns})
        # Deterministic content hash -> lets MERGE skip rows that did not change,
        # so a replay produces zero updates instead of rewriting identical rows.
        row_hash = F.sha2(F.concat_ws("\u001f", *[
            F.coalesce(F.col(c).cast("string"), F.lit("\u0000")) for c in hashed]), 256)
        df = df.withColumn("ROW_HASH", row_hash).withColumn("RUN_ID", F.lit(run_id))

        # One row per business key, chosen deterministically (latest version wins,
        # ROW_HASH breaks ties) so re-runs pick the same row every time.
        order = [F.col(cfg.version_column.upper()).desc()] if cfg.version_column else []
        order.append(F.col("ROW_HASH").desc())
        w = W.partitionBy(*[k.upper() for k in cfg.key_columns]).orderBy(*order)
        df = (df.withColumn("RN__", F.row_number().over(w))
                .where("RN__ = 1").drop("RN__"))
        self._cols = business
        return df

    def stage(self, df: DataFrame) -> int:
        cfg = self.cfg
        # Clear leftovers of any earlier failed attempt (we hold the job lease).
        self.c.execute(self.d.truncate_sql(cfg.staging_table))
        writer = (df.repartition(cfg.write_partitions).write.format("jdbc")
                  .option("url", cfg.jdbc_url)
                  .option("driver", cfg.jdbc_driver)
                  .option("dbtable", cfg.staging_table)
                  .option("batchsize", cfg.write_batch_size)
                  .option("isolationLevel", "READ_COMMITTED")
                  .mode("append"))
        for k, v in cfg.jdbc_properties.items():
            writer = writer.option(k, v)
        writer.save()
        with self.c.transaction() as tx:
            n = int(tx.scalar(f"SELECT COUNT(*) FROM {cfg.staging_table}"))
        log.info("Staged %d rows into %s", n, cfg.staging_table)
        return n

    # -------------------------------------------------------------- DB2 side
    def _source(self) -> str:
        return self.d.merge_source(self.cfg.staging_table,
                                   [k.upper() for k in self.cfg.key_columns],
                                   self._cols + list(META_COLS), "ROW_HASH")

    def merge_sql(self) -> str:
        cfg = self.cfg
        keys = [k.upper() for k in cfg.key_columns]
        non_keys = [c for c in self._cols if c not in keys]
        on = " AND ".join(f"T.{k} = S.{k}" for k in keys)
        changed = "(T.ROW_HASH IS NULL OR T.ROW_HASH <> S.ROW_HASH)"
        if cfg.version_column:     # never let an older replay overwrite newer data
            v = cfg.version_column.upper()
            changed += f" AND (T.{v} IS NULL OR S.{v} >= T.{v})"
        sets = ", ".join([f"{c} = S.{c}" for c in non_keys] +
                         ["ROW_HASH = S.ROW_HASH", "LAST_RUN_ID = S.RUN_ID",
                          "ETL_UPDATED_TS = CURRENT_TIMESTAMP"])
        ins_cols = ", ".join(self._cols + ["ROW_HASH", "LAST_RUN_ID", "ETL_UPDATED_TS"])
        ins_vals = ", ".join([f"S.{c}" for c in self._cols] +
                             ["S.ROW_HASH", "S.RUN_ID", "CURRENT_TIMESTAMP"])
        return (f"MERGE INTO {cfg.target_table} T USING {self._source()} S ON {on} "
                f"WHEN MATCHED AND {changed} THEN UPDATE SET {sets} "
                f"WHEN NOT MATCHED THEN INSERT ({ins_cols}) VALUES ({ins_vals})")

    def replace_slice_sql(self) -> List[str]:
        cfg = self.cfg
        sc = cfg.slice_column.upper()
        cols = ", ".join(self._cols + ["ROW_HASH", "LAST_RUN_ID", "ETL_UPDATED_TS"])
        vals = ", ".join([f"S.{c}" for c in self._cols] +
                         ["S.ROW_HASH", "S.RUN_ID", "CURRENT_TIMESTAMP"])
        return [
            f"DELETE FROM {cfg.target_table} WHERE {sc} IN "
            f"(SELECT DISTINCT {sc} FROM {cfg.staging_table})",
            f"INSERT INTO {cfg.target_table} ({cols}) SELECT {vals} FROM {self._source()} S",
        ]

    def apply(self, tx: Tx) -> int:
        """Runs inside the commit transaction. Replaying it is harmless."""
        if self.cfg.write_strategy == "MERGE":
            sql = self.merge_sql()
            log.info("MERGE: %s", sql)
            return tx.execute(sql)
        deleted, inserted = (tx.execute(s) for s in self.replace_slice_sql())
        log.info("REPLACE_SLICE deleted=%d inserted=%d", deleted, inserted)
        return inserted

    def cleanup(self) -> None:
        try:
            self.c.execute(self.d.truncate_sql(self.cfg.staging_table))
        except Exception:
            log.warning("Staging cleanup failed (harmless; next run truncates)", exc_info=True)
