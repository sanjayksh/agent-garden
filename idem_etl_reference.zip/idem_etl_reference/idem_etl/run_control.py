"""Run-level idempotency: one logical run key is processed at most once successfully.

Table ETL_JOB_RUN has PRIMARY KEY (JOB_NAME, RUN_KEY). The primary key - not
application logic - is what guarantees that two submissions of the same run key
cannot both start: the second INSERT fails with SQLSTATE 23505.
"""
from __future__ import annotations

import datetime as dt
import logging
import uuid
from dataclasses import dataclass
from typing import Optional

from .db_client import DbClient, DuplicateKeyError, Tx

log = logging.getLogger(__name__)


class RunInProgressError(RuntimeError):
    """Another live attempt owns this run key."""


@dataclass
class RunDecision:
    action: str                          # "RUN" | "SKIP"
    run_id: str
    attempt: int
    prior_low: Optional[str] = None      # window recorded by a failed attempt
    prior_high: Optional[str] = None


class RunController:
    def __init__(self, client: DbClient, table: str, job_name: str, stale_seconds: int):
        self.c = client
        self.t = table
        self.job = job_name
        self.stale = dt.timedelta(seconds=stale_seconds)

    def claim(self, run_key: str, now: dt.datetime, batch_id: str = "",
              force: bool = False) -> RunDecision:
        run_id = uuid.uuid4().hex
        try:
            self.c.execute(
                f"INSERT INTO {self.t} (JOB_NAME, RUN_KEY, RUN_ID, ATTEMPT, STATUS, BATCH_ID,"
                f" STARTED_TS, HEARTBEAT_TS) VALUES (?, ?, ?, 1, 'RUNNING', ?, ?, ?)",
                (self.job, run_key, run_id, batch_id, now, now))
            log.info("Claimed new run %s/%s run_id=%s", self.job, run_key, run_id)
            return RunDecision("RUN", run_id, 1)
        except DuplicateKeyError:
            pass

        rows = self.c.query(
            f"SELECT RUN_ID, ATTEMPT, STATUS, HEARTBEAT_TS, WM_LOW, WM_HIGH FROM {self.t}"
            f" WHERE JOB_NAME = ? AND RUN_KEY = ?", (self.job, run_key))
        row = rows[0]
        status = row["STATUS"]

        if status == "SUCCESS" and not force:
            log.info("Run %s/%s already SUCCEEDED - nothing to do", self.job, run_key)
            return RunDecision("SKIP", row["RUN_ID"], int(row["ATTEMPT"]))
        if status == "RUNNING" and row["HEARTBEAT_TS"] > now - self.stale:
            raise RunInProgressError(
                f"{self.job}/{run_key} is RUNNING (run_id={row['RUN_ID']}, "
                f"last heartbeat {row['HEARTBEAT_TS']})")

        # FAILED, stale RUNNING (driver died) or forced re-run: take over with a
        # compare-and-set on the previous RUN_ID so only one contender wins.
        keep_window = status != "SUCCESS"
        n = self.c.execute(
            f"UPDATE {self.t} SET RUN_ID = ?, ATTEMPT = ATTEMPT + 1, STATUS = 'RUNNING',"
            f" BATCH_ID = ?, STARTED_TS = ?, HEARTBEAT_TS = ?, ENDED_TS = NULL,"
            f" ERROR_MSG = NULL"
            + ("" if keep_window else ", WM_LOW = NULL, WM_HIGH = NULL")
            + " WHERE JOB_NAME = ? AND RUN_KEY = ? AND RUN_ID = ?",
            (run_id, batch_id, now, now, self.job, run_key, row["RUN_ID"]))
        if n != 1:
            raise RunInProgressError(f"Lost race while taking over {self.job}/{run_key}")
        attempt = int(row["ATTEMPT"]) + 1
        log.info("Re-claimed %s/%s (previous status %s) attempt=%d run_id=%s",
                 self.job, run_key, status, attempt, run_id)
        return RunDecision("RUN", run_id, attempt,
                           row["WM_LOW"] if keep_window else None,
                           row["WM_HIGH"] if keep_window else None)

    def record_window(self, run_key: str, run_id: str, low: str, high: str) -> None:
        self.c.execute(
            f"UPDATE {self.t} SET WM_LOW = ?, WM_HIGH = ? "
            f"WHERE JOB_NAME = ? AND RUN_KEY = ? AND RUN_ID = ?",
            (low, high, self.job, run_key, run_id))

    def heartbeat(self, run_key: str, run_id: str, now: dt.datetime) -> None:
        self.c.execute(
            f"UPDATE {self.t} SET HEARTBEAT_TS = ? WHERE JOB_NAME = ? AND RUN_KEY = ?"
            f" AND RUN_ID = ? AND STATUS = 'RUNNING'", (now, self.job, run_key, run_id))

    def mark_success(self, tx: Tx, run_key: str, run_id: str,
                     rows_staged: int, rows_written: int) -> None:
        """Called INSIDE the commit transaction - succeeds only if we still own the run."""
        n = tx.execute(
            f"UPDATE {self.t} SET STATUS = 'SUCCESS', ENDED_TS = CURRENT_TIMESTAMP,"
            f" ROWS_STAGED = ?, ROWS_WRITTEN = ? WHERE JOB_NAME = ? AND RUN_KEY = ?"
            f" AND RUN_ID = ? AND STATUS = 'RUNNING'",
            (rows_staged, rows_written, self.job, run_key, run_id))
        if n != 1:
            raise RunInProgressError(f"Run {run_id} no longer owns {self.job}/{run_key}")

    def mark_failed(self, run_key: str, run_id: str, error: str) -> None:
        try:
            self.c.execute(
                f"UPDATE {self.t} SET STATUS = 'FAILED', ENDED_TS = CURRENT_TIMESTAMP,"
                f" ERROR_MSG = ? WHERE JOB_NAME = ? AND RUN_KEY = ? AND RUN_ID = ?"
                f" AND STATUS = 'RUNNING'",
                ((error or "unknown")[:1000], self.job, run_key, run_id))
        except Exception:  # never mask the original error
            log.exception("Could not mark run %s as FAILED", run_id)
