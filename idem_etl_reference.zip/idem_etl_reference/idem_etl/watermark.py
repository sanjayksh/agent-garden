"""High-water-mark bookkeeping in DB2 (table ETL_WATERMARK, one row per job).

The row doubles as a job-level lease (LOCK_RUN_ID / LOCK_TS) so that two runs
of the same job with *different* run keys can never process the same window
concurrently.
"""
from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass

from .config import JobConfig
from .db_client import DbClient, DuplicateKeyError, Tx, fmt_ts, parse_ts
from .dialect import Db2Dialect

log = logging.getLogger(__name__)


class JobLockedError(RuntimeError):
    """Another run of this job holds the lease."""


@dataclass(frozen=True)
class Window:
    low: str          # committed watermark exactly as stored (CAS value)
    read_low: str     # low minus look-back overlap (what we actually read from)
    high: str         # inclusive upper bound; becomes the new watermark
    wm_type: str

    @property
    def is_empty(self) -> bool:
        if self.wm_type == "BIGINT":
            return int(self.high) <= int(self.low)
        return parse_ts(self.high) <= parse_ts(self.low)


class WatermarkStore:
    def __init__(self, client: DbClient, cfg: JobConfig, dialect: Db2Dialect):
        self.c, self.cfg, self.d = client, cfg, dialect
        self.t = cfg.watermark_table

    # ------------------------------------------------------------------ setup
    def ensure_row(self) -> None:
        try:
            self.c.execute(
                f"INSERT INTO {self.t} (JOB_NAME, SOURCE_TABLE, WM_COLUMN, WM_TYPE, WM_VALUE,"
                f" UPDATED_TS) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
                (self.cfg.job_name, self.cfg.source_table, self.cfg.watermark_column,
                 self.cfg.watermark_type, self.cfg.initial_watermark))
            log.info("Initialised watermark for %s at %s", self.cfg.job_name,
                     self.cfg.initial_watermark)
        except DuplicateKeyError:
            pass

    # ------------------------------------------------------------------ lease
    def acquire(self, run_id: str, now: dt.datetime) -> str:
        """Take the job lease and return the committed watermark value."""
        stale_before = now - dt.timedelta(seconds=self.cfg.stale_run_seconds)
        n = self.c.execute(
            f"UPDATE {self.t} SET LOCK_RUN_ID = ?, LOCK_TS = ? WHERE JOB_NAME = ? AND"
            f" (LOCK_RUN_ID IS NULL OR LOCK_TS < ? OR LOCK_RUN_ID = ?)",
            (run_id, now, self.cfg.job_name, stale_before, run_id))
        if n != 1:
            raise JobLockedError(f"Job {self.cfg.job_name} is locked by another run")
        return self.current_value()

    def heartbeat(self, run_id: str, now: dt.datetime) -> None:
        self.c.execute(f"UPDATE {self.t} SET LOCK_TS = ? WHERE JOB_NAME = ? AND LOCK_RUN_ID = ?",
                       (now, self.cfg.job_name, run_id))

    def release(self, run_id: str) -> None:
        try:
            self.c.execute(
                f"UPDATE {self.t} SET LOCK_RUN_ID = NULL, LOCK_TS = NULL"
                f" WHERE JOB_NAME = ? AND LOCK_RUN_ID = ?", (self.cfg.job_name, run_id))
        except Exception:
            log.exception("Could not release lease for run %s", run_id)

    def current_value(self) -> str:
        rows = self.c.query(f"SELECT WM_VALUE FROM {self.t} WHERE JOB_NAME = ?",
                            (self.cfg.job_name,))
        return rows[0]["WM_VALUE"]

    # ----------------------------------------------------------------- window
    def compute_window(self, low: str, db_now: dt.datetime) -> Window:
        cfg = self.cfg
        if cfg.watermark_type == "BIGINT":
            with self.c.transaction() as tx:
                mx = tx.scalar(f"SELECT MAX({cfg.watermark_column}) FROM {cfg.source_table}")
            high = int(low) if mx is None else max(int(mx), int(low))
            if cfg.max_window_seconds:            # re-used as "max rows of id range"
                high = min(high, int(low) + cfg.max_window_seconds)
            return Window(low, str(int(low)), str(high), "BIGINT")

        low_ts = parse_ts(low)
        # Upper bound comes from the DB2 server clock, never the Spark/GCP clock,
        # and stays behind "now" by the safety lag so in-flight transactions that
        # will commit with an older ROW CHANGE TIMESTAMP are not skipped.
        high_ts = db_now - dt.timedelta(seconds=cfg.safety_lag_seconds)
        if cfg.max_window_seconds:
            high_ts = min(high_ts, low_ts + dt.timedelta(seconds=cfg.max_window_seconds))
        high_ts = max(high_ts, low_ts)
        read_low = low_ts - dt.timedelta(seconds=cfg.lookback_seconds)
        return Window(low, fmt_ts(read_low), fmt_ts(high_ts), "TIMESTAMP")

    def literal(self, value: str) -> str:
        if self.cfg.watermark_type == "BIGINT":
            return str(int(value))                 # int() doubles as injection guard
        return self.d.ts_literal(fmt_ts(parse_ts(value)))

    # ----------------------------------------------------------------- commit
    def advance(self, tx: Tx, window: Window, run_id: str) -> None:
        """Compare-and-set inside the commit transaction.

        Moves the watermark only if (a) it still equals the value this run started
        from and (b) this run still holds the lease. Otherwise the whole unit of
        work - including the MERGE - is rolled back.
        """
        n = tx.execute(
            f"UPDATE {self.t} SET WM_VALUE = ?, PREV_WM_VALUE = WM_VALUE, LAST_RUN_ID = ?,"
            f" UPDATED_TS = CURRENT_TIMESTAMP, LOCK_RUN_ID = NULL, LOCK_TS = NULL"
            f" WHERE JOB_NAME = ? AND WM_VALUE = ? AND LOCK_RUN_ID = ?",
            (window.high, run_id, self.cfg.job_name, window.low, run_id))
        if n != 1:
            raise JobLockedError("Watermark changed or lease lost - rolling back")

    def release_in_tx(self, tx: Tx, run_id: str) -> None:
        tx.execute(f"UPDATE {self.t} SET LOCK_RUN_ID = NULL, LOCK_TS = NULL"
                   f" WHERE JOB_NAME = ? AND LOCK_RUN_ID = ?", (self.cfg.job_name, run_id))
