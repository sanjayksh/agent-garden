"""The few SQL fragments that differ between DB2 (production) and Derby (local tests)."""
from __future__ import annotations

from typing import List


class Db2Dialect:
    name = "db2"

    def current_timestamp_sql(self) -> str:
        # Works on DB2 for LUW and DB2 for z/OS.
        return "SELECT CURRENT TIMESTAMP FROM SYSIBM.SYSDUMMY1"

    def truncate_sql(self, table: str) -> str:
        # IMMEDIATE = not undoable, minimal logging. Must be first stmt in a unit of work.
        return f"TRUNCATE TABLE {table} IMMEDIATE"

    def ts_literal(self, value: str) -> str:
        return f"TIMESTAMP('{value}')"

    def merge_source(self, staging: str, keys: List[str], cols: List[str],
                     order_col: str) -> str:
        """De-duplicated MERGE source.

        Spark JDBC commits per partition; if a task is retried after its partition
        committed, the staging table can hold duplicate rows. DB2 MERGE raises
        SQLSTATE 21506 when two source rows hit the same target row, so we keep one
        row per key here.
        """
        col_list = ", ".join(cols)
        part = ", ".join(keys)
        return (f"(SELECT {col_list} FROM ("
                f"SELECT {col_list}, ROW_NUMBER() OVER (PARTITION BY {part} "
                f"ORDER BY {order_col} DESC) AS RN__ FROM {staging}) X WHERE RN__ = 1)")


class DerbyDialect(Db2Dialect):
    """Apache Derby (bundled with Spark) - used only by the test-suite."""
    name = "derby"

    def current_timestamp_sql(self) -> str:
        return "VALUES CURRENT_TIMESTAMP"

    def truncate_sql(self, table: str) -> str:
        return f"TRUNCATE TABLE {table}"

    def merge_source(self, staging, keys, cols, order_col) -> str:
        # Derby MERGE only accepts a base table as source; tests don't retry tasks.
        return staging


def get_dialect(name: str):
    return {"db2": Db2Dialect, "derby": DerbyDialect}[name.lower()]()
