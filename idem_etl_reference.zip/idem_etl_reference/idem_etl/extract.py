"""Incremental extract: push the watermark predicate down to DB2."""
from __future__ import annotations

import logging

from pyspark.sql import DataFrame, SparkSession

from .config import JobConfig
from .watermark import Window, WatermarkStore

log = logging.getLogger(__name__)


def build_window_query(cfg: JobConfig, wm: WatermarkStore, window: Window) -> str:
    cols = ", ".join(cfg.source_columns)
    pred = (f"{cfg.watermark_column} > {wm.literal(window.read_low)} AND "
            f"{cfg.watermark_column} <= {wm.literal(window.high)}")
    if cfg.source_filter:
        pred += f" AND ({cfg.source_filter})"
    # NOTE: never add "WITH UR" here - uncommitted rows may later roll back or
    # commit with a timestamp that is already behind the watermark.
    return f"SELECT {cols} FROM {cfg.source_table} WHERE {pred}"


def read_window(spark: SparkSession, cfg: JobConfig, wm: WatermarkStore,
                window: Window) -> DataFrame:
    sql = build_window_query(cfg, wm, window)
    log.info("Extract query: %s", sql)
    reader = (spark.read.format("jdbc")
              .option("url", cfg.jdbc_url)
              .option("driver", cfg.jdbc_driver)
              .option("dbtable", f"({sql}) SRC")
              .option("fetchsize", cfg.fetch_size))
    for k, v in cfg.jdbc_properties.items():
        reader = reader.option(k, v)
    if cfg.read_partitions > 1:
        # Split the window itself into N parallel range scans on the watermark
        # column (index it!). Bounds only shape partitions - they do not filter.
        reader = (reader.option("partitionColumn", cfg.watermark_column)
                  .option("lowerBound", window.read_low)
                  .option("upperBound", window.high)
                  .option("numPartitions", cfg.read_partitions))
    return reader.load()
