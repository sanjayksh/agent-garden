"""Idempotent submission of the PySpark job to Google Cloud Serverless for Apache Spark.

Called by the on-prem scheduler. Safe to call again after a timeout, a network
error or a scheduler restart: the same (job, run_key, attempt) always maps to
the same batch_id and request_id, so the Batches API never starts a duplicate.

    python submit_batch.py --project my-proj --region us-central1 \
        --job ORDERS_DAILY --run-key 2026-09-24 --attempt 1

Exit code 0 = batch SUCCEEDED; anything else = failed (scheduler may retry with
--attempt 2, which creates a new batch; the job itself is idempotent).
Requires: pip install google-cloud-dataproc
"""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
import time
import uuid

from google.api_core.exceptions import AlreadyExists
from google.cloud import dataproc_v1

NS = uuid.UUID("6f1c3a52-6a2e-4c47-9a53-2b8f0d1f5e11")      # fixed namespace for uuid5
TERMINAL = {"SUCCEEDED", "FAILED", "CANCELLED"}


def deterministic_ids(job: str, run_key: str, attempt: int) -> tuple[str, str]:
    seed = f"{job}|{run_key}|{attempt}"
    slug = re.sub(r"[^a-z0-9-]+", "-", f"{job}-{run_key}".lower()).strip("-")
    digest = hashlib.sha1(seed.encode()).hexdigest()[:8]
    batch_id = f"b-{slug}"[:48].rstrip("-") + f"-a{attempt}-{digest}"   # 4-63 chars [a-z0-9-]
    request_id = str(uuid.uuid5(NS, seed))                              # <= 40 chars
    return batch_id, request_id


def build_batch(a, batch_id: str) -> dataproc_v1.Batch:
    return dataproc_v1.Batch(
        pyspark_batch=dataproc_v1.PySparkBatch(
            main_python_file_uri=f"{a.code_uri}/main.py",
            python_file_uris=[f"{a.code_uri}/idem_etl.zip"],
            jar_file_uris=[a.db2_jar_uri],
            file_uris=[a.config_uri],
            args=["--config", a.config_uri.rsplit("/", 1)[-1],
                  "--run-key", a.run_key, "--batch-id", batch_id],
        ),
        runtime_config=dataproc_v1.RuntimeConfig(
            version=a.runtime_version,
            properties={
                "spark.speculation": "false",
                "spark.task.maxFailures": "4",
                # Keep JDBC TIMESTAMP conversion identical on driver and executors.
                "spark.sql.session.timeZone": a.db_timezone,
                "spark.driver.extraJavaOptions": f"-Duser.timezone={a.db_timezone}",
                "spark.executor.extraJavaOptions": f"-Duser.timezone={a.db_timezone}",
            },
        ),
        environment_config=dataproc_v1.EnvironmentConfig(
            execution_config=dataproc_v1.ExecutionConfig(
                subnetwork_uri=a.subnet,               # must route to on-prem DB2
                service_account=a.service_account,
                ttl={"seconds": a.ttl_seconds},        # hard stop for hung runs
            )),
        labels={"job": a.job.lower().replace("_", "-"),
                "run-key": re.sub(r"[^a-z0-9_-]", "-", a.run_key.lower())},
    )


def main() -> int:
    p = argparse.ArgumentParser()
    for name in ("project", "region", "job", "run-key", "code-uri", "config-uri",
                 "db2-jar-uri", "subnet", "service-account"):
        p.add_argument(f"--{name}", required=name in ("project", "region", "job", "run-key"))
    p.add_argument("--attempt", type=int, default=1)
    p.add_argument("--runtime-version", default="2.2")
    p.add_argument("--db-timezone", default="America/Edmonton")
    p.add_argument("--ttl-seconds", type=int, default=4 * 3600)
    p.add_argument("--poll-seconds", type=int, default=30)
    a = p.parse_args()

    client = dataproc_v1.BatchControllerClient(
        client_options={"api_endpoint": f"{a.region}-dataproc.googleapis.com:443"})
    parent = f"projects/{a.project}/locations/{a.region}"
    batch_id, request_id = deterministic_ids(a.job, a.run_key, a.attempt)
    name = f"{parent}/batches/{batch_id}"

    try:
        client.create_batch(request={"parent": parent, "batch": build_batch(a, batch_id),
                                     "batch_id": batch_id, "request_id": request_id})
        print(f"Submitted {name}")
    except AlreadyExists:
        # Same attempt already submitted (e.g. scheduler retried after a timeout):
        # attach to the existing batch instead of starting a second one.
        print(f"Batch {batch_id} already exists - attaching")

    while True:
        state = dataproc_v1.Batch.State(client.get_batch(name=name).state).name
        if state in TERMINAL:
            print(f"Batch {batch_id} finished: {state}")
            return 0 if state == "SUCCEEDED" else 1
        time.sleep(a.poll_seconds)


if __name__ == "__main__":
    sys.exit(main())
