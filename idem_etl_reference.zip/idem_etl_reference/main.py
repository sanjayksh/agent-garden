"""Serverless Spark entry point (main_python_file_uri).

Example args passed by the scheduler through the Batches API:
  --config job_orders.json --run-key 2026-09-24 --batch-id orders-20260924-a1
"""
from __future__ import annotations

import argparse
import importlib
import json
import logging
import sys

from pyspark.sql import SparkSession

from idem_etl import IncrementalJob, JobConfig, JobLockedError, RunInProgressError

EXIT_OK, EXIT_FAILED, EXIT_BUSY = 0, 1, 3


def load_transform(spec: str):
    """'package.module:function' -> callable(DataFrame) -> DataFrame"""
    if not spec:
        return lambda df: df
    mod, fn = spec.split(":")
    return getattr(importlib.import_module(mod), fn)


def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="JSON config (ship via file_uris)")
    p.add_argument("--run-key", required=True,
                   help="Logical run identity from the scheduler, e.g. business date")
    p.add_argument("--batch-id", default="", help="Serverless batch id, for audit")
    p.add_argument("--transform", default="", help="module:function")
    p.add_argument("--force-rerun", action="store_true",
                   help="Re-process a run key that already SUCCEEDED")
    a = p.parse_args(argv)

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s - %(message)s")
    cfg = JobConfig.from_json(a.config)
    spark = (SparkSession.builder.appName(f"{cfg.job_name}:{a.run_key}")
             # JDBC writes must never be speculated - a duplicate task = duplicate rows.
             .config("spark.speculation", "false")
             .getOrCreate())
    try:
        result = IncrementalJob(spark, cfg).run(
            a.run_key, load_transform(a.transform), a.batch_id, a.force_rerun)
        logging.info("RESULT %s", json.dumps(result.as_dict()))
        return EXIT_OK
    except (RunInProgressError, JobLockedError) as exc:
        logging.error("Another run is active: %s", exc)
        return EXIT_BUSY
    except Exception:
        logging.exception("Run failed")
        return EXIT_FAILED
    finally:
        spark.stop()


if __name__ == "__main__":
    sys.exit(main())
