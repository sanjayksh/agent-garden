import json
import os

import pytest

from edl_archiver.config import load_config, validate_config
from edl_archiver.errors import ConfigError

BASE = {
    "job_name": "t",
    "hdfs": {"client": "webhdfs", "url": "https://httpfs:14000"},
    "selection": {"source_paths": ["/data/x"], "age_days": 30},
    "gcs": {"bucket": "b", "storage_class": "ARCHIVE"},
    "db2": {"database": "D", "hostname": "H"},
}


def write(tmp_path, payload):
    path = tmp_path / "cfg.json"
    path.write_text(json.dumps(payload))
    return str(path)


def test_valid_config_loads(tmp_path):
    cfg = load_config(write(tmp_path, BASE))
    assert cfg.job_name == "t"
    assert cfg.gcs.retention.retention_period_days == 2555


def test_env_substitution(tmp_path):
    os.environ["TEST_DB2_PWD"] = "s3cret"
    payload = json.loads(json.dumps(BASE))
    payload["db2"]["password"] = "${TEST_DB2_PWD}"
    cfg = load_config(write(tmp_path, payload))
    assert cfg.db2.password == "s3cret"


def test_missing_env_var_is_rejected(tmp_path):
    payload = json.loads(json.dumps(BASE))
    payload["db2"]["password"] = "${NOT_SET_ANYWHERE_12345}"
    with pytest.raises(ConfigError):
        load_config(write(tmp_path, payload))


def test_unknown_key_is_rejected(tmp_path):
    payload = json.loads(json.dumps(BASE))
    payload["gcs"]["buckett"] = "typo"
    with pytest.raises(ConfigError):
        load_config(write(tmp_path, payload))


def test_chunk_size_must_be_multiple_of_256k(tmp_path):
    payload = json.loads(json.dumps(BASE))
    payload["gcs"]["chunk_size_bytes"] = 1000
    with pytest.raises(ConfigError):
        load_config(write(tmp_path, payload))


def test_cutoff_from_age_days(tmp_path):
    cfg = load_config(write(tmp_path, BASE))
    from datetime import datetime, timedelta, timezone
    now = datetime(2026, 8, 3, tzinfo=timezone.utc)
    assert cfg.selection.cutoff(now) == now - timedelta(days=30)


def test_delete_source_requires_checksum(tmp_path):
    payload = json.loads(json.dumps(BASE))
    payload["runtime"] = {"delete_source_after_archive": True, "verify_checksum": False}
    with pytest.raises(ConfigError):
        load_config(write(tmp_path, payload))
