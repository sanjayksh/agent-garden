import base64
import io

from edl_archiver.core.checksum import TeeChecksum


def test_tee_is_transparent_and_digests():
    payload = b"abc bank data lake" * 1000
    tee = TeeChecksum(io.BytesIO(payload), compute_md5=True)
    chunks = []
    while True:
        buf = tee.read(4096)
        if not buf:
            break
        chunks.append(buf)
    assert b"".join(chunks) == payload
    assert tee.bytes_read == len(payload)
    assert tee.md5_hex is not None
    if tee.crc32c_b64:
        assert len(base64.b64decode(tee.crc32c_b64)) == 4
