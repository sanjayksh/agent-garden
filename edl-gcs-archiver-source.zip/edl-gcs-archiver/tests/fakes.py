"""In-memory doubles for HDFS, GCS and Db2 so the pipeline can be tested
end to end without a cluster, a bucket or a database."""
from __future__ import annotations

import io
from datetime import datetime, timezone
from typing import Dict, Iterator, List, Optional

from edl_archiver.hdfs.base import HdfsFile, HdfsReader


class FakeHdfsReader(HdfsReader):
    def __init__(self, files: Dict[str, bytes], mtimes: Dict[str, datetime]) -> None:
        self._files = files
        self._mtimes = mtimes
        self.open_calls: List[str] = []

    def walk(self, path: str, recursive: bool = True) -> Iterator[HdfsFile]:
        for p, data in self._files.items():
            if p.startswith(path):
                yield HdfsFile(
                    path=p,
                    size_bytes=len(data),
                    modification_time=self._mtimes[p],
                )

    def open(self, path: str, chunk_size: int):
        self.open_calls.append(path)
        return io.BytesIO(self._files[path])

    def status(self, path: str) -> Optional[HdfsFile]:
        if path not in self._files:
            return None
        return HdfsFile(
            path=path,
            size_bytes=len(self._files[path]),
            modification_time=self._mtimes[path],
        )


class FakeBlob:
    def __init__(self, bucket, name):
        self._bucket = bucket
        self.name = name
        self.metadata = {}
        self.content_type = None
        self.storage_class = "ARCHIVE"
        self.custom_time = None
        self.generation = 1
        self.event_based_hold = False
        self.temporary_hold = False
        self.retention = None
        self._buffer = io.BytesIO()

    @property
    def size(self):
        return len(self._bucket.objects.get(self.name, b""))

    @property
    def crc32c(self):
        import base64
        try:
            import google_crc32c
        except ImportError:
            return None
        c = google_crc32c.Checksum()
        c.update(self._bucket.objects.get(self.name, b""))
        return base64.b64encode(c.digest()).decode()

    @property
    def md5_hash(self):
        return None

    def open(self, mode, **kwargs):
        blob = self

        class _Writer:
            def __enter__(self_inner):
                return self_inner

            def write(self_inner, data):
                blob._buffer.write(data)

            def __exit__(self_inner, *exc):
                blob._bucket.objects[blob.name] = blob._buffer.getvalue()
                return False

        return _Writer()

    def reload(self):
        pass

    def patch(self, **kwargs):
        pass

    def delete(self):
        self._bucket.objects.pop(self.name, None)


class FakeBucket:
    def __init__(self, name):
        self.name = name
        self.objects: Dict[str, bytes] = {}

    def blob(self, name, **kwargs):
        return FakeBlob(self, name)

    def get_blob(self, name):
        if name not in self.objects:
            return None
        return FakeBlob(self, name)


class FakeGcsClient:
    def __init__(self):
        self.buckets: Dict[str, FakeBucket] = {}

    def bucket(self, name):
        return self.buckets.setdefault(name, FakeBucket(name))


class FakeCursor:
    def __init__(self, store):
        self.store = store

    def execute(self, sql, params=()):
        self.store.setdefault("execute", []).append((sql.strip().split()[0], params))
        self._rows = [] if "SELECT" not in sql.upper() else []
        if "SYSDUMMY1" in sql:
            self._rows = [(1,)]

    def executemany(self, sql, seq):
        self.store.setdefault("executemany", []).append((sql.strip().split()[0], list(seq)))

    def fetchone(self):
        return self._rows[0] if getattr(self, "_rows", None) else None

    def fetchall(self):
        return getattr(self, "_rows", [])

    def close(self):
        pass


class FakeConnection:
    def __init__(self, store):
        self.store = store

    def cursor(self):
        return FakeCursor(self.store)

    def commit(self):
        self.store["commits"] = self.store.get("commits", 0) + 1

    def rollback(self):
        self.store["rollbacks"] = self.store.get("rollbacks", 0) + 1

    def set_autocommit(self, flag):
        pass

    def close(self):
        pass


def utc(y, m, d) -> datetime:
    return datetime(y, m, d, tzinfo=timezone.utc)
