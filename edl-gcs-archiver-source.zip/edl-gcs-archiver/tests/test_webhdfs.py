"""WebHDFS reader tests using a stubbed requests.Session."""
import json
from datetime import timezone

from edl_archiver.hdfs.webhdfs import WebHdfsReader


class StubResponse:
    def __init__(self, payload=None, content=b"", status=200):
        self._payload = payload
        self.status_code = status
        self._content = content
        self.text = ""

    def json(self):
        return self._payload

    def iter_content(self, chunk_size=8192):
        for i in range(0, len(self._content), chunk_size):
            yield self._content[i:i + chunk_size]

    def close(self):
        pass


class StubSession:
    def __init__(self, routes):
        self.routes = routes
        self.calls = []

    def get(self, url, params=None, **kwargs):
        self.calls.append((url, dict(params or {})))
        return self.routes(url, params or {})

    def close(self):
        pass


def _listing(entries, remaining=0):
    return {"DirectoryListing": {
        "partialListing": {"FileStatuses": {"FileStatus": entries}},
        "remainingEntries": remaining,
    }}


def file_entry(name, length=100, mtime_ms=1577836800000):
    return {"pathSuffix": name, "type": "FILE", "length": length,
            "modificationTime": mtime_ms, "owner": "hive", "group": "edl",
            "permission": "640", "replication": 3, "blockSize": 134217728}


def test_walk_paginates_and_recurses():
    pages = {
        ("/data/x", None): _listing(
            [{"pathSuffix": "sub", "type": "DIRECTORY"}, file_entry("a.csv")]),
        ("/data/x/sub", None): _listing([file_entry("b.parquet", 200)], remaining=1),
        ("/data/x/sub", "b.parquet"): _listing([file_entry("c.avro", 300)]),
    }

    def routes(url, params):
        path = url.split("/webhdfs/v1")[1]
        return StubResponse(pages[(path, params.get("startAfter"))])

    reader = WebHdfsReader(url="https://httpfs:14000", auth="simple", user="svc",
                           session=StubSession(routes))
    found = sorted(f.path for f in reader.walk("/data/x"))
    assert found == ["/data/x/a.csv", "/data/x/sub/b.parquet", "/data/x/sub/c.avro"]


def test_open_streams_full_content():
    payload = b"0123456789" * 5000

    def routes(url, params):
        return StubResponse(content=payload)

    reader = WebHdfsReader(url="https://httpfs:14000", auth="simple", user="svc",
                           session=StubSession(routes))
    with reader.open("/data/x/a.csv", chunk_size=4096) as stream:
        assert stream.read() == payload


def test_status_parses_timestamps_as_utc():
    def routes(url, params):
        return StubResponse({"FileStatus": {
            "type": "FILE", "length": 42, "modificationTime": 1577836800000,
            "owner": "hive", "group": "edl", "permission": "640"}})

    reader = WebHdfsReader(url="https://httpfs:14000", auth="simple", user="svc",
                           session=StubSession(routes))
    info = reader.status("/data/x/a.csv")
    assert info.size_bytes == 42
    assert info.modification_time.tzinfo is not None
    assert info.modification_time.astimezone(timezone.utc).year == 2020
    assert info.file_format == "CSV"


def test_missing_file_returns_none():
    reader = WebHdfsReader(url="https://httpfs:14000", auth="simple", user="svc",
                           session=StubSession(lambda u, p: StubResponse(status=404)))
    assert reader.status("/nope") is None
