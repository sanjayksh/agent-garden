import pytest

from edl_archiver.core.retry import retry
from edl_archiver.errors import RetryableError, TerminalError


def test_retries_then_succeeds():
    calls = {"n": 0}

    @retry(max_attempts=3, initial_seconds=0.001, max_seconds=0.002)
    def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise RetryableError("transient")
        return "ok"

    assert flaky() == "ok"
    assert calls["n"] == 3


def test_terminal_error_is_not_retried():
    calls = {"n": 0}

    @retry(max_attempts=5, initial_seconds=0.001)
    def bad():
        calls["n"] += 1
        raise TerminalError("nope")

    with pytest.raises(TerminalError):
        bad()
    assert calls["n"] == 1


def test_exhausts_attempts_and_reraises():
    @retry(max_attempts=2, initial_seconds=0.001)
    def always():
        raise RetryableError("always")

    with pytest.raises(RetryableError):
        always()
