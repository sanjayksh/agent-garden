import io
from datetime import datetime, timezone

from edl_archiver.config import GcsConfig, RetentionConfig
from edl_archiver.gcs.uploader import GcsUploader
from edl_archiver.hdfs.base import HdfsFile
from fakes import FakeGcsClient

RUN_DATE = datetime(2026, 8, 3, tzinfo=timezone.utc)


def make_uploader(**overrides):
    cfg = GcsConfig(bucket="abc-archive", storage_class="ARCHIVE", **overrides)
    return GcsUploader(cfg, client=FakeGcsClient()), cfg


def sample_file(path="/data/edl/raw/tbl/dt=2019-01-01/part-0.parquet", size=32):
    return HdfsFile(path=path, size_bytes=size,
                    modification_time=datetime(2019, 1, 1, tzinfo=timezone.utc))


def test_object_name_preserves_source_path():
    up, _ = make_uploader()
    name = up.build_object_name(sample_file(), "/data/edl/raw", "job1", RUN_DATE)
    assert name == "edl-archive/job1/2026/08/03/tbl/dt=2019-01-01/part-0.parquet"


def test_object_name_flat_when_not_preserving():
    up, _ = make_uploader(preserve_source_path=False)
    name = up.build_object_name(sample_file(), "/data/edl/raw", "job1", RUN_DATE)
    assert name.endswith("/part-0.parquet")


def test_upload_writes_bytes_and_retention_metadata():
    up, cfg = make_uploader()
    cfg.retention = RetentionConfig(mode="object_lock", retention_period_days=10,
                                    classification="CONFIDENTIAL")
    payload = b"parquet-bytes" * 100
    f = sample_file(size=len(payload))
    result = up.upload_stream(io.BytesIO(payload), "obj/a.parquet", f, "/data/edl/raw")

    assert result.size_bytes == len(payload)
    assert result.retention_mode == "object_lock"
    assert result.retain_until is not None
    assert up._bucket.objects["obj/a.parquet"] == payload


def test_content_type_mapping():
    up, _ = make_uploader()
    assert up._content_type(sample_file("/x/a.parquet")) == "application/vnd.apache.parquet"
    assert up._content_type(sample_file("/x/a.json")) == "application/json"
    assert up._content_type(sample_file("/x/a.bin")) == "application/octet-stream"


def test_object_exists_detects_prior_upload():
    up, _ = make_uploader()
    payload = b"x" * 50
    up.upload_stream(io.BytesIO(payload), "obj/b.csv", sample_file(size=50), "/data/edl/raw")
    assert up.object_exists("obj/b.csv", 50) is True
    assert up.object_exists("obj/b.csv", 99) is False
    assert up.object_exists("obj/missing", 1) is False
