from datetime import datetime, timezone

from edl_archiver.config import SelectionConfig
from edl_archiver.core.scanner import FileScanner
from fakes import FakeHdfsReader, utc

NOW = datetime(2026, 8, 3, tzinfo=timezone.utc)


def build(files):
    data = {p: b"x" * n for p, (n, _) in files.items()}
    mtimes = {p: t for p, (_, t) in files.items()}
    return FakeHdfsReader(data, mtimes)


def test_age_filter_selects_only_old_files():
    reader = build({
        "/data/x/a.parquet": (10, utc(2020, 1, 1)),
        "/data/x/b.parquet": (10, utc(2026, 7, 30)),
    })
    sel = SelectionConfig(source_paths=["/data/x"], age_days=365)
    scanner = FileScanner(reader, sel, now=NOW)
    paths = [f.path for _, f in scanner.scan()]
    assert paths == ["/data/x/a.parquet"]
    assert scanner.stats.excluded_by_age == 1


def test_exclude_globs_and_zero_byte():
    reader = build({
        "/data/x/_SUCCESS": (0, utc(2020, 1, 1)),
        "/data/x/part.csv": (5, utc(2020, 1, 1)),
        "/data/x/tmp.tmp": (5, utc(2020, 1, 1)),
    })
    sel = SelectionConfig(source_paths=["/data/x"], age_days=1)
    scanner = FileScanner(reader, sel, now=NOW)
    assert [f.name for _, f in scanner.scan()] == ["part.csv"]


def test_format_filter():
    reader = build({
        "/data/x/a.parquet": (5, utc(2020, 1, 1)),
        "/data/x/b.log": (5, utc(2020, 1, 1)),
    })
    sel = SelectionConfig(source_paths=["/data/x"], age_days=1,
                          include_formats=["parquet"])
    scanner = FileScanner(reader, sel, now=NOW)
    assert [f.name for _, f in scanner.scan()] == ["a.parquet"]


def test_partition_date_basis_overrides_mtime():
    # mtime is recent (a compaction touched it) but the business date is 2019.
    reader = build({"/data/x/dt=2019-04-01/part-0.avro": (5, utc(2026, 7, 1))})
    sel = SelectionConfig(
        source_paths=["/data/x"], age_days=365,
        age_basis="path_partition", partition_date_regex=r"dt=(\d{4}-\d{2}-\d{2})",
    )
    scanner = FileScanner(reader, sel, now=NOW)
    assert len(list(scanner.scan())) == 1


def test_already_archived_index_skips_file():
    reader = build({"/data/x/a.csv": (5, utc(2020, 1, 1))})
    sel = SelectionConfig(source_paths=["/data/x"], age_days=1)
    scanner = FileScanner(reader, sel, now=NOW)
    result = list(scanner.scan({"/data/x/a.csv": utc(2020, 1, 1)}))
    assert result == []
    assert scanner.stats.excluded_already_archived == 1


def test_max_files_per_run_caps_output():
    reader = build({f"/data/x/f{i}.csv": (5, utc(2020, 1, 1)) for i in range(10)})
    sel = SelectionConfig(source_paths=["/data/x"], age_days=1, max_files_per_run=3)
    scanner = FileScanner(reader, sel, now=NOW)
    assert len(list(scanner.scan())) == 3
