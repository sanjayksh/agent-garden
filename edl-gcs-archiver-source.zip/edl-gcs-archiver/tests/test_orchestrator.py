from datetime import datetime, timezone

from edl_archiver.config import (Db2Config, GcsConfig, JobConfig, RuntimeConfig,
                                 SelectionConfig)
from edl_archiver.core.orchestrator import ArchivalOrchestrator
from edl_archiver.gcs.uploader import GcsUploader
from edl_archiver.metadata.dao import ArchiveMetadataDao
from edl_archiver.metadata.db2_client import Db2ConnectionPool
from fakes import FakeConnection, FakeGcsClient, FakeHdfsReader, utc


def build_job(**runtime):
    return JobConfig(
        job_name="unit-job",
        selection=SelectionConfig(source_paths=["/data/x"], age_days=1),
        gcs=GcsConfig(bucket="abc-archive", storage_class="ARCHIVE"),
        db2=Db2Config(database="D", hostname="H"),
        runtime=RuntimeConfig(max_workers=4, **runtime),
    )


def build_dao():
    store = {}
    pool = Db2ConnectionPool(Db2Config(database="D", hostname="H", pool_size=2),
                             connection_factory=lambda: FakeConnection(store))
    return ArchiveMetadataDao(pool, batch_size=1), store


def test_end_to_end_archives_every_eligible_file():
    files = {f"/data/x/f{i}.csv": b"row,row\n" * (i + 1) for i in range(5)}
    mtimes = {p: utc(2020, 1, 1) for p in files}
    reader = FakeHdfsReader(files, mtimes)

    cfg = build_job()
    uploader = GcsUploader(cfg.gcs, client=FakeGcsClient())
    dao, store = build_dao()

    result = ArchivalOrchestrator(cfg, reader, uploader, dao).run()

    assert result.status == "SUCCEEDED"
    assert result.files_archived == 5
    assert result.files_failed == 0
    assert result.bytes_archived == sum(len(v) for v in files.values())
    assert len(uploader._bucket.objects) == 5
    assert store.get("executemany")


def test_dry_run_uploads_nothing():
    files = {"/data/x/a.csv": b"abc"}
    reader = FakeHdfsReader(files, {"/data/x/a.csv": utc(2020, 1, 1)})
    cfg = build_job(dry_run=True)
    uploader = GcsUploader(cfg.gcs, client=FakeGcsClient())
    dao, _ = build_dao()

    result = ArchivalOrchestrator(cfg, reader, uploader, dao).run()
    assert result.files_archived == 0
    assert result.files_skipped == 1
    assert uploader._bucket.objects == {}


def test_rerun_is_idempotent():
    files = {"/data/x/a.csv": b"abcdef"}
    mtimes = {"/data/x/a.csv": utc(2020, 1, 1)}
    reader = FakeHdfsReader(files, mtimes)
    cfg = build_job()
    uploader = GcsUploader(cfg.gcs, client=FakeGcsClient())
    dao, _ = build_dao()

    first = ArchivalOrchestrator(cfg, reader, uploader, dao).run()
    second = ArchivalOrchestrator(cfg, reader, uploader, dao).run()

    assert first.files_archived == 1
    # Second run finds the object already present and skips the transfer.
    assert second.files_archived == 0
    assert second.files_skipped == 1
    assert len(reader.open_calls) == 1


def test_failed_read_is_recorded_not_fatal():
    class Exploding(FakeHdfsReader):
        def open(self, path, chunk_size):
            raise OSError("datanode unreachable")

    files = {"/data/x/a.csv": b"abc", "/data/x/b.csv": b"def"}
    mtimes = {p: utc(2020, 1, 1) for p in files}
    cfg = build_job(max_attempts=2, backoff_initial_seconds=0.001,
                    backoff_max_seconds=0.002)
    uploader = GcsUploader(cfg.gcs, client=FakeGcsClient())
    dao, _ = build_dao()

    result = ArchivalOrchestrator(cfg, Exploding(files, mtimes), uploader, dao).run()
    assert result.files_failed == 2
    assert result.status == "FAILED"
