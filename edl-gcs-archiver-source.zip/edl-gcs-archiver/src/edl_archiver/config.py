"""Typed configuration model and JSON loader.

The job is driven entirely by a declarative JSON document so that onboarding a
new source directory is a configuration change reviewed through the bank's
normal change process - never a code change.

Secrets are never stored in the JSON. Any string value may use the form
``${ENV_VAR}`` and will be resolved from the process environment at load time,
which lets the bank inject credentials from CyberArk / Vault via the scheduler.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from .errors import ConfigError

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

VALID_STORAGE_CLASSES = {
    "STANDARD",
    "NEARLINE",
    "COLDLINE",
    "ARCHIVE",
}
VALID_HDFS_CLIENTS = {"webhdfs", "libhdfs"}
VALID_RETENTION_MODES = {"none", "object_lock", "custom_time_only", "event_based_hold"}


# --------------------------------------------------------------------------- #
# Sub-sections
# --------------------------------------------------------------------------- #
@dataclass
class HdfsConfig:
    """How to reach and read the on-premise Data Lake."""

    client: str = "webhdfs"           # webhdfs | libhdfs
    # --- WebHDFS / HttpFS ---
    url: str = ""                     # e.g. https://httpfs.abcbank.internal:14000
    auth: str = "kerberos"            # kerberos | simple
    user: str = ""                    # only used when auth == "simple"
    principal: str = ""               # informational; ticket comes from ccache
    keytab: str = ""                  # optional, used by the kinit helper
    verify_ssl: Any = True            # True | False | path to CA bundle
    timeout_seconds: int = 120
    # --- libhdfs / PyArrow ---
    namenode_host: str = ""
    namenode_port: int = 8020
    kerb_ticket: str = ""             # path to Kerberos credential cache
    extra_conf: Dict[str, str] = field(default_factory=dict)
    # --- shared ---
    read_chunk_bytes: int = 8 * 1024 * 1024
    list_batch_size: int = 1000       # WebHDFS LISTSTATUS_BATCH page size


@dataclass
class SelectionConfig:
    """Which files inside the source path qualify for archival."""

    source_paths: List[str] = field(default_factory=list)
    recursive: bool = True
    age_days: Optional[int] = None            # file older than N days
    older_than: Optional[str] = None          # absolute ISO-8601 cut-off
    age_basis: str = "modification_time"      # modification_time | path_partition
    partition_date_regex: str = ""            # used when age_basis == path_partition
    include_globs: List[str] = field(default_factory=lambda: ["*"])
    exclude_globs: List[str] = field(
        default_factory=lambda: ["_SUCCESS", "*_COPYING_", ".*", "*.tmp"]
    )
    include_formats: List[str] = field(
        default_factory=lambda: ["json", "csv", "avro", "parquet", "orc", "txt", "gz"]
    )
    min_size_bytes: int = 0
    max_files_per_run: int = 0                # 0 = unlimited
    skip_zero_byte_files: bool = True

    def cutoff(self, now: Optional[datetime] = None) -> datetime:
        """Resolve the effective cut-off timestamp (timezone aware, UTC)."""
        now = now or datetime.now(timezone.utc)
        if self.older_than:
            parsed = datetime.fromisoformat(self.older_than.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        if self.age_days is not None:
            return now - timedelta(days=self.age_days)
        raise ConfigError("selection: one of 'age_days' or 'older_than' is required")


@dataclass
class RetentionConfig:
    """Retention metadata applied to each archived object."""

    mode: str = "object_lock"          # see VALID_RETENTION_MODES
    retention_period_days: int = 2555  # 7 years - typical banking default
    lock_retention: bool = False       # irreversibly lock the per-object retention
    classification: str = "INTERNAL"
    record_code: str = ""              # bank records-management schedule code
    legal_hold: bool = False
    custom_metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class GcsConfig:
    """Target bucket and object naming."""

    project_id: str = ""
    bucket: str = ""
    # Supports {source_root},{relative_path},{yyyy},{mm},{dd},{job_name},{run_date}
    object_prefix_template: str = "edl-archive/{job_name}/{yyyy}/{mm}/{dd}"
    preserve_source_path: bool = True
    storage_class: str = "ARCHIVE"
    kms_key_name: str = ""             # CMEK; empty = Google-managed key
    chunk_size_bytes: int = 16 * 1024 * 1024
    upload_timeout_seconds: int = 3600
    credentials_file: str = ""         # empty = ADC / Workload Identity Federation
    max_retry_seconds: int = 600
    retention: RetentionConfig = field(default_factory=RetentionConfig)


@dataclass
class Db2Config:
    """Metadata store connection settings."""

    database: str = ""
    hostname: str = ""
    port: int = 50000
    username: str = ""
    password: str = ""
    schema: str = "EDLARCH"
    use_ssl: bool = True
    ssl_server_certificate: str = ""
    pool_size: int = 8
    batch_size: int = 500
    connect_timeout_seconds: int = 30


@dataclass
class RuntimeConfig:
    """Concurrency, retry and operational switches."""

    max_workers: int = 16
    max_attempts: int = 4
    backoff_initial_seconds: float = 2.0
    backoff_max_seconds: float = 60.0
    dry_run: bool = False
    verify_checksum: bool = True
    delete_source_after_archive: bool = False   # requires explicit sign-off
    failure_threshold_pct: float = 5.0          # abort run above this failure rate
    log_level: str = "INFO"
    log_file: str = ""
    lock_file: str = "/var/run/edl-archiver/{job_name}.lock"


@dataclass
class JobConfig:
    """Root configuration object."""

    job_name: str
    description: str = ""
    hdfs: HdfsConfig = field(default_factory=HdfsConfig)
    selection: SelectionConfig = field(default_factory=SelectionConfig)
    gcs: GcsConfig = field(default_factory=GcsConfig)
    db2: Db2Config = field(default_factory=Db2Config)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)


# --------------------------------------------------------------------------- #
# Loading / validation
# --------------------------------------------------------------------------- #
def _resolve_env(value: Any) -> Any:
    """Recursively substitute ${ENV_VAR} placeholders."""
    if isinstance(value, str):
        def repl(match: "re.Match[str]") -> str:
            name = match.group(1)
            if name not in os.environ:
                raise ConfigError(f"environment variable '{name}' referenced but not set")
            return os.environ[name]

        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, dict):
        return {k: _resolve_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_env(v) for v in value]
    return value


def _build(cls, payload: Dict[str, Any], section: str):
    """Instantiate a dataclass, rejecting unknown keys (typo protection)."""
    known = {f.name for f in cls.__dataclass_fields__.values()}
    unknown = set(payload) - known
    if unknown:
        raise ConfigError(f"{section}: unknown key(s) {sorted(unknown)}")
    return cls(**payload)


def load_config(path: str) -> JobConfig:
    """Read, env-resolve and validate the job configuration JSON file."""
    if not os.path.isfile(path):
        raise ConfigError(f"configuration file not found: {path}")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"invalid JSON in {path}: {exc}") from exc

    raw = _resolve_env(raw)

    if "job_name" not in raw:
        raise ConfigError("'job_name' is required")

    gcs_payload = dict(raw.get("gcs", {}))
    retention_payload = gcs_payload.pop("retention", {})

    cfg = JobConfig(
        job_name=raw["job_name"],
        description=raw.get("description", ""),
        hdfs=_build(HdfsConfig, raw.get("hdfs", {}), "hdfs"),
        selection=_build(SelectionConfig, raw.get("selection", {}), "selection"),
        gcs=_build(GcsConfig, gcs_payload, "gcs"),
        db2=_build(Db2Config, raw.get("db2", {}), "db2"),
        runtime=_build(RuntimeConfig, raw.get("runtime", {}), "runtime"),
    )
    cfg.gcs.retention = _build(RetentionConfig, retention_payload, "gcs.retention")
    validate_config(cfg)
    return cfg


def validate_config(cfg: JobConfig) -> None:
    """Fail fast on semantically invalid configuration."""
    if cfg.hdfs.client not in VALID_HDFS_CLIENTS:
        raise ConfigError(f"hdfs.client must be one of {sorted(VALID_HDFS_CLIENTS)}")
    if cfg.hdfs.client == "webhdfs" and not cfg.hdfs.url:
        raise ConfigError("hdfs.url is required when hdfs.client == 'webhdfs'")
    if cfg.hdfs.client == "libhdfs" and not cfg.hdfs.namenode_host:
        raise ConfigError("hdfs.namenode_host is required when hdfs.client == 'libhdfs'")

    if not cfg.selection.source_paths:
        raise ConfigError("selection.source_paths must contain at least one path")
    cfg.selection.cutoff()  # raises if neither age_days nor older_than set
    if cfg.selection.age_basis == "path_partition" and not cfg.selection.partition_date_regex:
        raise ConfigError(
            "selection.partition_date_regex is required when age_basis == 'path_partition'"
        )

    if not cfg.gcs.bucket:
        raise ConfigError("gcs.bucket is required")
    if cfg.gcs.storage_class not in VALID_STORAGE_CLASSES:
        raise ConfigError(f"gcs.storage_class must be one of {sorted(VALID_STORAGE_CLASSES)}")
    if cfg.gcs.chunk_size_bytes % (256 * 1024) != 0:
        raise ConfigError("gcs.chunk_size_bytes must be a multiple of 256 KiB (GCS requirement)")

    if cfg.gcs.retention.mode not in VALID_RETENTION_MODES:
        raise ConfigError(f"gcs.retention.mode must be one of {sorted(VALID_RETENTION_MODES)}")
    if cfg.gcs.retention.retention_period_days <= 0:
        raise ConfigError("gcs.retention.retention_period_days must be > 0")

    if not cfg.db2.database or not cfg.db2.hostname:
        raise ConfigError("db2.database and db2.hostname are required")

    if not 1 <= cfg.runtime.max_workers <= 128:
        raise ConfigError("runtime.max_workers must be between 1 and 128")
    if cfg.runtime.delete_source_after_archive and not cfg.runtime.verify_checksum:
        raise ConfigError(
            "runtime.delete_source_after_archive requires runtime.verify_checksum = true"
        )
