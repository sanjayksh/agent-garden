"""Candidate-file discovery and eligibility filtering.

The scanner is a pure generator: it never materialises the full file list, so
memory is flat whether the directory holds 1,000 files or 5,000,000. The
orchestrator consumes it lazily and feeds a bounded work queue, which is what
keeps a nightly run's resident set predictable.
"""
from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, Iterator, Optional, Tuple

from ..config import SelectionConfig
from ..hdfs.base import HdfsFile, HdfsReader

LOGGER = logging.getLogger(__name__)


@dataclass
class ScanStats:
    scanned: int = 0
    eligible: int = 0
    excluded_by_age: int = 0
    excluded_by_pattern: int = 0
    excluded_by_size: int = 0
    excluded_by_format: int = 0
    excluded_already_archived: int = 0


class FileScanner:
    """Walks the configured source paths and yields eligible files."""

    def __init__(self, reader: HdfsReader, selection: SelectionConfig,
                 now: Optional[datetime] = None) -> None:
        self._reader = reader
        self._sel = selection
        self._now = now or datetime.now(timezone.utc)
        self._cutoff = selection.cutoff(self._now)
        self._partition_re = (
            re.compile(selection.partition_date_regex)
            if selection.partition_date_regex else None
        )
        self.stats = ScanStats()

    @property
    def cutoff(self) -> datetime:
        return self._cutoff

    # -- eligibility rules -------------------------------------------------- #
    def _effective_timestamp(self, f: HdfsFile) -> datetime:
        """Age basis.

        ``modification_time`` is the default. ``path_partition`` exists because
        Data Lake tables are usually written as ``.../dt=2019-04-01/part-*`` and
        a compaction or re-replication job can refresh the file mtime years
        after the business date. Deriving the date from the partition path keeps
        archival aligned with the *business* retention clock rather than an
        incidental filesystem event.
        """
        if self._sel.age_basis == "path_partition" and self._partition_re:
            match = self._partition_re.search(f.path)
            if match:
                raw = match.group(1) if match.groups() else match.group(0)
                for fmt in ("%Y-%m-%d", "%Y%m%d", "%Y/%m/%d", "%Y-%m", "%Y"):
                    try:
                        return datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
                    except ValueError:
                        continue
            LOGGER.debug("no partition date in %s; falling back to mtime", f.path)
        return f.modification_time

    def is_eligible(self, f: HdfsFile) -> Tuple[bool, str]:
        """Return ``(eligible, reason_if_not)``."""
        name = f.name
        for pattern in self._sel.exclude_globs:
            if fnmatch.fnmatch(name, pattern):
                self.stats.excluded_by_pattern += 1
                return False, f"excluded by glob '{pattern}'"
        if not any(fnmatch.fnmatch(name, p) for p in self._sel.include_globs):
            self.stats.excluded_by_pattern += 1
            return False, "did not match any include glob"

        if self._sel.include_formats:
            fmt = f.file_format.lower()
            allowed = {x.lower() for x in self._sel.include_formats}
            if fmt == "unknown" or fmt not in allowed:
                self.stats.excluded_by_format += 1
                return False, f"format '{f.file_format}' not in include_formats"

        if self._sel.skip_zero_byte_files and f.size_bytes == 0:
            self.stats.excluded_by_size += 1
            return False, "zero-byte file"
        if f.size_bytes < self._sel.min_size_bytes:
            self.stats.excluded_by_size += 1
            return False, f"smaller than min_size_bytes ({self._sel.min_size_bytes})"

        if self._effective_timestamp(f) >= self._cutoff:
            self.stats.excluded_by_age += 1
            return False, f"newer than cut-off {self._cutoff.isoformat()}"

        return True, ""

    # -- traversal ---------------------------------------------------------- #
    def scan(self, archived_index: Optional[Dict[str, datetime]] = None
             ) -> Iterator[Tuple[str, HdfsFile]]:
        """Yield ``(source_root, file)`` pairs for every eligible file."""
        archived_index = archived_index or {}
        emitted = 0
        limit = self._sel.max_files_per_run

        for root in self._sel.source_paths:
            LOGGER.info("scanning %s (cut-off %s)", root, self._cutoff.isoformat())
            for f in self._reader.walk(root, recursive=self._sel.recursive):
                self.stats.scanned += 1
                if self.stats.scanned % 50000 == 0:
                    LOGGER.info("scanned %d files so far...", self.stats.scanned)

                ok, reason = self.is_eligible(f)
                if not ok:
                    LOGGER.debug("skip %s: %s", f.path, reason)
                    continue

                previous = archived_index.get(f.path)
                if previous is not None and _same_instant(previous, f.modification_time):
                    self.stats.excluded_already_archived += 1
                    LOGGER.debug("skip %s: already archived", f.path)
                    continue

                self.stats.eligible += 1
                emitted += 1
                yield root, f

                if limit and emitted >= limit:
                    LOGGER.warning(
                        "max_files_per_run (%d) reached; remaining files deferred to "
                        "the next run", limit
                    )
                    return


def _same_instant(a: datetime, b: datetime, tolerance_seconds: int = 1) -> bool:
    """Compare timestamps tolerantly - Db2 and HDFS round differently."""
    if a.tzinfo is None:
        a = a.replace(tzinfo=timezone.utc)
    if b.tzinfo is None:
        b = b.replace(tzinfo=timezone.utc)
    return abs((a - b).total_seconds()) <= tolerance_seconds
