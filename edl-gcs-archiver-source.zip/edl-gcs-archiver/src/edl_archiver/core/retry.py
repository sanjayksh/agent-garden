"""Retry policy with exponential backoff and full jitter.

Full jitter (rather than plain exponential backoff) is deliberate: a nightly
run fans out to dozens of concurrent uploads, and an outage that fails them all
at the same instant would otherwise produce a synchronised retry storm against
either HttpFS or the GCS front end.
"""
from __future__ import annotations

import functools
import logging
import random
import time
from typing import Callable, Tuple, Type

from .. import errors

LOGGER = logging.getLogger(__name__)

DEFAULT_RETRYABLE: Tuple[Type[BaseException], ...] = (
    errors.RetryableError,
    ConnectionError,
    TimeoutError,
    OSError,
)


def retry(
    max_attempts: int = 4,
    initial_seconds: float = 2.0,
    max_seconds: float = 60.0,
    retryable: Tuple[Type[BaseException], ...] = DEFAULT_RETRYABLE,
):
    """Decorator applying bounded exponential backoff with full jitter."""

    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc: BaseException = RuntimeError("retry wrapper never executed")
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except retryable as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        break
                    ceiling = min(max_seconds, initial_seconds * (2 ** (attempt - 1)))
                    delay = random.uniform(0, ceiling)
                    LOGGER.warning(
                        "attempt %d/%d of %s failed (%s); retrying in %.1fs",
                        attempt, max_attempts, func.__name__, exc, delay,
                    )
                    time.sleep(delay)
            raise last_exc

        return wrapper

    return decorator
