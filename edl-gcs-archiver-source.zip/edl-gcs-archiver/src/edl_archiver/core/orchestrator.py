"""Run orchestration: concurrency, idempotency, failure policy, reporting.

Concurrency model
-----------------
The workload is entirely I/O bound - HDFS socket reads and HTTPS writes to GCS
- and both the ``requests`` stack and the GCS client release the GIL while
blocked on the network. A ``ThreadPoolExecutor`` therefore scales close to
linearly up to the point where the WAN link, HttpFS, or the GCS ingest quota
saturates, without the memory cost and IPC overhead of a process pool.

Files are submitted from a lazily-consumed generator behind a bounded
in-flight window (``max_workers x 2``). Submitting the whole scan up front
would force the executor to queue millions of futures and would defeat the
constant-memory design of the scanner.

Failure policy
--------------
* A per-file failure is recorded and the run continues.
* If the failure *rate* exceeds ``runtime.failure_threshold_pct`` the run is
  aborted, on the assumption that the cause is systemic (expired Kerberos
  ticket, revoked GCS credential, network partition) rather than data-specific.
"""
from __future__ import annotations

import getpass
import logging
import os
import socket
import threading
import uuid
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime, timezone
from typing import Optional

from ..config import JobConfig
from ..errors import ArchiverError, ChecksumMismatchError, RetryableError
from ..gcs.uploader import GcsUploader
from ..hdfs.base import HdfsFile, HdfsReader
from ..metadata.dao import ArchiveMetadataDao
from ..metadata.models import FileArchiveRecord, JobRunRecord
from .retry import retry
from .scanner import FileScanner

LOGGER = logging.getLogger(__name__)


class RunCounters:
    """Thread-safe counters shared by the worker threads."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.archived = 0
        self.skipped = 0
        self.failed = 0
        self.bytes_archived = 0

    def record(self, *, archived: int = 0, skipped: int = 0, failed: int = 0,
               size: int = 0) -> None:
        with self._lock:
            self.archived += archived
            self.skipped += skipped
            self.failed += failed
            self.bytes_archived += size

    @property
    def processed(self) -> int:
        return self.archived + self.skipped + self.failed

    def failure_rate_pct(self) -> float:
        total = self.processed
        return (self.failed / total * 100.0) if total else 0.0


class ArchivalOrchestrator:
    """Executes one archival run end to end."""

    def __init__(self, cfg: JobConfig, reader: HdfsReader, uploader: GcsUploader,
                 dao: ArchiveMetadataDao, config_path: str = "") -> None:
        self._cfg = cfg
        self._reader = reader
        self._uploader = uploader
        self._dao = dao
        self._config_path = config_path
        self._counters = RunCounters()
        self._abort = threading.Event()
        self.job_run_id = str(uuid.uuid4())

    # -- public entry point -------------------------------------------------- #
    def run(self) -> JobRunRecord:
        cfg = self._cfg
        started = datetime.now(timezone.utc)
        scanner = FileScanner(self._reader, cfg.selection, now=started)

        run_record = JobRunRecord(
            job_run_id=self.job_run_id,
            job_name=cfg.job_name,
            config_path=self._config_path,
            status="RUNNING",
            start_ts=started,
            cutoff_ts=scanner.cutoff,
            source_paths=",".join(cfg.selection.source_paths),
            target_bucket=cfg.gcs.bucket,
            hostname=socket.gethostname(),
            executed_by=_current_user(),
            dry_run="Y" if cfg.runtime.dry_run else "N",
        )
        self._dao.start_job_run(run_record)
        LOGGER.info(
            "job run %s started: job=%s cutoff=%s workers=%d dry_run=%s",
            self.job_run_id, cfg.job_name, scanner.cutoff.isoformat(),
            cfg.runtime.max_workers, cfg.runtime.dry_run,
        )

        error_message = ""
        try:
            archived_index = self._dao.load_archived_index(cfg.job_name)
            self._execute(scanner, archived_index, started)
        except KeyboardInterrupt:
            self._abort.set()
            error_message = "interrupted by operator"
            LOGGER.error(error_message)
        except Exception as exc:  # pragma: no cover - defensive
            self._abort.set()
            error_message = f"{type(exc).__name__}: {exc}"
            LOGGER.exception("run failed")
        finally:
            self._dao.flush()

        ended = datetime.now(timezone.utc)
        run_record.end_ts = ended
        run_record.duration_ms = int((ended - started).total_seconds() * 1000)
        run_record.files_scanned = scanner.stats.scanned
        run_record.files_eligible = scanner.stats.eligible
        run_record.files_archived = self._counters.archived
        run_record.files_skipped = self._counters.skipped + scanner.stats.excluded_already_archived
        run_record.files_failed = self._counters.failed
        run_record.bytes_archived = self._counters.bytes_archived
        run_record.error_message = error_message
        run_record.status = self._final_status(error_message)
        self._dao.finish_job_run(run_record)

        LOGGER.info(
            "job run %s finished: status=%s scanned=%d eligible=%d archived=%d "
            "skipped=%d failed=%d bytes=%d duration=%dms",
            self.job_run_id, run_record.status, run_record.files_scanned,
            run_record.files_eligible, run_record.files_archived,
            run_record.files_skipped, run_record.files_failed,
            run_record.bytes_archived, run_record.duration_ms,
        )
        return run_record

    # -- internals ----------------------------------------------------------- #
    def _final_status(self, error_message: str) -> str:
        if self._abort.is_set():
            return "ABORTED"
        if error_message:
            return "FAILED"
        if self._counters.failed and self._counters.archived:
            return "PARTIAL"
        if self._counters.failed:
            return "FAILED"
        return "SUCCEEDED"

    def _execute(self, scanner: FileScanner, archived_index, run_date: datetime) -> None:
        workers = self._cfg.runtime.max_workers
        window = max(workers * 2, workers + 4)
        pending = set()
        last_heartbeat = datetime.now(timezone.utc)

        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="archive") as pool:
            for source_root, hdfs_file in scanner.scan(archived_index):
                if self._abort.is_set():
                    break
                pending.add(pool.submit(self._process_one, source_root, hdfs_file, run_date))

                if len(pending) >= window:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    self._drain(done)
                    now = datetime.now(timezone.utc)
                    if (now - last_heartbeat).total_seconds() > 60:
                        self._dao.heartbeat(
                            self.job_run_id, self._counters.archived,
                            self._counters.bytes_archived,
                        )
                        last_heartbeat = now

            done, _ = wait(pending)
            self._drain(done)

    def _drain(self, futures) -> None:
        for future in futures:
            exc = future.exception()
            if exc is not None:  # pragma: no cover - worker swallows its own errors
                LOGGER.error("worker raised unexpectedly: %s", exc)
                self._counters.record(failed=1)
        self._check_failure_threshold()

    def _check_failure_threshold(self) -> None:
        threshold = self._cfg.runtime.failure_threshold_pct
        if (
            threshold > 0
            and self._counters.processed >= 50
            and self._counters.failure_rate_pct() > threshold
            and not self._abort.is_set()
        ):
            self._abort.set()
            LOGGER.error(
                "aborting run: failure rate %.1f%% exceeds threshold %.1f%% - "
                "this indicates a systemic fault, not bad data",
                self._counters.failure_rate_pct(), threshold,
            )

    # -- per-file pipeline ---------------------------------------------------- #
    def _process_one(self, source_root: str, hdfs_file: HdfsFile,
                     run_date: datetime) -> None:
        """Read one file from HDFS and stream it into GCS. Never raises."""
        cfg = self._cfg
        started = datetime.now(timezone.utc)
        object_name = self._uploader.build_object_name(
            hdfs_file, source_root, cfg.job_name, run_date
        )
        record = FileArchiveRecord(
            file_archive_id=str(uuid.uuid4()),
            job_run_id=self.job_run_id,
            job_name=cfg.job_name,
            source_path=hdfs_file.path,
            source_root=source_root,
            file_name=hdfs_file.name,
            file_format=hdfs_file.file_format,
            source_size_bytes=hdfs_file.size_bytes,
            source_mod_ts=hdfs_file.modification_time,
            gcs_bucket=cfg.gcs.bucket,
            gcs_object=object_name,
            retention_mode=cfg.gcs.retention.mode,
            retention_period_days=cfg.gcs.retention.retention_period_days,
            data_classification=cfg.gcs.retention.classification,
            upload_start_ts=started,
        )

        try:
            if cfg.runtime.dry_run:
                record.status = "SKIPPED"
                record.error_message = "dry_run"
                self._counters.record(skipped=1)
                LOGGER.info("[dry-run] would archive %s -> gs://%s/%s",
                            hdfs_file.path, cfg.gcs.bucket, object_name)
                self._dao.record_file(record)
                return

            if self._uploader.object_exists(object_name, hdfs_file.size_bytes):
                record.status = "SKIPPED"
                record.error_message = "object already present in bucket"
                record.upload_end_ts = datetime.now(timezone.utc)
                self._counters.record(skipped=1)
                self._dao.record_file(record)
                return

            result = self._upload_with_retry(hdfs_file, object_name, source_root)

            record.gcs_generation = result.generation
            record.storage_class = result.storage_class
            record.crc32c = result.crc32c
            record.md5_hash = result.md5 or ""
            record.retain_until_ts = result.retain_until
            record.duration_ms = result.duration_ms
            record.upload_end_ts = datetime.now(timezone.utc)
            record.throughput_mbps = _mbps(result.size_bytes, result.duration_ms)
            record.status = "ARCHIVED"
            self._counters.record(archived=1, size=result.size_bytes)

        except ChecksumMismatchError as exc:
            record.status = "QUARANTINED"
            record.error_message = str(exc)
            record.upload_end_ts = datetime.now(timezone.utc)
            self._counters.record(failed=1)
            LOGGER.error("integrity failure for %s: %s", hdfs_file.path, exc)
        except (ArchiverError, OSError) as exc:
            record.status = "FAILED"
            record.error_message = f"{type(exc).__name__}: {exc}"
            record.upload_end_ts = datetime.now(timezone.utc)
            self._counters.record(failed=1)
            LOGGER.error("failed to archive %s: %s", hdfs_file.path, exc)
        except Exception as exc:  # pragma: no cover - defensive
            record.status = "FAILED"
            record.error_message = f"unexpected {type(exc).__name__}: {exc}"
            record.upload_end_ts = datetime.now(timezone.utc)
            self._counters.record(failed=1)
            LOGGER.exception("unexpected error archiving %s", hdfs_file.path)

        try:
            self._dao.record_file(record)
        except Exception:  # pragma: no cover
            LOGGER.exception("could not persist metadata for %s", hdfs_file.path)

    def _upload_with_retry(self, hdfs_file: HdfsFile, object_name: str, source_root: str):
        """Open the HDFS stream and pipe it to GCS, retrying transient faults.

        The retry wraps *both* the open and the upload: a resumable session
        cannot be replayed from a consumed stream, so a retry must re-open the
        HDFS file from byte zero. That is why the stream is opened inside the
        retried function rather than passed into it.
        """
        rt = self._cfg.runtime

        @retry(
            max_attempts=rt.max_attempts,
            initial_seconds=rt.backoff_initial_seconds,
            max_seconds=rt.backoff_max_seconds,
            retryable=(RetryableError, ConnectionError, TimeoutError, OSError),
        )
        def _attempt():
            with self._reader.open(hdfs_file.path, self._cfg.hdfs.read_chunk_bytes) as stream:
                return self._uploader.upload_stream(
                    stream=stream,
                    object_name=object_name,
                    source_file=hdfs_file,
                    source_root=source_root,
                    verify_checksum=rt.verify_checksum,
                )

        return _attempt()


def _mbps(size_bytes: int, duration_ms: int) -> float:
    if duration_ms <= 0:
        return 0.0
    return (size_bytes * 8 / 1_000_000) / (duration_ms / 1000.0)


def _current_user() -> str:
    try:
        return getpass.getuser()
    except Exception:  # pragma: no cover
        return os.environ.get("USER", "unknown")
