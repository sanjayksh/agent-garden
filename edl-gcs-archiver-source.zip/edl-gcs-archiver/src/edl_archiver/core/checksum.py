"""End-to-end integrity verification.

HDFS's native checksum (MD5-of-MD5-of-CRC32C) depends on the source cluster's
block and chunk sizes, so it cannot be compared with anything GCS returns. The
only sound way to prove that what landed in the bucket is byte-identical to what
left the Data Lake is to compute a checksum over the bytes *as they pass
through this process*, and compare it against the checksum GCS independently
computed over the bytes it received.

GCS returns a CRC32C (Castagnoli) digest for every object, so CRC32C is the
natural choice. ``google-crc32c`` uses a hardware-accelerated (SSE4.2 / ARMv8
CRC) implementation, costing well under 1% of the wall time of the transfer.
"""
from __future__ import annotations

import base64
import hashlib
from typing import IO, Optional, Tuple

try:  # pragma: no cover - optional native dependency
    import google_crc32c

    _HAS_CRC32C = True
except ImportError:  # pragma: no cover
    _HAS_CRC32C = False


class TeeChecksum:
    """Wraps a readable stream and digests every byte that flows through it.

    The wrapper is transparent: the GCS writer reads from it exactly as it
    would from the raw HDFS stream, so verification adds no extra pass over
    the data and no extra HDFS read.
    """

    def __init__(self, stream: "IO[bytes]", compute_md5: bool = False) -> None:
        self._stream = stream
        self._crc = google_crc32c.Checksum() if _HAS_CRC32C else None
        self._md5 = hashlib.md5() if compute_md5 else None  # noqa: S324 - integrity, not security
        self.bytes_read = 0

    def read(self, size: int = -1) -> bytes:
        data = self._stream.read(size)
        if data:
            self.bytes_read += len(data)
            if self._crc is not None:
                self._crc.update(data)
            if self._md5 is not None:
                self._md5.update(data)
        return data

    # Some writers probe for these attributes.
    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    def close(self) -> None:
        self._stream.close()

    def __enter__(self) -> "TeeChecksum":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    # -- digests ----------------------------------------------------------- #
    @property
    def crc32c_b64(self) -> Optional[str]:
        """Base64 big-endian CRC32C, the exact encoding GCS reports."""
        if self._crc is None:
            return None
        return base64.b64encode(self._crc.digest()).decode("ascii")

    @property
    def md5_b64(self) -> Optional[str]:
        if self._md5 is None:
            return None
        return base64.b64encode(self._md5.digest()).decode("ascii")

    @property
    def md5_hex(self) -> Optional[str]:
        return self._md5.hexdigest() if self._md5 is not None else None

    def digests(self) -> Tuple[Optional[str], Optional[str]]:
        return self.crc32c_b64, self.md5_b64
