"""Command-line entry point.

Exit codes (contract with the enterprise scheduler - Control-M / Autosys):

  0  SUCCEEDED  - every eligible file archived
  1  FAILED     - run failed, or every file failed
  2  CONFIG     - configuration invalid; scheduler should not retry
  3  PARTIAL    - some files archived, some failed; operations to review
  4  LOCKED     - another instance is running; not an error
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone

from .config import load_config
from .errors import ConfigError
from .gcs.uploader import GcsUploader
from .hdfs.factory import create_hdfs_reader
from .lock import LockAcquisitionError, single_instance
from .logging_setup import configure_logging
from .metadata.dao import ArchiveMetadataDao
from .metadata.db2_client import Db2ConnectionPool
from .core.orchestrator import ArchivalOrchestrator

EXIT_OK, EXIT_FAILED, EXIT_CONFIG, EXIT_PARTIAL, EXIT_LOCKED = 0, 1, 2, 3, 4


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="edl-archive",
        description="Archive files from the on-premise Enterprise Data Lake (HDFS) "
                    "to Google Cloud Storage with retention metadata.",
    )
    parser.add_argument("--config", "-c", required=True, help="path to the job configuration JSON")
    parser.add_argument("--dry-run", action="store_true",
                        help="scan and report, upload nothing")
    parser.add_argument("--max-files", type=int, default=None,
                        help="override selection.max_files_per_run")
    parser.add_argument("--workers", type=int, default=None,
                        help="override runtime.max_workers")
    parser.add_argument("--log-level", default=None, choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--validate-only", action="store_true",
                        help="validate configuration and connectivity, then exit")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        return EXIT_CONFIG

    if args.dry_run:
        cfg.runtime.dry_run = True
    if args.max_files is not None:
        cfg.selection.max_files_per_run = args.max_files
    if args.workers is not None:
        cfg.runtime.max_workers = args.workers
    if args.log_level:
        cfg.runtime.log_level = args.log_level

    logger = configure_logging(
        level=cfg.runtime.log_level,
        log_file=cfg.runtime.log_file.format(job_name=cfg.job_name) or None,
        job_run_id="pending",
    )
    logger.info("edl-archive starting for job '%s'", cfg.job_name)

    lock_path = cfg.runtime.lock_file.format(job_name=cfg.job_name)
    try:
        with single_instance(lock_path):
            return _run(cfg, args)
    except LockAcquisitionError as exc:
        logger.warning(str(exc))
        return EXIT_LOCKED


def _run(cfg, args) -> int:
    pool = Db2ConnectionPool(cfg.db2)
    if not pool.healthcheck():
        print("Db2 metadata store is not reachable", file=sys.stderr)
        return EXIT_FAILED
    dao = ArchiveMetadataDao(pool, schema=cfg.db2.schema, batch_size=cfg.db2.batch_size)

    reader = create_hdfs_reader(cfg.hdfs)
    uploader = GcsUploader(cfg.gcs)

    if args.validate_only:
        probe = cfg.selection.source_paths[0]
        reader.status(probe)
        print(f"configuration valid; HDFS reachable; Db2 reachable; bucket={cfg.gcs.bucket}")
        reader.close()
        pool.close()
        return EXIT_OK

    orchestrator = ArchivalOrchestrator(cfg, reader, uploader, dao, config_path=args.config)
    configure_logging(
        level=cfg.runtime.log_level,
        log_file=cfg.runtime.log_file.format(job_name=cfg.job_name) or None,
        job_run_id=orchestrator.job_run_id,
    )
    try:
        result = orchestrator.run()
    finally:
        reader.close()
        pool.close()

    _print_summary(result)
    return {
        "SUCCEEDED": EXIT_OK,
        "PARTIAL": EXIT_PARTIAL,
        "FAILED": EXIT_FAILED,
        "ABORTED": EXIT_FAILED,
    }.get(result.status, EXIT_FAILED)


def _print_summary(result) -> None:
    gib = result.bytes_archived / (1024 ** 3)
    seconds = max(result.duration_ms / 1000.0, 0.001)
    print(
        "\n"
        f"  Job run id .......... {result.job_run_id}\n"
        f"  Job name ............ {result.job_name}\n"
        f"  Status .............. {result.status}\n"
        f"  Cut-off ............. {result.cutoff_ts}\n"
        f"  Files scanned ....... {result.files_scanned:,}\n"
        f"  Files eligible ...... {result.files_eligible:,}\n"
        f"  Files archived ...... {result.files_archived:,}\n"
        f"  Files skipped ....... {result.files_skipped:,}\n"
        f"  Files failed ........ {result.files_failed:,}\n"
        f"  Data archived ....... {gib:,.2f} GiB\n"
        f"  Duration ............ {seconds:,.1f} s\n"
        f"  Aggregate throughput  {gib * 1024 / seconds:,.1f} MiB/s\n"
        f"  Completed at ........ {datetime.now(timezone.utc).isoformat()}\n"
    )


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
