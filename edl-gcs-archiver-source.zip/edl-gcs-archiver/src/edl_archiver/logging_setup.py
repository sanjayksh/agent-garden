"""Structured (JSON) logging configuration.

ABC Bank's operations tooling ingests newline-delimited JSON, so every log
record is emitted as a single JSON object enriched with the job run id. This
makes per-run log retrieval a single indexed query in the log platform.
"""
from __future__ import annotations

import logging
import logging.handlers
import os
import sys
from typing import Optional

try:  # pragma: no cover - optional dependency
    from pythonjsonlogger import jsonlogger

    _HAS_JSON_LOGGER = True
except ImportError:  # pragma: no cover
    _HAS_JSON_LOGGER = False


class JobRunFilter(logging.Filter):
    """Injects the current job_run_id into every record."""

    def __init__(self, job_run_id: str = "-") -> None:
        super().__init__()
        self.job_run_id = job_run_id

    def filter(self, record: logging.LogRecord) -> bool:
        record.job_run_id = self.job_run_id
        record.host = os.uname().nodename if hasattr(os, "uname") else "unknown"
        return True


def configure_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    job_run_id: str = "-",
    json_output: bool = True,
) -> logging.Logger:
    """Configure the root logger. Idempotent - safe to call more than once."""
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    for handler in list(root.handlers):
        root.removeHandler(handler)

    fmt = "%(asctime)s %(levelname)s %(name)s %(job_run_id)s %(host)s %(message)s"
    if json_output and _HAS_JSON_LOGGER:
        formatter: logging.Formatter = jsonlogger.JsonFormatter(fmt)
    else:
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | run=%(job_run_id)s | %(message)s"
        )

    run_filter = JobRunFilter(job_run_id)

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    stream.addFilter(run_filter)
    root.addHandler(stream)

    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        rotating = logging.handlers.RotatingFileHandler(
            log_file, maxBytes=256 * 1024 * 1024, backupCount=10
        )
        rotating.setFormatter(formatter)
        rotating.addFilter(run_filter)
        root.addHandler(rotating)

    # Third-party libraries are verbose at INFO; keep them at WARNING.
    for noisy in ("urllib3", "google.auth", "google.resumable_media", "hdfs.client"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    return logging.getLogger("edl_archiver")
