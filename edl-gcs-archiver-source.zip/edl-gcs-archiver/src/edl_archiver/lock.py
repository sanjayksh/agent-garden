"""Single-instance guard.

The nightly schedule can overlap with a long-running catch-up run. Two
concurrent runs against the same source would double the load on HttpFS and
produce duplicate metadata churn, so the job takes an exclusive advisory file
lock and exits with a distinct code if it cannot obtain it.
"""
from __future__ import annotations

import errno
import logging
import os
from contextlib import contextmanager
from typing import Iterator

LOGGER = logging.getLogger(__name__)


class LockAcquisitionError(RuntimeError):
    """Another instance of this job is already running."""


@contextmanager
def single_instance(lock_path: str) -> Iterator[None]:
    import fcntl

    directory = os.path.dirname(lock_path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    handle = open(lock_path, "w", encoding="utf-8")
    try:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            if exc.errno in (errno.EACCES, errno.EAGAIN):
                raise LockAcquisitionError(
                    f"another instance holds {lock_path}; exiting without action"
                ) from exc
            raise
        handle.write(str(os.getpid()))
        handle.flush()
        LOGGER.info("acquired instance lock %s", lock_path)
        yield
    finally:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()
