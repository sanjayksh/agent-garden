"""Exception hierarchy for the archival application.

A narrow, explicit hierarchy lets the orchestrator distinguish *retryable*
infrastructure faults from *terminal* data/config faults, so that a single bad
file never aborts an entire nightly run.
"""


class ArchiverError(Exception):
    """Base class for every error raised by this application."""


class ConfigError(ArchiverError):
    """Job configuration file is missing, malformed or semantically invalid."""


class RetryableError(ArchiverError):
    """Transient fault; the operation may succeed if attempted again."""


class TerminalError(ArchiverError):
    """Permanent fault; retrying will not help. File is quarantined."""


class HdfsError(ArchiverError):
    """Failure while listing or reading from HDFS."""


class HdfsRetryableError(HdfsError, RetryableError):
    """Transient HDFS fault (NameNode failover, DataNode timeout, 5xx)."""


class GcsUploadError(ArchiverError):
    """Failure while uploading to or mutating an object in GCS."""


class GcsRetryableError(GcsUploadError, RetryableError):
    """Transient GCS fault (429, 5xx, connection reset)."""


class ChecksumMismatchError(TerminalError):
    """CRC32C computed on the HDFS stream != CRC32C reported by GCS."""


class MetadataStoreError(ArchiverError):
    """Failure while reading from or writing to the Db2 metadata store."""
