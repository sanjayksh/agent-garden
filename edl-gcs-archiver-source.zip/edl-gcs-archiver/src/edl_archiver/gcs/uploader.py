"""Google Cloud Storage upload and retention layer.

Design decisions
----------------
1. **Streaming resumable upload.** ``blob.open("wb")`` returns a ``BlobWriter``
   that performs a resumable upload in ``chunk_size`` increments. Because we
   copy from the HDFS stream into that writer, a 40 GiB Parquet file never
   exists on local disk or in the heap - only one chunk at a time does. This
   removes the need for staging storage on the archival host entirely.

2. **Integrity.** GCS computes CRC32C over what it received; we compute CRC32C
   over what we sent (see ``core.checksum``). Equality proves the object is
   byte-identical to the source. Only after that check does the run record the
   file as ``ARCHIVED``.

3. **Retention.** Three independent mechanisms are supported because they solve
   different problems and banks usually need more than one:

   * ``object_lock``   - per-object retention configuration (requires a bucket
     created with object retention enabled). Sets ``retainUntilTime``; the
     object cannot be deleted or overwritten until then. Optionally locked,
     which makes even the retention date itself immutable.
   * ``event_based_hold`` - object cannot be deleted until the hold is released;
     the bucket's default retention clock starts on release. This is the right
     model when the retention period starts at an event (account closure)
     rather than at ingest.
   * ``custom_time_only`` - sets ``customTime`` and custom metadata only, and
     lets bucket lifecycle rules do the deletion. Cheapest, but advisory.

   In every mode the human-readable retention facts are *also* written to the
   object's custom metadata, so an auditor reading object metadata sees the
   policy without needing IAM to read bucket configuration.
"""
from __future__ import annotations

import logging
import posixpath
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import IO, Dict, Optional

from ..config import GcsConfig, RetentionConfig
from ..core.checksum import TeeChecksum
from ..errors import ChecksumMismatchError, GcsRetryableError, GcsUploadError
from ..hdfs.base import HdfsFile

LOGGER = logging.getLogger(__name__)

_CONTENT_TYPES = {
    "json": "application/json",
    "jsonl": "application/x-ndjson",
    "csv": "text/csv",
    "tsv": "text/tab-separated-values",
    "txt": "text/plain",
    "avro": "application/avro",
    "parquet": "application/vnd.apache.parquet",
    "orc": "application/x-orc",
    "gz": "application/gzip",
}


@dataclass
class UploadResult:
    """Everything the metadata store needs to record about one object."""

    bucket: str
    object_name: str
    generation: int
    size_bytes: int
    crc32c: str
    md5: Optional[str]
    storage_class: str
    retain_until: Optional[datetime]
    retention_mode: str
    duration_ms: int
    skipped: bool = False
    skip_reason: str = ""


class GcsUploader:
    """Thread-safe wrapper around the GCS Python client.

    A single ``storage.Client`` is shared by every worker thread. The client is
    thread-safe and internally pools HTTPS connections, so sharing it avoids
    re-running the OAuth token exchange (and TLS handshake) per file.
    """

    def __init__(self, cfg: GcsConfig, client=None) -> None:
        self._cfg = cfg
        self._client = client or self._build_client(cfg)
        self._bucket = self._client.bucket(cfg.bucket)

    # -- construction ------------------------------------------------------ #
    @staticmethod
    def _build_client(cfg: GcsConfig):
        from google.cloud import storage

        if cfg.credentials_file:
            client = storage.Client.from_service_account_json(
                cfg.credentials_file, project=cfg.project_id or None
            )
        else:
            # Application Default Credentials. In production this resolves to
            # Workload Identity Federation, so no service-account key ever
            # exists on the on-premise host.
            client = storage.Client(project=cfg.project_id or None)
        return client

    # -- object naming ----------------------------------------------------- #
    def build_object_name(self, source_file: HdfsFile, source_root: str, job_name: str,
                          run_date: datetime) -> str:
        """Deterministically map an HDFS path to a GCS object name.

        Determinism matters: it is what makes the job idempotent. Re-running
        the same day for the same file produces the same object name, so the
        pre-flight existence check can short-circuit a redundant transfer.
        """
        prefix = self._cfg.object_prefix_template.format(
            job_name=job_name,
            source_root=source_root.strip("/").replace("/", "_"),
            yyyy=f"{run_date:%Y}",
            mm=f"{run_date:%m}",
            dd=f"{run_date:%d}",
            run_date=f"{run_date:%Y-%m-%d}",
        )
        if self._cfg.preserve_source_path:
            relative = source_file.path
            if source_root and source_file.path.startswith(source_root):
                relative = source_file.path[len(source_root):]
            relative = relative.lstrip("/")
        else:
            relative = source_file.name
        return posixpath.join(prefix.strip("/"), relative)

    @staticmethod
    def _content_type(source_file: HdfsFile) -> str:
        return _CONTENT_TYPES.get(source_file.file_format.lower(), "application/octet-stream")

    # -- retention --------------------------------------------------------- #
    def _retention_metadata(self, source_file: HdfsFile, retain_until: Optional[datetime],
                            retention: RetentionConfig, source_root: str) -> Dict[str, str]:
        meta = {
            "edl_source_path": source_file.path,
            "edl_source_root": source_root,
            "edl_source_size_bytes": str(source_file.size_bytes),
            "edl_source_mtime_utc": source_file.modification_time.isoformat(),
            "edl_file_format": source_file.file_format,
            "retention_period_days": str(retention.retention_period_days),
            "data_classification": retention.classification,
            "archived_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        if retain_until:
            meta["retain_until_utc"] = retain_until.isoformat()
        if retention.record_code:
            meta["records_schedule_code"] = retention.record_code
        if retention.legal_hold:
            meta["legal_hold"] = "true"
        meta.update(retention.custom_metadata)
        return meta

    def _apply_retention(self, blob, retain_until: Optional[datetime],
                         retention: RetentionConfig) -> None:
        """Applies the immutability controls after the bytes have landed."""
        if retention.mode == "object_lock" and retain_until is not None:
            try:
                from google.cloud.storage.retention import Retention

                blob.retention = Retention(
                    blob,
                    mode="Locked" if retention.lock_retention else "Unlocked",
                    retain_until_time=retain_until,
                )
                blob.patch(override_unlocked_retention=True)
            except ImportError:  # pragma: no cover - older client library
                LOGGER.warning(
                    "google-cloud-storage is too old for per-object retention; "
                    "falling back to bucket default retention for %s", blob.name
                )
            except Exception as exc:
                raise GcsUploadError(
                    f"failed to apply object retention to {blob.name}: {exc}"
                ) from exc
        elif retention.mode == "event_based_hold":
            blob.event_based_hold = True
            blob.patch()

        if retention.legal_hold:
            blob.temporary_hold = True
            blob.patch()

    # -- upload ------------------------------------------------------------ #
    def object_exists(self, object_name: str, expected_size: int) -> bool:
        """Idempotency pre-flight.

        If an object of the same name and byte length already exists, the file
        was archived by a previous (possibly partially failed) run and is
        skipped. This is what makes the nightly job safe to re-run at any time.
        """
        blob = self._bucket.get_blob(object_name)
        return blob is not None and blob.size == expected_size

    def upload_stream(
        self,
        stream: "IO[bytes]",
        object_name: str,
        source_file: HdfsFile,
        source_root: str,
        verify_checksum: bool = True,
    ) -> UploadResult:
        """Stream ``stream`` into ``object_name`` and apply retention."""
        started = datetime.now(timezone.utc)
        retention = self._cfg.retention
        retain_until = None
        if retention.mode in ("object_lock", "custom_time_only"):
            retain_until = started + timedelta(days=retention.retention_period_days)

        blob = self._bucket.blob(
            object_name,
            chunk_size=self._cfg.chunk_size_bytes,
            kms_key_name=self._cfg.kms_key_name or None,
        )
        blob.content_type = self._content_type(source_file)
        blob.storage_class = self._cfg.storage_class
        blob.custom_time = retain_until or started
        blob.metadata = self._retention_metadata(
            source_file, retain_until, retention, source_root
        )

        tee = TeeChecksum(stream)
        try:
            # Resumable, chunked, constant-memory upload.
            with blob.open(
                "wb",
                chunk_size=self._cfg.chunk_size_bytes,
                timeout=self._cfg.upload_timeout_seconds,
                if_generation_match=None,
            ) as writer:
                while True:
                    buffer = tee.read(self._cfg.chunk_size_bytes)
                    if not buffer:
                        break
                    writer.write(buffer)
        except Exception as exc:
            if _is_retryable(exc):
                raise GcsRetryableError(f"upload of {object_name} failed: {exc}") from exc
            raise GcsUploadError(f"upload of {object_name} failed: {exc}") from exc

        blob.reload()

        local_crc = tee.crc32c_b64
        if verify_checksum and local_crc and blob.crc32c and local_crc != blob.crc32c:
            # Delete the corrupt object so a retry cannot mistake it for a
            # completed archive.
            try:
                blob.delete()
            except Exception:  # pragma: no cover
                LOGGER.error("could not delete corrupt object %s", object_name)
            raise ChecksumMismatchError(
                f"CRC32C mismatch for {source_file.path}: "
                f"source={local_crc} gcs={blob.crc32c}"
            )

        self._apply_retention(blob, retain_until, retention)

        duration_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        LOGGER.info(
            "archived %s -> gs://%s/%s (%d bytes in %d ms, %.1f MiB/s)",
            source_file.path, self._cfg.bucket, object_name, tee.bytes_read, duration_ms,
            (tee.bytes_read / 1048576) / max(duration_ms / 1000, 0.001),
        )
        return UploadResult(
            bucket=self._cfg.bucket,
            object_name=object_name,
            generation=int(blob.generation or 0),
            size_bytes=tee.bytes_read,
            crc32c=blob.crc32c or local_crc or "",
            md5=blob.md5_hash,
            storage_class=blob.storage_class or self._cfg.storage_class,
            retain_until=retain_until,
            retention_mode=retention.mode,
            duration_ms=duration_ms,
        )


def _is_retryable(exc: BaseException) -> bool:
    """Classify a GCS client exception as transient or terminal."""
    status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    if isinstance(status, int) and (status == 429 or 500 <= status < 600):
        return True
    return isinstance(exc, (ConnectionError, TimeoutError, OSError))
