"""Abstract HDFS access layer.

Two concrete implementations are shipped:

* ``WebHdfsReader``  - pure Python, talks the WebHDFS/HttpFS REST protocol.
                       No JVM, no native libraries, no Hadoop client on the
                       archival host. This is the default and the recommended
                       deployment for ABC Bank.
* ``LibHdfsReader``  - PyArrow's ``HadoopFileSystem`` binding over the native
                       ``libhdfs`` JNI bridge. Higher single-stream throughput
                       (short-circuit local reads, direct DataNode RPC) at the
                       cost of requiring a JVM and the Hadoop classpath.

Both expose exactly the same contract, so the storage protocol is an operational
decision recorded in the job configuration - not a code change.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import IO, Iterator, Optional


@dataclass(frozen=True)
class HdfsFile:
    """A single candidate file discovered on HDFS."""

    path: str                 # absolute HDFS path
    size_bytes: int
    modification_time: datetime   # timezone-aware, UTC
    owner: str = ""
    group: str = ""
    permission: str = ""
    replication: int = 0
    block_size: int = 0

    @property
    def name(self) -> str:
        return self.path.rsplit("/", 1)[-1]

    @property
    def file_format(self) -> str:
        """Best-effort format classification used for reporting and lifecycle."""
        lowered = self.name.lower()
        for ext in (".parquet", ".avro", ".orc", ".json", ".jsonl", ".csv", ".tsv",
                    ".txt", ".gz", ".snappy", ".bz2", ".seq"):
            if lowered.endswith(ext):
                return ext.lstrip(".").upper()
        return "UNKNOWN"

    @staticmethod
    def epoch_millis_to_utc(millis: int) -> datetime:
        return datetime.fromtimestamp(millis / 1000.0, tz=timezone.utc)


class HdfsReader(abc.ABC):
    """Protocol-agnostic read-only interface to the Enterprise Data Lake."""

    @abc.abstractmethod
    def walk(self, path: str, recursive: bool = True) -> Iterator[HdfsFile]:
        """Yield every *file* (never a directory) beneath ``path``.

        Implementations must stream results - directories in the Data Lake
        routinely hold hundreds of thousands of entries and the listing must
        never be materialised in memory in full.
        """

    @abc.abstractmethod
    def open(self, path: str, chunk_size: int) -> "IO[bytes]":
        """Return a context-managed, binary, read-only, streaming file object.

        The returned object is used with ``with`` and supports ``.read(n)``.
        It is never fully buffered: bytes flow HDFS -> memory window -> GCS.
        """

    @abc.abstractmethod
    def status(self, path: str) -> Optional[HdfsFile]:
        """Return metadata for a single path, or ``None`` if absent."""

    def close(self) -> None:  # pragma: no cover - default no-op
        """Release any underlying sessions/connections."""

    def __enter__(self) -> "HdfsReader":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()
