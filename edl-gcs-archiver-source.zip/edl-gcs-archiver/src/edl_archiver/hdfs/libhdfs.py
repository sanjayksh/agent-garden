"""Native (libhdfs) implementation of :class:`HdfsReader` via PyArrow.

Use this profile when the archival host is an existing Hadoop edge node and the
bank wants maximum single-stream throughput. ``pyarrow.fs.HadoopFileSystem``
loads ``libhdfs.so`` through JNI, which means the process talks the native
Hadoop RPC protocol directly to the DataNodes and can exploit short-circuit
local reads when co-located.

Prerequisites on the host
-------------------------
* A JVM, with ``JAVA_HOME`` exported.
* ``HADOOP_HOME`` and ``CLASSPATH`` populated - typically
  ``export CLASSPATH=$(hadoop classpath --glob)``.
* ``ARROW_LIBHDFS_DIR`` pointing at the directory containing ``libhdfs.so``.
* A valid Kerberos credential cache (``kerb_ticket``).

Trade-off: roughly 1.5-2x the per-stream throughput of HttpFS, but the host is
no longer a self-contained Python deployment and JVM heap must be sized and
monitored.
"""
from __future__ import annotations

import logging
import posixpath
from typing import IO, Iterator, Optional

from ..errors import HdfsError, HdfsRetryableError
from .base import HdfsFile, HdfsReader

LOGGER = logging.getLogger(__name__)


class LibHdfsReader(HdfsReader):
    """PyArrow-backed HDFS client."""

    def __init__(
        self,
        host: str,
        port: int = 8020,
        user: str = "",
        kerb_ticket: str = "",
        extra_conf: Optional[dict] = None,
        filesystem=None,
    ) -> None:
        if filesystem is not None:
            self._fs = filesystem
            return
        try:
            from pyarrow import fs as arrow_fs
        except ImportError as exc:  # pragma: no cover
            raise HdfsError(
                "pyarrow is required for hdfs.client == 'libhdfs'. "
                "Install pyarrow and ensure JAVA_HOME/CLASSPATH are configured."
            ) from exc
        try:
            self._fs = arrow_fs.HadoopFileSystem(
                host=host,
                port=port,
                user=user or None,
                kerb_ticket=kerb_ticket or None,
                extra_conf=extra_conf or None,
            )
        except Exception as exc:
            raise HdfsError(f"unable to initialise libhdfs for {host}:{port}: {exc}") from exc

    # -- HdfsReader contract ---------------------------------------------- #
    def walk(self, path: str, recursive: bool = True) -> Iterator[HdfsFile]:
        from pyarrow.fs import FileSelector, FileType

        selector = FileSelector(path, recursive=recursive, allow_not_found=False)
        try:
            infos = self._fs.get_file_info(selector)
        except Exception as exc:
            raise HdfsRetryableError(f"libhdfs listing failed for {path}: {exc}") from exc

        for info in infos:
            if info.type != FileType.File:
                continue
            yield HdfsFile(
                path=info.path,
                size_bytes=info.size or 0,
                modification_time=info.mtime,
            )

    def open(self, path: str, chunk_size: int) -> "IO[bytes]":
        try:
            return self._fs.open_input_stream(path, buffer_size=chunk_size)
        except Exception as exc:
            raise HdfsRetryableError(f"libhdfs open failed for {path}: {exc}") from exc

    def status(self, path: str) -> Optional[HdfsFile]:
        from pyarrow.fs import FileType

        info = self._fs.get_file_info([path])[0]
        if info.type != FileType.File:
            return None
        return HdfsFile(
            path=info.path,
            size_bytes=info.size or 0,
            modification_time=info.mtime,
        )

    def close(self) -> None:  # pragma: no cover
        # PyArrow closes the JNI handle on garbage collection.
        self._fs = None
