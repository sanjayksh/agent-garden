"""Selects the HDFS access implementation named in the job configuration."""
from __future__ import annotations

import logging

from ..config import HdfsConfig
from ..errors import ConfigError
from .base import HdfsReader

LOGGER = logging.getLogger(__name__)


def create_hdfs_reader(cfg: HdfsConfig) -> HdfsReader:
    """Instantiate the configured reader. This is the only place either
    concrete implementation is referenced, which keeps the rest of the
    application protocol-agnostic and trivially unit-testable with a fake."""
    if cfg.client == "webhdfs":
        from .webhdfs import WebHdfsReader

        LOGGER.info("using WebHDFS/HttpFS reader endpoint=%s auth=%s", cfg.url, cfg.auth)
        return WebHdfsReader(
            url=cfg.url,
            auth=cfg.auth,
            user=cfg.user,
            verify_ssl=cfg.verify_ssl,
            timeout_seconds=cfg.timeout_seconds,
            list_batch_size=cfg.list_batch_size,
        )
    if cfg.client == "libhdfs":
        from .libhdfs import LibHdfsReader

        LOGGER.info("using native libhdfs reader namenode=%s:%s", cfg.namenode_host, cfg.namenode_port)
        return LibHdfsReader(
            host=cfg.namenode_host,
            port=cfg.namenode_port,
            user=cfg.user,
            kerb_ticket=cfg.kerb_ticket,
            extra_conf=cfg.extra_conf,
        )
    raise ConfigError(f"unsupported hdfs.client '{cfg.client}'")
