"""WebHDFS / HttpFS implementation of :class:`HdfsReader`.

Why this is the default for ABC Bank
------------------------------------
* No JVM, no ``libhdfs.so``, no Hadoop configuration files on the archival host
  - the application is a self-contained Python artefact, which is what the
  bank's standalone-application standard requires.
* Kerberos SPNEGO is negotiated over HTTPS through ``requests-kerberos``; the
  service principal's TGT is obtained from the credential cache refreshed by
  the platform's ``k5start``/cron keytab job.
* HttpFS presents a single, load-balanced, firewall-friendly TCP endpoint
  (port 14000). Direct WebHDFS on the NameNode (port 9870) issues HTTP 307
  redirects to individual DataNodes, which requires every DataNode to be
  reachable from the archival host - usually unacceptable in a segmented
  network. HttpFS proxies the data path and avoids that entirely.

Streaming contract
------------------
``open()`` returns a file-like object backed by ``requests`` with
``stream=True``. Bytes are pulled from HDFS only as fast as the GCS writer
consumes them, so peak heap stays at roughly
``max_workers x (hdfs_chunk + gcs_chunk)`` regardless of file size. A 40 GiB
Parquet file and a 4 KiB control file cost the same memory.
"""
from __future__ import annotations

import io
import logging
import posixpath
from datetime import datetime
from typing import IO, Iterator, Optional

from ..errors import HdfsError, HdfsRetryableError
from .base import HdfsFile, HdfsReader

LOGGER = logging.getLogger(__name__)

_RETRYABLE_STATUS = {408, 425, 429, 500, 502, 503, 504}


class _StreamingResponseReader(io.RawIOBase):
    """Adapts a streaming ``requests.Response`` to a binary file object.

    ``shutil.copyfileobj`` and the GCS ``BlobWriter`` both need a ``.read(n)``
    that blocks until ``n`` bytes (or EOF) are available; ``Response.raw`` does
    not guarantee that, so we buffer the shortfall here.
    """

    def __init__(self, response, chunk_size: int) -> None:
        self._response = response
        self._iterator = response.iter_content(chunk_size=chunk_size)
        self._buffer = bytearray()
        self._eof = False
        self._position = 0

    # -- io.RawIOBase contract ------------------------------------------- #
    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    def tell(self) -> int:
        return self._position

    def read(self, size: int = -1) -> bytes:  # type: ignore[override]
        if size is None or size < 0:
            while not self._eof:
                self._fill()
            data = bytes(self._buffer)
            self._buffer.clear()
            self._position += len(data)
            return data

        while len(self._buffer) < size and not self._eof:
            self._fill()
        data = bytes(self._buffer[:size])
        del self._buffer[: len(data)]
        self._position += len(data)
        return data

    def readinto(self, b) -> int:  # type: ignore[override]
        data = self.read(len(b))
        b[: len(data)] = data
        return len(data)

    def _fill(self) -> None:
        try:
            self._buffer.extend(next(self._iterator))
        except StopIteration:
            self._eof = True
        except Exception as exc:  # network fault mid-stream
            self._eof = True
            raise HdfsRetryableError(f"stream interrupted: {exc}") from exc

    def close(self) -> None:
        try:
            self._response.close()
        finally:
            super().close()


class WebHdfsReader(HdfsReader):
    """Read-only WebHDFS/HttpFS client."""

    def __init__(
        self,
        url: str,
        auth: str = "kerberos",
        user: str = "",
        verify_ssl=True,
        timeout_seconds: int = 120,
        list_batch_size: int = 1000,
        session=None,
    ) -> None:
        self._base = url.rstrip("/") + "/webhdfs/v1"
        self._timeout = timeout_seconds
        self._batch = list_batch_size
        self._verify = verify_ssl
        self._params = {}
        self._session = session or self._build_session(auth, user)
        if auth == "simple":
            if not user:
                raise HdfsError("hdfs.user is required when hdfs.auth == 'simple'")
            self._params["user.name"] = user

    # -- construction ------------------------------------------------------ #
    @staticmethod
    def _build_session(auth: str, user: str):
        import requests
        from requests.adapters import HTTPAdapter

        session = requests.Session()
        if auth == "kerberos":
            try:
                from requests_kerberos import DISABLED, HTTPKerberosAuth
            except ImportError as exc:  # pragma: no cover
                raise HdfsError(
                    "requests-kerberos is required for hdfs.auth == 'kerberos'"
                ) from exc
            session.auth = HTTPKerberosAuth(mutual_authentication=DISABLED)
        elif auth != "simple":
            raise HdfsError(f"unsupported hdfs.auth '{auth}'")

        # The connection pool must be at least as large as the worker pool or
        # threads will serialise on socket checkout - a classic and silent
        # throughput ceiling.
        adapter = HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    # -- helpers ----------------------------------------------------------- #
    def _request(self, path: str, op: str, stream: bool = False, **extra):
        params = dict(self._params, op=op, **extra)
        url = self._base + path
        try:
            response = self._session.get(
                url,
                params=params,
                stream=stream,
                timeout=self._timeout,
                verify=self._verify,
                allow_redirects=True,
            )
        except Exception as exc:
            raise HdfsRetryableError(f"WebHDFS transport failure for {path}: {exc}") from exc

        if response.status_code in _RETRYABLE_STATUS:
            raise HdfsRetryableError(
                f"WebHDFS {op} {path} returned HTTP {response.status_code}"
            )
        if response.status_code == 404:
            return None
        if response.status_code >= 400:
            raise HdfsError(
                f"WebHDFS {op} {path} returned HTTP {response.status_code}: "
                f"{response.text[:512]}"
            )
        return response

    @staticmethod
    def _to_file(parent: str, entry: dict) -> HdfsFile:
        name = entry.get("pathSuffix") or ""
        full = posixpath.join(parent, name) if name else parent
        return HdfsFile(
            path=full,
            size_bytes=int(entry.get("length", 0)),
            modification_time=HdfsFile.epoch_millis_to_utc(int(entry.get("modificationTime", 0))),
            owner=entry.get("owner", ""),
            group=entry.get("group", ""),
            permission=entry.get("permission", ""),
            replication=int(entry.get("replication", 0) or 0),
            block_size=int(entry.get("blockSize", 0) or 0),
        )

    # -- HdfsReader contract ---------------------------------------------- #
    def walk(self, path: str, recursive: bool = True) -> Iterator[HdfsFile]:
        """Iterative, batched, depth-first traversal.

        ``LISTSTATUS_BATCH`` is used rather than ``LISTSTATUS`` so that a
        directory holding 500k partitions is returned in bounded pages instead
        of one multi-hundred-megabyte JSON document that would pin the NameNode
        heap and the client's.
        """
        stack = [path.rstrip("/") or "/"]
        while stack:
            current = stack.pop()
            for entry in self._list_batched(current):
                if entry.get("type") == "DIRECTORY":
                    if recursive:
                        stack.append(posixpath.join(current, entry["pathSuffix"]))
                elif entry.get("type") == "FILE":
                    yield self._to_file(current, entry)

    def _list_batched(self, directory: str) -> Iterator[dict]:
        start_after: Optional[str] = None
        while True:
            extra = {}
            if start_after is not None:
                extra["startAfter"] = start_after
            response = self._request(directory, "LISTSTATUS_BATCH", **extra)
            if response is None:
                LOGGER.warning("path disappeared during walk: %s", directory)
                return
            payload = response.json().get("DirectoryListing", {})
            partial = payload.get("partialListing", {}).get("FileStatuses", {})
            entries = partial.get("FileStatus", [])
            for entry in entries:
                yield entry
            if not entries or int(payload.get("remainingEntries", 0)) == 0:
                return
            start_after = entries[-1]["pathSuffix"]

    def open(self, path: str, chunk_size: int) -> "IO[bytes]":
        response = self._request(path, "OPEN", stream=True)
        if response is None:
            raise HdfsError(f"file not found: {path}")
        return io.BufferedReader(
            _StreamingResponseReader(response, chunk_size), buffer_size=chunk_size
        )

    def status(self, path: str) -> Optional[HdfsFile]:
        response = self._request(path, "GETFILESTATUS")
        if response is None:
            return None
        entry = response.json().get("FileStatus", {})
        if entry.get("type") != "FILE":
            return None
        return HdfsFile(
            path=path,
            size_bytes=int(entry.get("length", 0)),
            modification_time=HdfsFile.epoch_millis_to_utc(int(entry.get("modificationTime", 0))),
            owner=entry.get("owner", ""),
            group=entry.get("group", ""),
            permission=entry.get("permission", ""),
        )

    def checksum(self, path: str) -> Optional[str]:
        """Native HDFS checksum (MD5-of-MD5-of-CRC32C).

        Recorded for provenance only: it is *not* comparable with the CRC32C
        that GCS returns, because it is a function of the block and chunk sizes
        of the source cluster. End-to-end integrity is proven by the CRC32C the
        application computes itself while streaming (see ``core.checksum``).
        """
        response = self._request(path, "GETFILECHECKSUM")
        if response is None:
            return None
        return response.json().get("FileChecksum", {}).get("bytes")

    def close(self) -> None:
        self._session.close()
