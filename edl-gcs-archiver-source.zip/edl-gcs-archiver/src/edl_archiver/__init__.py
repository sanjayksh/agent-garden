"""EDL -> GCS archival application."""
__version__ = "1.0.0"
