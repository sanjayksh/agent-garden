"""Db2 connectivity: a small, thread-safe connection pool over ``ibm_db_dbi``.

Why a pool
----------
The orchestrator runs ``max_workers`` upload threads and each completed file
writes one metadata row. Opening a Db2 connection costs tens of milliseconds
and consumes an agent slot on the server, so connections are borrowed from a
bounded pool and returned. The pool size is capped independently of the worker
count because the bank's Db2 instance has a finite ``MAXAPPLS``.

Security
--------
* Connections use ``SECURITY=SSL`` by default.
* Every statement is parameterised with ``?`` markers - no SQL is ever built by
  string concatenation, so the metadata layer is structurally immune to
  injection from file paths (which in a Data Lake are attacker-influenced).
"""
from __future__ import annotations

import logging
import queue
import threading
from contextlib import contextmanager
from typing import Iterator, Optional

from ..config import Db2Config
from ..errors import MetadataStoreError

LOGGER = logging.getLogger(__name__)


def build_dsn(cfg: Db2Config) -> str:
    """Assemble the Db2 CLI connection string."""
    parts = [
        f"DATABASE={cfg.database}",
        f"HOSTNAME={cfg.hostname}",
        f"PORT={cfg.port}",
        "PROTOCOL=TCPIP",
        f"UID={cfg.username}",
        f"PWD={cfg.password}",
        f"ConnectTimeout={cfg.connect_timeout_seconds}",
    ]
    if cfg.use_ssl:
        parts.append("SECURITY=SSL")
        if cfg.ssl_server_certificate:
            parts.append(f"SSLServerCertificate={cfg.ssl_server_certificate}")
    return ";".join(parts) + ";"


def _redact(dsn: str) -> str:
    return ";".join(
        "PWD=***" if part.upper().startswith("PWD=") else part for part in dsn.split(";")
    )


class Db2ConnectionPool:
    """Bounded, thread-safe pool of ``ibm_db_dbi`` connections."""

    def __init__(self, cfg: Db2Config, connection_factory=None) -> None:
        self._cfg = cfg
        self._dsn = build_dsn(cfg)
        self._factory = connection_factory or self._default_factory
        self._pool: "queue.LifoQueue" = queue.LifoQueue(maxsize=cfg.pool_size)
        self._created = 0
        self._lock = threading.Lock()
        self._closed = False
        LOGGER.info("Db2 pool configured: %s (size=%d)", _redact(self._dsn), cfg.pool_size)

    def _default_factory(self):
        try:
            import ibm_db_dbi
        except ImportError as exc:  # pragma: no cover
            raise MetadataStoreError(
                "ibm_db / ibm_db_dbi is required for the Db2 metadata store"
            ) from exc
        try:
            conn = ibm_db_dbi.connect(self._dsn, "", "")
            conn.set_autocommit(False)
            return conn
        except Exception as exc:
            raise MetadataStoreError(f"Db2 connection failed: {exc}") from exc

    def _acquire(self):
        try:
            return self._pool.get_nowait()
        except queue.Empty:
            pass
        with self._lock:
            if self._created < self._cfg.pool_size:
                self._created += 1
                return self._factory()
        return self._pool.get(timeout=self._cfg.connect_timeout_seconds)

    def _release(self, conn) -> None:
        try:
            self._pool.put_nowait(conn)
        except queue.Full:  # pragma: no cover
            _safe_close(conn)

    @contextmanager
    def connection(self) -> Iterator:
        """Borrow a connection; commit on success, roll back on failure."""
        if self._closed:
            raise MetadataStoreError("connection pool is closed")
        conn = self._acquire()
        try:
            yield conn
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:  # pragma: no cover
                LOGGER.exception("rollback failed")
            raise
        finally:
            self._release(conn)

    @contextmanager
    def cursor(self) -> Iterator:
        """Borrow a connection and yield a cursor on it."""
        with self.connection() as conn:
            cur = conn.cursor()
            try:
                yield cur
            finally:
                try:
                    cur.close()
                except Exception:  # pragma: no cover
                    pass

    def healthcheck(self) -> bool:
        """Fail fast at start-up rather than after two hours of uploads."""
        try:
            with self.cursor() as cur:
                cur.execute("SELECT 1 FROM SYSIBM.SYSDUMMY1")
                cur.fetchone()
            return True
        except Exception as exc:
            LOGGER.error("Db2 healthcheck failed: %s", exc)
            return False

    def close(self) -> None:
        self._closed = True
        while True:
            try:
                _safe_close(self._pool.get_nowait())
            except queue.Empty:
                break


def _safe_close(conn: Optional[object]) -> None:
    try:
        if conn is not None:
            conn.close()  # type: ignore[attr-defined]
    except Exception:  # pragma: no cover
        pass
