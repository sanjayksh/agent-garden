"""Row-level data transfer objects for the Db2 metadata tables."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class JobRunRecord:
    """One row of ``EDLARCH.ARCHIVE_JOB_RUN`` - a single nightly execution."""

    job_run_id: str
    job_name: str
    config_path: str
    status: str = "RUNNING"          # RUNNING | SUCCEEDED | PARTIAL | FAILED | ABORTED
    start_ts: Optional[datetime] = None
    end_ts: Optional[datetime] = None
    cutoff_ts: Optional[datetime] = None
    source_paths: str = ""
    target_bucket: str = ""
    files_scanned: int = 0
    files_eligible: int = 0
    files_archived: int = 0
    files_skipped: int = 0
    files_failed: int = 0
    bytes_archived: int = 0
    duration_ms: int = 0
    hostname: str = ""
    executed_by: str = ""
    dry_run: str = "N"
    error_message: str = ""


@dataclass
class FileArchiveRecord:
    """One row of ``EDLARCH.ARCHIVE_FILE`` - a single archived file."""

    file_archive_id: str
    job_run_id: str
    job_name: str
    source_path: str
    source_root: str = ""
    file_name: str = ""
    file_format: str = ""
    source_size_bytes: int = 0
    source_mod_ts: Optional[datetime] = None
    gcs_bucket: str = ""
    gcs_object: str = ""
    gcs_generation: int = 0
    storage_class: str = ""
    crc32c: str = ""
    md5_hash: str = ""
    retention_mode: str = ""
    retention_period_days: int = 0
    retain_until_ts: Optional[datetime] = None
    data_classification: str = ""
    upload_start_ts: Optional[datetime] = None
    upload_end_ts: Optional[datetime] = None
    duration_ms: int = 0
    throughput_mbps: float = 0.0
    attempt_count: int = 1
    status: str = "ARCHIVED"        # ARCHIVED | SKIPPED | FAILED | QUARANTINED
    error_message: str = ""
    tags: dict = field(default_factory=dict)
