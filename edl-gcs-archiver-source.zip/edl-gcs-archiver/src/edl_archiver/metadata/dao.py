"""Data access object for the archival metadata tables.

All SQL lives here. Two design points worth calling out to the client:

* **Buffered batch writes.** Per-file rows are accumulated in a thread-safe
  buffer and flushed with ``executemany`` every ``db2.batch_size`` rows. At
  200k files a night, one round trip per row would add hours of latency and
  dominate the run; batching reduces it to a few hundred round trips.
* **Idempotent upsert.** ``MERGE`` on the natural key ``(SOURCE_PATH,
  SOURCE_MOD_TS)`` means a re-run after a partial failure updates the existing
  row rather than duplicating it, so the catalogue always has exactly one row
  per (file, version) - which is what reconciliation reports depend on.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Sequence

from ..errors import MetadataStoreError
from .db2_client import Db2ConnectionPool
from .models import FileArchiveRecord, JobRunRecord

LOGGER = logging.getLogger(__name__)


class ArchiveMetadataDao:
    """Persistence for job runs and per-file archival records."""

    def __init__(self, pool: Db2ConnectionPool, schema: str = "EDLARCH",
                 batch_size: int = 500) -> None:
        self._pool = pool
        self._schema = schema
        self._batch_size = batch_size
        self._buffer: List[FileArchiveRecord] = []
        self._lock = threading.Lock()

    # -- table names -------------------------------------------------------- #
    @property
    def _run_table(self) -> str:
        return f"{self._schema}.ARCHIVE_JOB_RUN"

    @property
    def _file_table(self) -> str:
        return f"{self._schema}.ARCHIVE_FILE"

    # -- job run ------------------------------------------------------------ #
    def start_job_run(self, record: JobRunRecord) -> None:
        sql = f"""
            INSERT INTO {self._run_table} (
                JOB_RUN_ID, JOB_NAME, CONFIG_PATH, STATUS, START_TS, CUTOFF_TS,
                SOURCE_PATHS, TARGET_BUCKET, HOSTNAME, EXECUTED_BY, DRY_RUN
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """
        params = (
            record.job_run_id, record.job_name, record.config_path, record.status,
            record.start_ts or datetime.now(timezone.utc), record.cutoff_ts,
            record.source_paths[:1024], record.target_bucket, record.hostname,
            record.executed_by, record.dry_run,
        )
        self._execute(sql, params, "start_job_run")

    def finish_job_run(self, record: JobRunRecord) -> None:
        self.flush()
        sql = f"""
            UPDATE {self._run_table}
               SET STATUS = ?, END_TS = ?, DURATION_MS = ?,
                   FILES_SCANNED = ?, FILES_ELIGIBLE = ?, FILES_ARCHIVED = ?,
                   FILES_SKIPPED = ?, FILES_FAILED = ?, BYTES_ARCHIVED = ?,
                   ERROR_MESSAGE = ?
             WHERE JOB_RUN_ID = ?
        """
        params = (
            record.status, record.end_ts or datetime.now(timezone.utc), record.duration_ms,
            record.files_scanned, record.files_eligible, record.files_archived,
            record.files_skipped, record.files_failed, record.bytes_archived,
            (record.error_message or "")[:2048], record.job_run_id,
        )
        self._execute(sql, params, "finish_job_run")

    def heartbeat(self, job_run_id: str, files_archived: int, bytes_archived: int) -> None:
        """Periodic progress update so operations can watch a long run live."""
        sql = f"""
            UPDATE {self._run_table}
               SET FILES_ARCHIVED = ?, BYTES_ARCHIVED = ?, LAST_HEARTBEAT_TS = ?
             WHERE JOB_RUN_ID = ?
        """
        self._execute(
            sql,
            (files_archived, bytes_archived, datetime.now(timezone.utc), job_run_id),
            "heartbeat",
        )

    # -- file records ------------------------------------------------------- #
    _FILE_MERGE = """
        MERGE INTO {table} AS T
        USING (VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?))
              AS S (FILE_ARCHIVE_ID, JOB_RUN_ID, JOB_NAME, SOURCE_PATH, SOURCE_ROOT,
                    FILE_NAME, FILE_FORMAT, SOURCE_SIZE_BYTES, SOURCE_MOD_TS,
                    GCS_BUCKET, GCS_OBJECT, GCS_GENERATION, STORAGE_CLASS,
                    CRC32C, MD5_HASH, RETENTION_MODE, RETENTION_PERIOD_DAYS,
                    RETAIN_UNTIL_TS, DATA_CLASSIFICATION, UPLOAD_START_TS,
                    UPLOAD_END_TS, DURATION_MS, THROUGHPUT_MBPS, ATTEMPT_COUNT,
                    STATUS, ERROR_MESSAGE, TAGS)
           ON T.SOURCE_PATH = S.SOURCE_PATH AND T.SOURCE_MOD_TS = S.SOURCE_MOD_TS
        WHEN MATCHED THEN UPDATE SET
             JOB_RUN_ID = S.JOB_RUN_ID, GCS_BUCKET = S.GCS_BUCKET,
             GCS_OBJECT = S.GCS_OBJECT, GCS_GENERATION = S.GCS_GENERATION,
             STORAGE_CLASS = S.STORAGE_CLASS, CRC32C = S.CRC32C,
             MD5_HASH = S.MD5_HASH, RETENTION_MODE = S.RETENTION_MODE,
             RETENTION_PERIOD_DAYS = S.RETENTION_PERIOD_DAYS,
             RETAIN_UNTIL_TS = S.RETAIN_UNTIL_TS,
             UPLOAD_START_TS = S.UPLOAD_START_TS, UPLOAD_END_TS = S.UPLOAD_END_TS,
             DURATION_MS = S.DURATION_MS, THROUGHPUT_MBPS = S.THROUGHPUT_MBPS,
             ATTEMPT_COUNT = S.ATTEMPT_COUNT, STATUS = S.STATUS,
             ERROR_MESSAGE = S.ERROR_MESSAGE, UPDATED_TS = CURRENT TIMESTAMP
        WHEN NOT MATCHED THEN INSERT (
             FILE_ARCHIVE_ID, JOB_RUN_ID, JOB_NAME, SOURCE_PATH, SOURCE_ROOT,
             FILE_NAME, FILE_FORMAT, SOURCE_SIZE_BYTES, SOURCE_MOD_TS,
             GCS_BUCKET, GCS_OBJECT, GCS_GENERATION, STORAGE_CLASS, CRC32C,
             MD5_HASH, RETENTION_MODE, RETENTION_PERIOD_DAYS, RETAIN_UNTIL_TS,
             DATA_CLASSIFICATION, UPLOAD_START_TS, UPLOAD_END_TS, DURATION_MS,
             THROUGHPUT_MBPS, ATTEMPT_COUNT, STATUS, ERROR_MESSAGE, TAGS)
        VALUES (
             S.FILE_ARCHIVE_ID, S.JOB_RUN_ID, S.JOB_NAME, S.SOURCE_PATH, S.SOURCE_ROOT,
             S.FILE_NAME, S.FILE_FORMAT, S.SOURCE_SIZE_BYTES, S.SOURCE_MOD_TS,
             S.GCS_BUCKET, S.GCS_OBJECT, S.GCS_GENERATION, S.STORAGE_CLASS, S.CRC32C,
             S.MD5_HASH, S.RETENTION_MODE, S.RETENTION_PERIOD_DAYS, S.RETAIN_UNTIL_TS,
             S.DATA_CLASSIFICATION, S.UPLOAD_START_TS, S.UPLOAD_END_TS, S.DURATION_MS,
             S.THROUGHPUT_MBPS, S.ATTEMPT_COUNT, S.STATUS, S.ERROR_MESSAGE, S.TAGS)
    """

    @staticmethod
    def _to_params(rec: FileArchiveRecord) -> tuple:
        import json

        return (
            rec.file_archive_id, rec.job_run_id, rec.job_name, rec.source_path,
            rec.source_root, rec.file_name, rec.file_format, rec.source_size_bytes,
            rec.source_mod_ts, rec.gcs_bucket, rec.gcs_object, rec.gcs_generation,
            rec.storage_class, rec.crc32c, rec.md5_hash or "", rec.retention_mode,
            rec.retention_period_days, rec.retain_until_ts, rec.data_classification,
            rec.upload_start_ts, rec.upload_end_ts, rec.duration_ms,
            round(rec.throughput_mbps, 3), rec.attempt_count, rec.status,
            (rec.error_message or "")[:2048], json.dumps(rec.tags)[:2048],
        )

    def record_file(self, record: FileArchiveRecord) -> None:
        """Buffer one file record; flush automatically when the batch is full."""
        with self._lock:
            self._buffer.append(record)
            ready = self._buffer if len(self._buffer) >= self._batch_size else None
            if ready is not None:
                self._buffer = []
        if ready:
            self._write_batch(ready)

    def flush(self) -> None:
        with self._lock:
            pending, self._buffer = self._buffer, []
        if pending:
            self._write_batch(pending)

    def _write_batch(self, records: Sequence[FileArchiveRecord]) -> None:
        sql = self._FILE_MERGE.format(table=self._file_table)
        params = [self._to_params(r) for r in records]
        try:
            with self._pool.cursor() as cur:
                cur.executemany(sql, params)
            LOGGER.debug("persisted %d file metadata rows", len(records))
        except Exception as exc:
            # Metadata loss must never be silent: the batch is written to the
            # log in full so it can be replayed by the operations team.
            LOGGER.error("batch metadata write failed for %d rows: %s", len(records), exc)
            raise MetadataStoreError(str(exc)) from exc

    # -- queries used for idempotency and reporting ------------------------- #
    def already_archived(self, source_path: str, source_mod_ts: datetime) -> bool:
        """True if this exact file version is already recorded as ARCHIVED."""
        sql = f"""
            SELECT 1 FROM {self._file_table}
             WHERE SOURCE_PATH = ? AND SOURCE_MOD_TS = ? AND STATUS = 'ARCHIVED'
             FETCH FIRST 1 ROW ONLY
        """
        try:
            with self._pool.cursor() as cur:
                cur.execute(sql, (source_path, source_mod_ts))
                return cur.fetchone() is not None
        except Exception as exc:
            LOGGER.warning("idempotency lookup failed for %s: %s", source_path, exc)
            return False

    def load_archived_index(self, job_name: str) -> Dict[str, datetime]:
        """Bulk-load ``{source_path: source_mod_ts}`` for a job.

        One query replaces N per-file lookups. At 200k candidate files this is
        the difference between a few seconds and roughly an hour of Db2 round
        trips, so the orchestrator always uses this in preference to
        ``already_archived``.
        """
        sql = f"""
            SELECT SOURCE_PATH, SOURCE_MOD_TS FROM {self._file_table}
             WHERE JOB_NAME = ? AND STATUS = 'ARCHIVED'
        """
        index: Dict[str, datetime] = {}
        try:
            with self._pool.cursor() as cur:
                cur.execute(sql, (job_name,))
                for path, mod_ts in cur.fetchall():
                    index[path] = mod_ts
        except Exception as exc:
            LOGGER.warning("could not preload archived index: %s", exc)
        LOGGER.info("preloaded %d previously archived paths for job %s", len(index), job_name)
        return index

    def failed_files(self, job_run_id: str) -> List[str]:
        sql = f"SELECT SOURCE_PATH FROM {self._file_table} WHERE JOB_RUN_ID = ? AND STATUS = 'FAILED'"
        with self._pool.cursor() as cur:
            cur.execute(sql, (job_run_id,))
            return [row[0] for row in cur.fetchall()]

    # -- internal ----------------------------------------------------------- #
    def _execute(self, sql: str, params: tuple, label: str) -> None:
        try:
            with self._pool.cursor() as cur:
                cur.execute(sql, params)
        except Exception as exc:
            raise MetadataStoreError(f"{label} failed: {exc}") from exc
