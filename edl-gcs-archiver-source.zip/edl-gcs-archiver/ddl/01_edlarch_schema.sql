--------------------------------------------------------------------------------
-- ABC Bank - Enterprise Data Lake to GCS Archival
-- Db2 metadata store DDL
--
-- Two tables:
--   ARCHIVE_JOB_RUN  - one row per execution of the nightly job
--   ARCHIVE_FILE     - one row per (file, version) archived
--
-- Design notes
--   * ARCHIVE_FILE is range-partitioned by ARCHIVED_TS so that old runs can be
--     detached and rolled off without a mass DELETE.
--   * The unique index on (SOURCE_PATH, SOURCE_MOD_TS) is the natural key that
--     makes the MERGE upsert - and therefore the whole job - idempotent.
--   * APPEND ON and a generous PCTFREE suit the insert-mostly access pattern.
--------------------------------------------------------------------------------

CREATE SCHEMA EDLARCH;

--------------------------------------------------------------------------------
-- Job run table
--------------------------------------------------------------------------------
CREATE TABLE EDLARCH.ARCHIVE_JOB_RUN (
    JOB_RUN_ID           VARCHAR(36)   NOT NULL,
    JOB_NAME             VARCHAR(128)  NOT NULL,
    CONFIG_PATH          VARCHAR(512),
    STATUS               VARCHAR(16)   NOT NULL,
    START_TS             TIMESTAMP     NOT NULL,
    END_TS               TIMESTAMP,
    LAST_HEARTBEAT_TS    TIMESTAMP,
    CUTOFF_TS            TIMESTAMP,
    SOURCE_PATHS         VARCHAR(1024),
    TARGET_BUCKET        VARCHAR(256),
    FILES_SCANNED        BIGINT        NOT NULL DEFAULT 0,
    FILES_ELIGIBLE       BIGINT        NOT NULL DEFAULT 0,
    FILES_ARCHIVED       BIGINT        NOT NULL DEFAULT 0,
    FILES_SKIPPED        BIGINT        NOT NULL DEFAULT 0,
    FILES_FAILED         BIGINT        NOT NULL DEFAULT 0,
    BYTES_ARCHIVED       BIGINT        NOT NULL DEFAULT 0,
    DURATION_MS          BIGINT        NOT NULL DEFAULT 0,
    HOSTNAME             VARCHAR(255),
    EXECUTED_BY          VARCHAR(128),
    DRY_RUN              CHAR(1)       NOT NULL DEFAULT 'N',
    ERROR_MESSAGE        VARCHAR(2048),
    CREATED_TS           TIMESTAMP     NOT NULL DEFAULT CURRENT TIMESTAMP,
    CONSTRAINT PK_ARCHIVE_JOB_RUN PRIMARY KEY (JOB_RUN_ID),
    CONSTRAINT CK_JOB_RUN_STATUS  CHECK (STATUS IN
        ('RUNNING','SUCCEEDED','PARTIAL','FAILED','ABORTED'))
) IN TS_EDLARCH_DATA;

CREATE INDEX EDLARCH.IX_JOB_RUN_NAME_START
    ON EDLARCH.ARCHIVE_JOB_RUN (JOB_NAME, START_TS DESC);
CREATE INDEX EDLARCH.IX_JOB_RUN_STATUS
    ON EDLARCH.ARCHIVE_JOB_RUN (STATUS, START_TS DESC);

--------------------------------------------------------------------------------
-- File archive table
--------------------------------------------------------------------------------
CREATE TABLE EDLARCH.ARCHIVE_FILE (
    FILE_ARCHIVE_ID      VARCHAR(36)   NOT NULL,
    JOB_RUN_ID           VARCHAR(36)   NOT NULL,
    JOB_NAME             VARCHAR(128)  NOT NULL,
    SOURCE_PATH          VARCHAR(1024) NOT NULL,
    SOURCE_ROOT          VARCHAR(512),
    FILE_NAME            VARCHAR(512),
    FILE_FORMAT          VARCHAR(32),
    SOURCE_SIZE_BYTES    BIGINT        NOT NULL DEFAULT 0,
    SOURCE_MOD_TS        TIMESTAMP     NOT NULL,
    GCS_BUCKET           VARCHAR(256),
    GCS_OBJECT           VARCHAR(1024),
    GCS_GENERATION       BIGINT,
    STORAGE_CLASS        VARCHAR(16),
    CRC32C               VARCHAR(32),
    MD5_HASH             VARCHAR(64),
    RETENTION_MODE       VARCHAR(24),
    RETENTION_PERIOD_DAYS INTEGER,
    RETAIN_UNTIL_TS      TIMESTAMP,
    DATA_CLASSIFICATION  VARCHAR(32),
    UPLOAD_START_TS      TIMESTAMP,
    UPLOAD_END_TS        TIMESTAMP,
    DURATION_MS          BIGINT        NOT NULL DEFAULT 0,
    THROUGHPUT_MBPS      DECIMAL(12,3) NOT NULL DEFAULT 0,
    ATTEMPT_COUNT        SMALLINT      NOT NULL DEFAULT 1,
    STATUS               VARCHAR(16)   NOT NULL,
    ERROR_MESSAGE        VARCHAR(2048),
    TAGS                 VARCHAR(2048),
    ARCHIVED_TS          TIMESTAMP     NOT NULL DEFAULT CURRENT TIMESTAMP,
    UPDATED_TS           TIMESTAMP     NOT NULL DEFAULT CURRENT TIMESTAMP,
    CONSTRAINT PK_ARCHIVE_FILE PRIMARY KEY (FILE_ARCHIVE_ID),
    CONSTRAINT FK_ARCHIVE_FILE_RUN FOREIGN KEY (JOB_RUN_ID)
        REFERENCES EDLARCH.ARCHIVE_JOB_RUN (JOB_RUN_ID),
    CONSTRAINT CK_ARCHIVE_FILE_STATUS CHECK (STATUS IN
        ('ARCHIVED','SKIPPED','FAILED','QUARANTINED'))
)
  IN TS_EDLARCH_DATA
  PARTITION BY RANGE (ARCHIVED_TS)
    (STARTING '2026-01-01' ENDING '2032-12-31' EVERY 3 MONTHS);

-- Natural key: exactly one row per file *version*. This is what MERGE targets.
CREATE UNIQUE INDEX EDLARCH.UX_ARCHIVE_FILE_SOURCE
    ON EDLARCH.ARCHIVE_FILE (SOURCE_PATH, SOURCE_MOD_TS);

CREATE INDEX EDLARCH.IX_ARCHIVE_FILE_RUN
    ON EDLARCH.ARCHIVE_FILE (JOB_RUN_ID, STATUS);
CREATE INDEX EDLARCH.IX_ARCHIVE_FILE_JOB_STATUS
    ON EDLARCH.ARCHIVE_FILE (JOB_NAME, STATUS);
CREATE INDEX EDLARCH.IX_ARCHIVE_FILE_OBJECT
    ON EDLARCH.ARCHIVE_FILE (GCS_BUCKET, GCS_OBJECT);
CREATE INDEX EDLARCH.IX_ARCHIVE_FILE_RETAIN
    ON EDLARCH.ARCHIVE_FILE (RETAIN_UNTIL_TS);

--------------------------------------------------------------------------------
-- Reporting views
--------------------------------------------------------------------------------
CREATE OR REPLACE VIEW EDLARCH.V_RUN_SUMMARY AS
SELECT  JOB_NAME,
        DATE(START_TS)                  AS RUN_DATE,
        COUNT(*)                        AS RUNS,
        SUM(FILES_ARCHIVED)             AS FILES_ARCHIVED,
        SUM(FILES_FAILED)               AS FILES_FAILED,
        SUM(BYTES_ARCHIVED)/1024/1024/1024 AS GIB_ARCHIVED,
        AVG(DURATION_MS)/1000           AS AVG_SECONDS
  FROM  EDLARCH.ARCHIVE_JOB_RUN
 WHERE  STATUS <> 'RUNNING'
 GROUP BY JOB_NAME, DATE(START_TS);

-- Objects whose retention has expired and which are candidates for disposal.
CREATE OR REPLACE VIEW EDLARCH.V_RETENTION_EXPIRED AS
SELECT  JOB_NAME, SOURCE_PATH, GCS_BUCKET, GCS_OBJECT,
        RETAIN_UNTIL_TS, DATA_CLASSIFICATION, SOURCE_SIZE_BYTES
  FROM  EDLARCH.ARCHIVE_FILE
 WHERE  STATUS = 'ARCHIVED'
   AND  RETAIN_UNTIL_TS IS NOT NULL
   AND  RETAIN_UNTIL_TS <= CURRENT TIMESTAMP;

-- Files that need operator attention.
CREATE OR REPLACE VIEW EDLARCH.V_EXCEPTIONS AS
SELECT  JOB_RUN_ID, JOB_NAME, SOURCE_PATH, STATUS, ATTEMPT_COUNT,
        ERROR_MESSAGE, UPDATED_TS
  FROM  EDLARCH.ARCHIVE_FILE
 WHERE  STATUS IN ('FAILED','QUARANTINED');

--------------------------------------------------------------------------------
-- Least privilege: the application account may read and write rows, nothing more
--------------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE ON EDLARCH.ARCHIVE_JOB_RUN TO USER EDLARCHAPP;
GRANT SELECT, INSERT, UPDATE ON EDLARCH.ARCHIVE_FILE    TO USER EDLARCHAPP;
GRANT SELECT ON EDLARCH.V_RUN_SUMMARY       TO ROLE ABC_DATA_STEWARD;
GRANT SELECT ON EDLARCH.V_RETENTION_EXPIRED TO ROLE ABC_RECORDS_MGMT;
GRANT SELECT ON EDLARCH.V_EXCEPTIONS        TO ROLE ABC_OPERATIONS;
