# EDL to GCS Archival Application

Standalone Python application that archives ageing files from ABC Bank's
on-premise Enterprise Data Lake (HDFS) to Google Cloud Storage, applies
retention metadata to each object, and records full job and file lineage in
IBM Db2.

## Layout

```
src/edl_archiver/
  config.py             Typed configuration model + JSON loader (env-var resolution)
  errors.py             Retryable vs terminal exception hierarchy
  logging_setup.py      Structured JSON logging
  lock.py               Single-instance advisory file lock
  cli.py                Entry point; scheduler exit-code contract
  hdfs/
    base.py             HdfsReader interface + HdfsFile model
    webhdfs.py          WebHDFS / HttpFS reader (default; pure Python)
    libhdfs.py          PyArrow / libhdfs native reader (high throughput)
    factory.py          Selects the reader named in configuration
  gcs/uploader.py       Streaming resumable upload, CRC32C verification, retention
  metadata/
    db2_client.py       Thread-safe Db2 connection pool
    models.py           Row DTOs
    dao.py              Batched, parameterised, idempotent MERGE upserts
  core/
    scanner.py          Lazy traversal + eligibility filtering
    checksum.py         Inline CRC32C/MD5 tee
    retry.py            Exponential backoff with full jitter
    orchestrator.py     Concurrency, idempotency, failure policy, reporting
ddl/01_edlarch_schema.sql   Db2 tables, indexes, partitioning, views, grants
config/job_config.sample.json
tests/                  30 unit tests, no cluster or cloud access required
```

## Install

```bash
python3 -m venv /opt/edl-archiver/venv
/opt/edl-archiver/venv/bin/pip install -r requirements.txt
/opt/edl-archiver/venv/bin/pip install .
```

## Run

```bash
export DB2_USER=EDLARCHAPP
export DB2_PASSWORD="$(vault read -field=password secret/edl/db2)"
kinit -kt /etc/security/keytabs/svc_edlarchive.keytab svc_edlarchive@ABCBANK.INTERNAL

edl-archive --config /etc/edl-archiver/retail_banking.json            # normal run
edl-archive --config /etc/edl-archiver/retail_banking.json --dry-run  # report only
edl-archive --config /etc/edl-archiver/retail_banking.json --validate-only
```

## Exit codes

| Code | Meaning   | Scheduler action              |
|------|-----------|-------------------------------|
| 0    | SUCCEEDED | none                          |
| 1    | FAILED    | page on-call                  |
| 2    | CONFIG    | do not retry; raise a defect  |
| 3    | PARTIAL   | raise ticket, review exceptions |
| 4    | LOCKED    | none; previous run still active |

## Tests

```bash
cd tests && python3 -m pytest -q
```
