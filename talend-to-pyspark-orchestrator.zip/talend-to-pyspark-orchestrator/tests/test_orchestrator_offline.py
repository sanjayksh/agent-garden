"""End-to-end orchestrator test using the offline backend (no credentials)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from talend2pyspark.config import load_config  # noqa: E402
from talend2pyspark.orchestrator import run_pipeline  # noqa: E402


def test_orchestrator_offline(tmp_path):
    cfg = load_config(
        project_root=ROOT,
        provider="offline",
        workspace=str(tmp_path / "ws"),
        # keep validation but it will run on a temp copy, leaving sample intact
    )
    # redirect workspace sub-folders under the temp workspace
    cfg.extracted_logic_dir = cfg.workspace / "01_extracted_logic"
    cfg.pyspark_code_dir = cfg.workspace / "02_pyspark_code"
    cfg.mapping_dir = cfg.workspace / "03_mapping"
    cfg.validation_dir = cfg.workspace / "04_validation"

    ctx = run_pipeline(cfg)

    # all four artifacts exist
    assert ctx.logic_json_path and ctx.logic_json_path.exists()
    assert ctx.logic_doc_path and ctx.logic_doc_path.exists()
    assert ctx.pyspark_code_path and ctx.pyspark_code_path.exists()
    assert ctx.mapping_doc_path and ctx.mapping_doc_path.exists()
    assert ctx.validation_doc_path and ctx.validation_doc_path.exists()

    # mapping has a row per business rule plus structural rows
    assert len(ctx.mapping_rows) >= 8
    # generated code looks right
    code = ctx.pyspark_code or ""
    assert "F.trim(" in code and "F.upper(" in code and "F.round(" in code
    assert "def transform(" in code and "write_single_csv(" in code

    # validation passed
    assert ctx.validation_result is not None
    assert ctx.validation_result["passed"] is True


def test_sample_input_preserved():
    """The orchestrator must not destroy the canonical sample input."""
    assert (ROOT / "data" / "input" / "customers.csv").exists()
