"""Tests for the Talend parser."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from talend2pyspark.talend.parser import parse_job  # noqa: E402

JOB = ROOT / "sample_talend_job" / "MoveCsvFile"


def test_parse_job_structure():
    spec = parse_job(JOB)
    assert spec["job_name"] == "MoveCsvFile"
    assert spec["purpose"]
    # 3 context variables
    names = {c["name"] for c in spec["context"]}
    assert names == {"INPUT_FOLDER", "OUTPUT_FOLDER", "FILE_NAME"}
    # source with 5 columns
    assert spec["source"]["type"] == "tFileInputDelimited"
    assert [c["name"] for c in spec["source"]["schema"]] == [
        "customer_id", "name", "country", "signup_date", "balance",
    ]
    # 6 transformations, 1 filter, 1 post-action
    assert len(spec["transformations"]) == 6
    assert len(spec["filters"]) == 1
    assert len(spec["post_actions"]) == 1
    # business-rule ids are assigned in order
    assert spec["transformations"][0]["id"] == "BR-01"
    assert spec["filters"][0]["id"] == "BR-07"
    assert spec["post_actions"][0]["id"] == "BR-08"


def test_parse_job_expressions():
    spec = parse_job(JOB)
    by_out = {t["output"]: t["talend_expr"] for t in spec["transformations"]}
    assert by_out["name"] == "StringHandling.TRIM(row1.name)"
    assert by_out["country"] == "StringHandling.UPCASE(row1.country)"
    assert "Math.round" in by_out["balance"]
    assert by_out["load_date"] == "TalendDate.getCurrentDate()"
    assert spec["filters"][0]["talend_expr"] == "row1.balance >= 0"
