"""Generate a pipeline and execute it, asserting Talend-equivalent behaviour.

Skipped automatically if pyspark is not installed.
"""
import csv
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

pyspark = pytest.importorskip("pyspark")  # noqa: F841

from talend2pyspark.talend.codegen import generate_pyspark  # noqa: E402
from talend2pyspark.talend.parser import parse_job  # noqa: E402

JOB = ROOT / "sample_talend_job" / "MoveCsvFile"
SAMPLE_CSV = ROOT / "data" / "input" / "customers.csv"


def test_generated_pipeline_moves_and_transforms(tmp_path):
    # generate the pipeline from the parsed spec
    spec = parse_job(JOB)
    code = generate_pyspark(spec, "generated_pipeline")
    script = tmp_path / "generated_pipeline.py"
    script.write_text(code, encoding="utf-8")

    # isolated input/output so the sample data is untouched
    in_dir = tmp_path / "input"
    out_dir = tmp_path / "output"
    in_dir.mkdir()
    out_dir.mkdir()
    shutil.copy(SAMPLE_CSV, in_dir / "customers.csv")

    proc = subprocess.run(
        [sys.executable, str(script),
         "--input-dir", str(in_dir),
         "--output-dir", str(out_dir),
         "--file-name", "customers.csv"],
        capture_output=True, text=True, timeout=600,
    )
    assert proc.returncode == 0, proc.stderr

    out_csv = out_dir / "customers.csv"
    assert out_csv.exists()

    with out_csv.open(newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))

    # filter removed the single negative-balance row (6 -> 5)
    assert len(rows) == 5
    # transformations applied
    for r in rows:
        assert r["name"] == r["name"].strip()         # trimmed
        assert r["country"] == r["country"].upper()    # upper-cased
        assert r["load_date"]                          # load date stamped
        if "." in r["balance"]:
            assert len(r["balance"].split(".")[1]) <= 2  # rounded

    # move semantics: the source file was deleted
    assert not (in_dir / "customers.csv").exists()
