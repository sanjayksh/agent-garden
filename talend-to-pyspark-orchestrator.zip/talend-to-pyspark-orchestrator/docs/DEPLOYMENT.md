# Deployment & Run Guide — `talend2pyspark`

This guide covers everything needed to deploy and run the Talend→PySpark
multi-agent orchestrator: prerequisites, installation, running with each AI
backend, the VS Code workflow (including the Copilot companion extension),
running the generated pipeline, and troubleshooting.

---

## 1. Prerequisites

| Requirement | Needed for | Notes |
|---|---|---|
| **Python 3.10+** | everything | 3.10–3.12 tested |
| **pip** | install deps | |
| **Java 8/11/17/21** | running the generated PySpark + Agent 4 validation | `java -version` |
| **pyspark ≥ 3.4** | running the generated PySpark + Agent 4 validation | optional for doc-only runs |
| **GitHub account + PAT** (`models: read`) | `github_copilot` backend | free tier available |
| **VS Code + GitHub Copilot + Copilot Chat** | the companion extension's Copilot commands | optional |

> The **offline** backend needs none of the AI credentials — only Python.
> Java + pyspark are only required to *execute* PySpark (the generated pipeline
> and Agent 4). Document generation alone works without them.

---

## 2. Install

```bash
# 1. unzip and enter the project
unzip talend-to-pyspark-orchestrator.zip
cd talend-to-pyspark-orchestrator

# 2. (recommended) create a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3a. quick start (no install) — just the core deps
pip install -r requirements.txt

# 3b. OR install as a package (adds the `talend2pyspark` command)
pip install -e .

# 4. (optional) enable live PySpark execution / validation
pip install pyspark
```

---

## 3. Run — offline backend (default, zero credentials)

```bash
# zero-install entry point
python run.py --provider offline

# or, if you ran `pip install -e .`
talend2pyspark --provider offline

# or as a module
PYTHONPATH=src python -m talend2pyspark --provider offline
```

You will see each agent start and hand off, then a summary:

```
======================================================================
  CONVERSION COMPLETE
======================================================================
  Talend job          : MoveCsvFile
  LLM backend         : offline
  Business-logic doc  : workspace/01_extracted_logic/MoveCsvFile_business_logic.docx
  Logic JSON          : workspace/01_extracted_logic/logic.json
  Generated PySpark   : workspace/02_pyspark_code/generated_pipeline.py
  Mapping doc         : workspace/03_mapping/MoveCsvFile_logic_mapping.docx
  Validation report   : workspace/04_validation/MoveCsvFile_validation_report.docx
  Validation verdict  : PASS
======================================================================
```

> If `pyspark` is not installed, Agent 4 automatically falls back to a **static
> review** instead of a live execution, and the run still completes.

---

## 4. Run — GitHub Copilot backend

The `github_copilot` backend calls the GitHub-hosted, OpenAI-compatible
inference API that serves the same model catalogue as Copilot.

### 4.1 Create a token

1. GitHub → **Settings** → **Developer settings** → **Personal access tokens**
   → **Fine-grained tokens** → **Generate new token**.
2. Grant the **`Models: read`** permission.
3. Copy the token.

### 4.2 Configure

```bash
cp .env.example .env
```

Edit `.env`:

```ini
T2P_LLM_PROVIDER=github_copilot
GITHUB_TOKEN=ghp_your_token_here
T2P_GITHUB_BASE_URL=https://models.github.ai/inference
T2P_GITHUB_MODEL=openai/gpt-4o
```

For an organization-scoped endpoint use
`https://models.github.ai/orgs/<ORG>/inference`.

### 4.3 Run

```bash
python run.py --provider github_copilot
```

The four agents now submit their prompts to Copilot. Agent 2 receives generated
PySpark from the model (validated before saving); Agent 3 receives the mapping
as JSON. If a response is ever unusable, the agent falls back to the
deterministic engine so the run still succeeds.

---

## 5. Run — generic OpenAI-compatible backend

Works with OpenAI, Azure OpenAI, or a local server (Ollama, vLLM, LM Studio).

```ini
# .env
T2P_LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
T2P_OPENAI_BASE_URL=https://api.openai.com/v1      # or http://localhost:11434/v1 etc.
T2P_OPENAI_MODEL=gpt-4o
```

```bash
python run.py --provider openai
```

---

## 6. VS Code workflow

### 6.1 Open & configure

1. Open the **`talend-to-pyspark-orchestrator`** folder in VS Code.
2. Select your Python interpreter (the `.venv` you created).
3. `.vscode/settings.json` already sets `PYTHONPATH=src` for the integrated
   terminal and enables pytest.

### 6.2 One-click tasks

**Terminal → Run Task…** (or `Ctrl/Cmd+Shift+B`):

- **t2p: install (editable)** — `pip install -e .`
- **t2p: convert (offline)** — run the orchestrator offline *(default build task)*
- **t2p: convert (GitHub Copilot)** — run with the Copilot backend
- **t2p: run generated pipeline** — execute the generated PySpark
- **t2p: tests** — run pytest

### 6.3 Debug configurations

**Run and Debug** (`F5`):

- **Run orchestrator (offline)**
- **Run orchestrator (GitHub Copilot)**
- **Run GENERATED pipeline**

### 6.4 Copilot companion extension (optional)

The extension demonstrates the **native in-editor Copilot models** and provides
Command-Palette entry points.

```bash
cd vscode-extension
npm install
npm run compile
```

Press **F5** to launch an Extension Development Host, open the project folder
inside it, then use the Command Palette (`Ctrl/Cmd+Shift+P`):

- **Talend2PySpark: Convert Talend Job** — runs the orchestrator in the terminal.
- **Talend2PySpark: Explain Talend Job with Copilot** — opens a `.item` file and
  streams a Copilot explanation into a new Markdown editor. The first call shows
  a **consent dialog**; you need **GitHub Copilot + Copilot Chat** installed and
  signed in.
- **Talend2PySpark: Run Generated PySpark Pipeline** — runs the generated
  pipeline against `data/input → data/output`.

Extension settings: `talend2pyspark.provider`, `talend2pyspark.pythonPath`,
`talend2pyspark.copilotModelFamily`.

---

## 7. Run the generated pipeline

The converter writes a standalone PySpark module you can run on its own:

```bash
python workspace/02_pyspark_code/generated_pipeline.py \
    --input-dir data/input \
    --output-dir data/output \
    --file-name customers.csv
```

Behaviour (faithful to the Talend job):

- reads `data/input/customers.csv` with the explicit schema,
- keeps rows with `balance >= 0` (the sample's negative-balance row is dropped:
  6 → 5 rows),
- trims `name`, upper-cases `country`, rounds `balance` to 2 decimals, stamps
  `load_date`,
- writes a single `data/output/customers.csv`,
- **deletes the source file** to complete the move (use `--no-delete-source` to
  copy instead).

> Re-running needs the input file back in `data/input/` (the move deletes it).
> Restore it from the zip or your version control if you want to run again.

---

## 8. Output artifacts

| Folder | File | Produced by |
|---|---|---|
| `workspace/01_extracted_logic/` | `logic.json`, `<job>_business_logic.docx` | Agent 1 |
| `workspace/02_pyspark_code/` | `generated_pipeline.py` | Agent 2 |
| `workspace/03_mapping/` | `<job>_logic_mapping.docx` | Agent 3 |
| `workspace/04_validation/` | `<job>_validation_report.docx` | Agent 4 |

---

## 9. Configuration reference

`config/settings.yaml` controls folders, generated-pipeline IO, the default
backend, and behaviour (`execute_validation`, `fail_fast`). Environment
variables (`.env`) override the YAML; CLI flags override both.

Common CLI flags:

```
--talend-input PATH   folder with the Talend .properties/.item files
--workspace PATH      where agent artifacts are written
--input-dir PATH      what the generated pipeline reads
--output-dir PATH     where the generated pipeline writes
--provider NAME       offline | github_copilot | openai
--no-validate         skip Agent 4's live execution (static review only)
-v / --verbose        debug logging
```

Convert a different job:

```bash
python run.py --talend-input ./my_jobs/AnotherJob --provider github_copilot
```

---

## 10. Tests

```bash
pip install pytest
PYTHONPATH=src pytest -q
```

- `test_parser.py` — parsing correctness
- `test_orchestrator_offline.py` — full offline run produces all artifacts and
  preserves the sample data
- `test_generated_pipeline.py` — executes the generated pipeline and asserts the
  filter, transformations, and move semantics (auto-skipped if pyspark is
  absent)

---

## 11. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `ModuleNotFoundError: talend2pyspark` | run via `python run.py`, or `pip install -e .`, or set `PYTHONPATH=src` |
| Agent 4 does a static review instead of executing | `pyspark`/Java not installed — `pip install pyspark` and install a JDK |
| `JAVA_HOME is not set` / Spark won't start | install a JDK (8/11/17/21) and set `JAVA_HOME` |
| `GITHUB_TOKEN is empty` | set a PAT with `models: read` in `.env` |
| GitHub Models `HTTP 401/403` | token missing `models: read`, expired, or org access not enabled |
| GitHub Models `HTTP 404` on model | use a valid id, e.g. `openai/gpt-4o` |
| Copilot command: "No Copilot model available" | install **GitHub Copilot Chat**, sign in, accept the consent dialog |
| Generated pipeline can't find input | the previous run moved (deleted) it — restore `data/input/customers.csv` |
| Windows path issues | the app resolves paths relative to the project root; run from the project folder |

---

## 12. Deploying in CI / containers

- **CI without credentials:** run `python run.py --provider offline` — it needs
  only Python (+ Java/pyspark if you also want Agent 4 to execute).
- **CI with Copilot:** in GitHub Actions, grant `permissions: models: read` and
  the runner's `GITHUB_TOKEN` can call GitHub Models without a separate secret;
  set `T2P_LLM_PROVIDER=github_copilot` and `GITHUB_TOKEN=${{ github.token }}`.
- **Containers:** base on `python:3.12-slim`, add a JDK
  (`apt-get install -y default-jre`) if you need PySpark execution,
  `pip install -e .[spark]`, then run the CLI.
