# Talend → PySpark (Copilot) — VS Code companion extension

This **optional** extension wires the Python multi-agent orchestrator into VS
Code and demonstrates using GitHub Copilot's **in-editor language models**
(`vscode.lm`) directly.

The Python CLI is the primary, fully-tested path. This extension is a
convenience layer on top of it.

## Commands

| Command | What it does |
| --- | --- |
| **Talend2PySpark: Convert Talend Job** | Runs `python run.py --provider <configured>` in the integrated terminal (the full 4-agent orchestrator). |
| **Talend2PySpark: Explain Talend Job with Copilot** | Calls `vscode.lm.selectChatModels({vendor:'copilot'})` and streams a Copilot explanation of the open `.item` file into a new Markdown editor. |
| **Talend2PySpark: Run Generated PySpark Pipeline** | Runs the generated pipeline against `data/input → data/output`. |

## Settings

- `talend2pyspark.provider` — `offline` | `github_copilot` | `openai`
- `talend2pyspark.pythonPath` — interpreter used to run the orchestrator
- `talend2pyspark.copilotModelFamily` — Copilot model family for the explain command (default `gpt-4o`)

## Build & run

```bash
cd vscode-extension
npm install
npm run compile
```

Then press **F5** in VS Code to launch an Extension Development Host, open the
`talend-to-pyspark-orchestrator` folder inside it, and run any command from the
Command Palette (`Ctrl/Cmd+Shift+P`).

> The first time you run **Explain with Copilot**, VS Code shows a consent
> dialog because the extension is requesting access to Copilot's language
> models. You need the **GitHub Copilot Chat** extension installed and an
> active Copilot subscription.

## Requirements

- VS Code ≥ 1.90
- GitHub Copilot + GitHub Copilot Chat (for the Copilot commands)
- Python environment with the orchestrator installed (see the project README)
