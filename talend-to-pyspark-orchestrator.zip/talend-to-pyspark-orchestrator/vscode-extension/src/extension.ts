// Talend -> PySpark Copilot companion extension.
//
// Three commands:
//   1. talend2pyspark.convert            - runs the Python multi-agent orchestrator
//                                          in the integrated terminal.
//   2. talend2pyspark.explainWithCopilot - uses the NATIVE in-editor Copilot
//                                          language model (vscode.lm) to explain
//                                          the Talend job that is open / selected.
//   3. talend2pyspark.runGenerated       - runs the generated PySpark pipeline.
//
// The orchestrator (command 1) is the primary, fully-tested path. Command 2
// demonstrates driving GitHub Copilot's models directly from the editor.

import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('talend2pyspark.convert', runOrchestrator),
    vscode.commands.registerCommand('talend2pyspark.explainWithCopilot', explainWithCopilot),
    vscode.commands.registerCommand('talend2pyspark.runGenerated', runGenerated),
  );
}

export function deactivate() {}

function workspaceRoot(): string | undefined {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

function getTerminal(name: string): vscode.Terminal {
  const existing = vscode.window.terminals.find((t) => t.name === name);
  return existing ?? vscode.window.createTerminal(name);
}

// ---------------------------------------------------------------------------
// Command 1: run the Python orchestrator
// ---------------------------------------------------------------------------
async function runOrchestrator() {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showErrorMessage('Open the talend-to-pyspark-orchestrator folder first.');
    return;
  }
  const cfg = vscode.workspace.getConfiguration('talend2pyspark');
  const python = cfg.get<string>('pythonPath', 'python');
  const provider = cfg.get<string>('provider', 'offline');

  const term = getTerminal('talend2pyspark');
  term.show(true);
  term.sendText(`cd "${root}"`);
  term.sendText(`${python} run.py --provider ${provider}`);
  vscode.window.showInformationMessage(`Running orchestrator (provider=${provider})…`);
}

// ---------------------------------------------------------------------------
// Command 2: explain the Talend job using the in-editor Copilot model
// ---------------------------------------------------------------------------
async function explainWithCopilot() {
  const root = workspaceRoot();
  // Prefer the open editor; otherwise read the sample .item file.
  let jobXml = '';
  const editor = vscode.window.activeTextEditor;
  if (editor && editor.document.fileName.endsWith('.item')) {
    jobXml = editor.document.getText();
  } else if (root) {
    const sample = path.join(
      root, 'sample_talend_job', 'MoveCsvFile', 'MoveCsvFile_0.1.item',
    );
    if (fs.existsSync(sample)) {
      jobXml = fs.readFileSync(sample, 'utf8');
    }
  }
  if (!jobXml) {
    vscode.window.showErrorMessage('Open a Talend .item file to explain.');
    return;
  }

  // Select a Copilot model. selectChatModels must run from a user action and
  // triggers a consent dialog the first time.
  const [model] = await vscode.lm.selectChatModels({
    vendor: 'copilot',
    family: vscode.workspace.getConfiguration('talend2pyspark').get('copilotModelFamily', 'gpt-4o'),
  });
  if (!model) {
    vscode.window.showErrorMessage(
      'No Copilot model available. Install/enable the GitHub Copilot Chat extension and sign in.',
    );
    return;
  }

  const messages = [
    vscode.LanguageModelChatMessage.User(
      'You are a senior data engineer. Explain, precisely and in order, the ' +
        'business logic of the following Talend job: the source read, each ' +
        'tMap output rule, any row filters, the target write, and any ' +
        'post-actions such as deleting the source file. Be faithful to the XML.',
    ),
    vscode.LanguageModelChatMessage.User(jobXml),
  ];

  const doc = await vscode.workspace.openTextDocument({
    language: 'markdown',
    content: '# Talend Job Explanation (via Copilot)\n\n',
  });
  const out = await vscode.window.showTextDocument(doc, { preview: false });

  try {
    const resp = await model.sendRequest(
      messages, {}, new vscode.CancellationTokenSource().token,
    );
    for await (const fragment of resp.text) {
      await out.edit((edit) => {
        const last = new vscode.Position(out.document.lineCount, 0);
        edit.insert(last, fragment);
      });
    }
  } catch (err) {
    if (err instanceof vscode.LanguageModelError) {
      vscode.window.showErrorMessage(`Copilot error: ${err.message} (${err.code})`);
    } else {
      throw err;
    }
  }
}

// ---------------------------------------------------------------------------
// Command 3: run the generated PySpark pipeline
// ---------------------------------------------------------------------------
async function runGenerated() {
  const root = workspaceRoot();
  if (!root) {
    return;
  }
  const cfg = vscode.workspace.getConfiguration('talend2pyspark');
  const python = cfg.get<string>('pythonPath', 'python');
  const script = path.join(root, 'workspace', '02_pyspark_code', 'generated_pipeline.py');
  if (!fs.existsSync(script)) {
    vscode.window.showErrorMessage('Run the orchestrator first to generate the pipeline.');
    return;
  }
  const term = getTerminal('talend2pyspark');
  term.show(true);
  term.sendText(`cd "${root}"`);
  term.sendText(
    `${python} "${script}" --input-dir data/input --output-dir data/output --file-name customers.csv`,
  );
}
