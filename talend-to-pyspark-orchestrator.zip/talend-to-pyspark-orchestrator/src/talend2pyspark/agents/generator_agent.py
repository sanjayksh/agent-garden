"""Agent 2 - PySpark Code Generator.

Reads the extracted logic spec and produces a runnable PySpark pipeline, saving
it to the code-output folder. With a real LLM backend the model writes the code
from the prompt; with the offline backend the deterministic generator is used.
A safety net validates that the produced code is syntactically valid Python and
falls back to the deterministic generator if the LLM returns something broken.
"""
from __future__ import annotations

import ast

from ..context import RunContext
from ..prompts import generator_prompt
from ..talend.codegen import generate_pyspark
from ..utils.fs import ensure_dir, write_text
from .base import BaseAgent

_MODULE_NAME = "generated_pipeline"


class GeneratorAgent(BaseAgent):
    name = "generator"
    number = 2

    def execute(self, ctx: RunContext) -> None:
        cfg = ctx.config
        spec = ctx.logic_spec
        if spec is None:
            raise RuntimeError("GeneratorAgent: no logic spec in context (Agent 1 did not run).")

        self.log.info("generating PySpark for job '%s'", spec.get("job_name"))
        response = self.ask(
            generator_prompt.SYSTEM,
            generator_prompt.user(spec, _MODULE_NAME),
            task="generate_pyspark",
            payload=spec,
            module_name=_MODULE_NAME,
        )
        code = self.extract_code_block(response)

        # validate; if the backend returned invalid Python, fall back.
        if not self._is_valid_python(code):
            self.log.warning("LLM code failed to parse; using deterministic generator")
            code = generate_pyspark(spec, _MODULE_NAME)

        ensure_dir(cfg.pyspark_code_dir)
        path = cfg.pyspark_code_dir / f"{_MODULE_NAME}.py"
        ctx.pyspark_code = code
        ctx.pyspark_code_path = write_text(path, code)
        ctx.add_note(f"Agent 2 wrote PySpark pipeline: {path}")
        self.log.info("PySpark pipeline written: %s (%d lines)", path, code.count(chr(10)))

    @staticmethod
    def _is_valid_python(code: str) -> bool:
        try:
            ast.parse(code)
            return True
        except SyntaxError:
            return False
