"""Agent 3 - Logic Mapping / Traceability.

Builds the Talend -> PySpark mapping table that proves each business rule was
converted, and writes it to a Word document. With a real LLM backend the model
returns the mapping as JSON; the deterministic mapping is used as the offline
backend and as a fallback/merge when the LLM output is unusable.
"""
from __future__ import annotations

from ..context import RunContext
from ..docgen.mapping_doc import build_mapping_doc
from ..prompts import mapper_prompt
from ..talend.mapping import build_mapping
from ..utils.fs import ensure_dir
from .base import BaseAgent

_REQUIRED_KEYS = {"id", "talend", "talend_detail", "pyspark", "intent", "status"}


class MapperAgent(BaseAgent):
    name = "mapper"
    number = 3

    def execute(self, ctx: RunContext) -> None:
        cfg = ctx.config
        spec = ctx.logic_spec
        if spec is None:
            raise RuntimeError("MapperAgent: no logic spec in context (Agent 1 did not run).")

        response = self.ask(
            mapper_prompt.SYSTEM,
            mapper_prompt.user(spec, ctx.pyspark_code or ""),
            task="build_mapping",
            payload=spec,
        )

        rows = self._parse_rows(response)
        if not rows:
            self.log.warning("LLM mapping unusable; using deterministic mapping")
            rows = build_mapping(spec)

        ctx.mapping_rows = rows
        ensure_dir(cfg.mapping_dir)
        ctx.mapping_doc_path = build_mapping_doc(
            spec, rows, cfg.mapping_dir / f"{cfg.job_name}_logic_mapping.docx"
        )
        ctx.add_note(f"Agent 3 wrote mapping doc: {ctx.mapping_doc_path}")
        self.log.info("mapping document: %s (%d rows)", ctx.mapping_doc_path, len(rows))

    def _parse_rows(self, response: str) -> list[dict]:
        try:
            data = self.extract_json(response)
        except (ValueError, TypeError):
            return []
        if not isinstance(data, list):
            return []
        clean: list[dict] = []
        for item in data:
            if isinstance(item, dict) and _REQUIRED_KEYS.issubset(item.keys()):
                clean.append({k: str(item[k]) for k in _REQUIRED_KEYS})
        return clean
