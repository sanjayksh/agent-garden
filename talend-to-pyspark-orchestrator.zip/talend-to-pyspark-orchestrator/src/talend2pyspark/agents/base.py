"""Base agent.

Agents are chained: each agent does its work, then *hands off* to the next
agent in the chain (Agent 1 -> Agent 2 -> Agent 3 -> Agent 4). The orchestrator
builds the chain and starts Agent 1, which mirrors the brief's requirement that
"the first agent calls the next agent".
"""
from __future__ import annotations

import json
import re
from typing import Any

from ..context import RunContext
from ..llm.base import LLMProvider, Message
from ..utils.logging import get_logger


class BaseAgent:
    name: str = "agent"
    number: int = 0

    def __init__(self, llm: LLMProvider):
        self.llm = llm
        self.next: "BaseAgent | None" = None
        self.log = get_logger(f"t2p.agent{self.number}.{self.name}")

    # -- chaining ---------------------------------------------------------
    def set_next(self, agent: "BaseAgent") -> "BaseAgent":
        self.next = agent
        return agent

    def run(self, ctx: RunContext) -> None:
        self.log.info("=== Agent %d (%s) starting ===", self.number, self.name)
        self.execute(ctx)
        self.log.info("=== Agent %d (%s) complete ===", self.number, self.name)
        if self.next is not None:
            self.log.info("handing off to Agent %d (%s)", self.next.number, self.next.name)
            self.next.run(ctx)

    # -- to be implemented ------------------------------------------------
    def execute(self, ctx: RunContext) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    # -- helpers ----------------------------------------------------------
    def ask(self, system: str, user: str, **kwargs) -> str:
        """Send a prompt to the configured LLM backend."""
        return self.llm.complete([Message("system", system), Message("user", user)], **kwargs)

    @staticmethod
    def extract_code_block(text: str) -> str:
        """Pull the python code out of a ```python ...``` block (or return as-is)."""
        m = re.search(r"```(?:python|py)?\s*\n(.*?)```", text, re.DOTALL)
        return (m.group(1) if m else text).strip() + "\n"

    @staticmethod
    def extract_json(text: str) -> Any:
        """Parse a JSON array/object, tolerating code fences and surrounding prose."""
        m = re.search(r"```(?:json)?\s*\n(.*?)```", text, re.DOTALL)
        candidate = m.group(1) if m else text
        # fall back to the first [...] or {...} span
        if not m:
            sm = re.search(r"(\[.*\]|\{.*\})", candidate, re.DOTALL)
            if sm:
                candidate = sm.group(1)
        return json.loads(candidate)
