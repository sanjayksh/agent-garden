"""Agent 4 - Validation & Test.

Proves the converted pipeline behaves like the Talend job. When execution is
enabled (and pyspark + Java are available) it runs the generated pipeline
against a *temporary copy* of the sample input (so the canonical sample data is
left untouched and the user can still run the pipeline themselves), then checks:

  - row-count reconciliation against the Talend filter,
  - each transformation rule (trim / upper / round / current-date / passthrough),
  - move semantics (the source file is deleted),

and writes a validation-report Word document. If execution is disabled it falls
back to a static review of the generated code.
"""
from __future__ import annotations

import csv
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from ..context import RunContext
from ..docgen.validation_doc import build_validation_doc
from ..prompts import validator_prompt
from ..talend.narrative import validation_narrative
from ..utils.fs import ensure_dir
from .base import BaseAgent


class ValidatorAgent(BaseAgent):
    name = "validator"
    number = 4

    def execute(self, ctx: RunContext) -> None:
        cfg = ctx.config
        spec = ctx.logic_spec or {}

        if cfg.execute_validation and ctx.pyspark_code_path and self._spark_available():
            result = self._execute_and_check(ctx)
        else:
            result = self._static_check(ctx)

        ctx.validation_result = result
        summary = self.ask(
            validator_prompt.SYSTEM,
            validator_prompt.user(spec, result),
            task="validation_summary",
            payload=result,
        )
        if not summary.strip():
            summary = validation_narrative(result)

        ensure_dir(cfg.validation_dir)
        ctx.validation_doc_path = build_validation_doc(
            spec, result, summary, cfg.validation_dir / f"{cfg.job_name}_validation_report.docx"
        )
        ctx.add_note(
            f"Agent 4 verdict: {'PASS' if result['passed'] else 'FAIL'} "
            f"(doc: {ctx.validation_doc_path})"
        )
        self.log.info("validation %s", "PASSED" if result["passed"] else "FAILED")

    # ------------------------------------------------------------------
    @staticmethod
    def _spark_available() -> bool:
        try:
            import pyspark  # noqa: F401
            return True
        except ImportError:
            return False

    @staticmethod
    def _file_name(spec: dict[str, Any]) -> str:
        for c in spec.get("context", []):
            if c["name"] == "FILE_NAME":
                return c.get("value", "customers.csv")
        return "customers.csv"

    @staticmethod
    def _read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
        with path.open(newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            rows = list(reader)
            return (reader.fieldnames or []), rows

    # ------------------------------------------------------------------
    def _execute_and_check(self, ctx: RunContext) -> dict[str, Any]:
        cfg = ctx.config
        spec = ctx.logic_spec or {}
        file_name = self._file_name(spec)
        checks: list[dict[str, Any]] = []

        # work entirely inside a temp dir so the sample data is preserved
        tmp = Path(tempfile.mkdtemp(prefix="t2p_validate_"))
        in_dir = ensure_dir(tmp / "input")
        out_dir = ensure_dir(tmp / "output")
        src_sample = cfg.input_dir / file_name
        if not src_sample.exists():
            shutil.rmtree(tmp, ignore_errors=True)
            return self._static_check(ctx, reason=f"sample input not found: {src_sample}")
        shutil.copy(src_sample, in_dir / file_name)

        # count + filter the input ourselves to get the expected output rows
        in_fields, in_rows = self._read_csv(in_dir / file_name)
        expected = self._expected_output_count(spec, in_rows)

        # run the generated pipeline exactly like a user would
        cmd = [
            sys.executable, str(ctx.pyspark_code_path),
            "--input-dir", str(in_dir),
            "--output-dir", str(out_dir),
            "--file-name", file_name,
        ]
        self.log.info("executing generated pipeline: %s", " ".join(cmd))
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        executed = proc.returncode == 0
        if not executed:
            checks.append({
                "name": "Pipeline executes without error",
                "passed": False,
                "detail": (proc.stderr or proc.stdout or "non-zero exit").strip()[-400:],
            })
            shutil.rmtree(tmp, ignore_errors=True)
            return {
                "passed": False, "executed": True,
                "input_rows": len(in_rows), "output_rows": 0,
                "output_path": str(cfg.output_dir / file_name),
                "sample_output": "", "checks": checks,
            }
        checks.append({"name": "Pipeline executes without error", "passed": True,
                       "detail": "Process exited 0."})

        out_path = out_dir / file_name
        out_fields, out_rows = self._read_csv(out_path)

        # 1. row-count reconciliation
        checks.append({
            "name": "Row count after filter",
            "passed": len(out_rows) == expected,
            "detail": f"expected {expected}, got {len(out_rows)} "
                      f"(from {len(in_rows)} source rows).",
        })

        # 2. per-rule checks
        checks.extend(self._rule_checks(spec, out_fields, out_rows))

        # 3. move semantics: the temp source must be gone
        moved = not (in_dir / file_name).exists()
        if spec.get("post_actions"):
            checks.append({
                "name": "Move semantics (source deleted)",
                "passed": moved,
                "detail": "source removed after write." if moved else "source still present.",
            })

        sample = self._sample_text(out_path)
        shutil.rmtree(tmp, ignore_errors=True)

        passed = all(c["passed"] for c in checks)
        return {
            "passed": passed,
            "executed": True,
            "input_rows": len(in_rows),
            "output_rows": len(out_rows),
            "output_path": str(cfg.output_dir / file_name),
            "sample_output": sample,
            "checks": checks,
        }

    # ------------------------------------------------------------------
    def _expected_output_count(self, spec: dict[str, Any], in_rows: list[dict[str, str]]) -> int:
        """Apply the Talend filters to the raw input to predict the row count."""
        def keep(row: dict[str, str]) -> bool:
            for f in spec.get("filters", []):
                expr = f["talend_expr"]
                # support simple "row1.col <op> number"
                import re
                m = re.fullmatch(r"\s*row\d+\.(\w+)\s*(>=|<=|==|!=|>|<)\s*(-?\d+(?:\.\d+)?)\s*", expr)
                if not m:
                    continue
                col, op, val = m.group(1), m.group(2), float(m.group(3))
                try:
                    x = float(row.get(col, "nan"))
                except ValueError:
                    return True
                ok = {">=": x >= val, "<=": x <= val, ">": x > val,
                      "<": x < val, "==": x == val, "!=": x != val}[op]
                if not ok:
                    return False
            return True
        return sum(1 for r in in_rows if keep(r))

    def _rule_checks(self, spec, out_fields, out_rows) -> list[dict[str, Any]]:
        checks: list[dict[str, Any]] = []
        for t in spec.get("transformations", []):
            name, expr = t["output"], t["talend_expr"]
            present = name in out_fields
            if "TRIM" in expr:
                bad = [r[name] for r in out_rows if present and r[name] != r[name].strip()]
                checks.append({"name": f"{t['id']} trim({name})", "passed": present and not bad,
                               "detail": "no leading/trailing whitespace." if not bad
                               else f"{len(bad)} value(s) not trimmed."})
            elif "UPCASE" in expr:
                bad = [r[name] for r in out_rows if present and r[name] != r[name].upper()]
                checks.append({"name": f"{t['id']} upper({name})", "passed": present and not bad,
                               "detail": "all values upper-case." if not bad
                               else f"{len(bad)} value(s) not upper-cased."})
            elif "Math.round" in expr:
                bad = [r[name] for r in out_rows
                       if present and "." in r[name] and len(r[name].split(".")[1]) > 2]
                checks.append({"name": f"{t['id']} round({name})", "passed": present and not bad,
                               "detail": "<= 2 decimal places." if not bad
                               else f"{len(bad)} value(s) over 2 decimals."})
            elif "getCurrentDate" in expr:
                filled = present and all(r[name].strip() for r in out_rows) and bool(out_rows)
                checks.append({"name": f"{t['id']} {name} stamped", "passed": filled,
                               "detail": "load date present on all rows." if filled
                               else "load date missing."})
            else:
                checks.append({"name": f"{t['id']} {name} present", "passed": present,
                               "detail": "column present in output." if present
                               else "column missing from output."})
        return checks

    @staticmethod
    def _sample_text(out_path: Path, max_lines: int = 6) -> str:
        try:
            lines = out_path.read_text(encoding="utf-8").splitlines()
            return "\n".join(lines[:max_lines])
        except OSError:
            return ""

    # ------------------------------------------------------------------
    def _static_check(self, ctx: RunContext, reason: str = "") -> dict[str, Any]:
        code = ctx.pyspark_code or ""
        checks = [
            {"name": "Generated code present", "passed": bool(code.strip()),
             "detail": "code file was produced." if code.strip() else "no code produced."},
            {"name": "Uses explicit schema", "passed": "StructType(" in code,
             "detail": "StructType found." if "StructType(" in code else "no explicit schema."},
            {"name": "Reads source", "passed": "read_source" in code,
             "detail": "read_source() present."},
            {"name": "Applies transform", "passed": "def transform" in code,
             "detail": "transform() present."},
            {"name": "Writes single CSV", "passed": "write_single_csv" in code,
             "detail": "single-file writer present."},
        ]
        if ctx.logic_spec and ctx.logic_spec.get("post_actions"):
            checks.append({"name": "Implements move", "passed": "finalize_move" in code,
                           "detail": "finalize_move() present."})
        if reason:
            checks.append({"name": "Execution skipped", "passed": True, "detail": reason})
        return {
            "passed": all(c["passed"] for c in checks),
            "executed": False,
            "checks": checks,
        }
