"""Agent 1 - Parser / Logic Extractor.

Reads the Talend job (.properties + .item) from the input folder, extracts the
business logic into a structured spec, asks the LLM for a natural-language
narrative, and writes a business-logic Word document plus a machine-readable
logic.json for the downstream agents.
"""
from __future__ import annotations

from ..context import RunContext
from ..docgen.logic_doc import build_logic_doc
from ..prompts import parser_prompt
from ..talend.narrative import logic_narrative
from ..talend.parser import parse_job
from ..utils.fs import ensure_dir, find_one, read_text, write_json
from .base import BaseAgent


class ParserAgent(BaseAgent):
    name = "parser"
    number = 1

    def execute(self, ctx: RunContext) -> None:
        cfg = ctx.config

        # 1. Deterministically parse the Talend export into a logic spec.
        self.log.info("parsing Talend job at %s", cfg.talend_input)
        spec = parse_job(cfg.talend_input)
        ctx.logic_spec = spec
        self.log.info(
            "extracted %d transformation(s), %d filter(s), %d post-action(s)",
            len(spec["transformations"]), len(spec["filters"]), len(spec["post_actions"]),
        )

        # 2. Persist the structured logic for the next agents.
        ensure_dir(cfg.extracted_logic_dir)
        ctx.logic_json_path = write_json(cfg.extracted_logic_dir / "logic.json", spec)

        # 3. Ask the LLM (or offline backend) for a readable narrative.
        raw_item = read_text(find_one(cfg.talend_input, ".item"))
        narrative = self.ask(
            parser_prompt.SYSTEM,
            parser_prompt.user(spec, raw_item),
            task="extract_logic_narrative",
            payload=spec,
        )
        if not narrative.strip():
            narrative = logic_narrative(spec)  # safety fallback

        # 4. Build the business-logic Word document.
        ctx.logic_doc_path = build_logic_doc(
            spec, narrative, cfg.extracted_logic_dir / f"{cfg.job_name}_business_logic.docx"
        )
        ctx.add_note(f"Agent 1 wrote business-logic doc: {ctx.logic_doc_path}")
        self.log.info("logic document: %s", ctx.logic_doc_path)
