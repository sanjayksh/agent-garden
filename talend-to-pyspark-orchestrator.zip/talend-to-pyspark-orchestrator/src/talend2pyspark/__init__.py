"""talend2pyspark - a multi-agent (Copilot) orchestrator that converts Talend
data-processing pipelines into PySpark pipelines.

The package is organised around four agents wired together by an orchestrator:

    Agent 1  ParserAgent      .item/.properties  -> business-logic Word doc + logic.json
    Agent 2  GeneratorAgent   logic.json         -> PySpark pipeline (.py)
    Agent 3  MapperAgent      logic + code       -> Talend->PySpark mapping Word doc
    Agent 4  ValidatorAgent   code               -> executes & writes a validation report

Each agent talks to a pluggable LLM backend (offline / GitHub Copilot / OpenAI)
through the `talend2pyspark.llm` provider abstraction.
"""

__version__ = "1.0.0"

__all__ = ["__version__"]
