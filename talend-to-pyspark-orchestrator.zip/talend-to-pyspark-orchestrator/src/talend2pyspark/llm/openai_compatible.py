"""Generic OpenAI-compatible provider.

Works with the OpenAI API, Azure OpenAI, local servers (Ollama, vLLM, LM Studio,
llama.cpp) and any gateway that serves POST {base_url}/chat/completions in the
OpenAI schema.
"""
from __future__ import annotations

import json

import requests

from .base import LLMError, LLMProvider, Message


class OpenAICompatibleProvider(LLMProvider):
    name = "openai"

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        model: str = "gpt-4o",
        temperature: float = 0.1,
        max_tokens: int = 4096,
        timeout: int = 120,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout

    @property
    def endpoint(self) -> str:
        return f"{self.base_url}/chat/completions"

    def complete(self, messages: list[Message], **kwargs) -> str:
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        try:
            resp = requests.post(
                self.endpoint, headers=headers, data=json.dumps(payload), timeout=self.timeout
            )
        except requests.RequestException as exc:
            raise LLMError(f"OpenAI-compatible request failed: {exc}") from exc
        if resp.status_code >= 400:
            raise LLMError(f"LLM endpoint returned HTTP {resp.status_code}: {resp.text[:500]}")
        try:
            return resp.json()["choices"][0]["message"]["content"]
        except (KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"Unexpected LLM response: {resp.text[:500]}") from exc
