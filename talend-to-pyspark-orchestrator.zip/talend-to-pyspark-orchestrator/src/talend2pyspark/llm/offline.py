"""Offline, deterministic 'LLM' backend.

This backend requires no credentials and no network. It produces exactly the
output shape each agent's prompt asks for, driven by a structured ``task`` and
``payload`` passed as keyword arguments. Real LLM backends ignore those kwargs
and answer from the message text instead; the offline backend uses them to
generate a reliable, repeatable result.

This is what makes the whole package runnable and testable out-of-the-box, and
it also serves as the deterministic fallback when a network LLM call fails.
"""
from __future__ import annotations

import json

from ..talend.codegen import generate_pyspark
from ..talend.mapping import build_mapping
from ..talend.narrative import logic_narrative, validation_narrative
from .base import LLMError, LLMProvider, Message


class OfflineProvider(LLMProvider):
    name = "offline"

    def complete(self, messages: list[Message], **kwargs) -> str:
        task = kwargs.get("task")
        payload = kwargs.get("payload") or {}

        if task == "extract_logic_narrative":
            return logic_narrative(payload)

        if task == "generate_pyspark":
            module_name = kwargs.get("module_name", "generated_pipeline")
            return "```python\n" + generate_pyspark(payload, module_name) + "\n```"

        if task == "build_mapping":
            return json.dumps(build_mapping(payload), indent=2)

        if task == "validation_summary":
            return validation_narrative(payload)

        # No structured task -> echo a short, deterministic acknowledgement so
        # the offline backend never blocks a generic call.
        if not task:
            user = next((m.content for m in reversed(messages) if m.role == "user"), "")
            return f"[offline] Acknowledged request ({len(user)} chars)."

        raise LLMError(f"OfflineProvider received an unknown task: {task!r}")
