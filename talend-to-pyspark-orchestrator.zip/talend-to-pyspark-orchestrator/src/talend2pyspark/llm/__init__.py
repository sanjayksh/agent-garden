"""Build an :class:`LLMProvider` from configuration."""
from __future__ import annotations

from ..config import LLMConfig
from ..utils.logging import get_logger
from .base import LLMError, LLMProvider, Message
from .github_copilot import GitHubCopilotProvider
from .offline import OfflineProvider
from .openai_compatible import OpenAICompatibleProvider

log = get_logger("t2p.llm")


def build_provider(cfg: LLMConfig) -> LLMProvider:
    provider = (cfg.provider or "offline").lower()

    if provider == "offline":
        log.info("LLM backend: offline (deterministic, no credentials)")
        return OfflineProvider()

    if provider == "github_copilot":
        log.info("LLM backend: github_copilot (%s, model=%s)", cfg.github_base_url, cfg.github_model)
        return GitHubCopilotProvider(
            token=cfg.github_token,
            base_url=cfg.github_base_url,
            model=cfg.github_model,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
        )

    if provider == "openai":
        log.info("LLM backend: openai-compatible (%s, model=%s)", cfg.openai_base_url, cfg.openai_model)
        return OpenAICompatibleProvider(
            api_key=cfg.openai_api_key,
            base_url=cfg.openai_base_url,
            model=cfg.openai_model,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
        )

    raise LLMError(f"Unknown LLM provider: {cfg.provider!r}")


__all__ = [
    "LLMProvider",
    "Message",
    "LLMError",
    "OfflineProvider",
    "GitHubCopilotProvider",
    "OpenAICompatibleProvider",
    "build_provider",
]
