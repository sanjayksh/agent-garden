"""LLM provider abstraction.

Every agent depends only on the :class:`LLMProvider` interface, never on a
concrete backend. This makes the agents identical whether they are driven by
the deterministic offline converter, GitHub Copilot (GitHub Models), or any
OpenAI-compatible endpoint.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass


@dataclass
class Message:
    role: str  # "system" | "user" | "assistant"
    content: str


class LLMProvider(abc.ABC):
    """Common interface implemented by every backend."""

    #: human-readable backend name, used in logs and reports
    name: str = "base"

    @abc.abstractmethod
    def complete(self, messages: list[Message], **kwargs) -> str:
        """Return the assistant's reply text for the given messages."""
        raise NotImplementedError

    # convenience -----------------------------------------------------------
    def chat(self, system: str, user: str, **kwargs) -> str:
        return self.complete(
            [Message("system", system), Message("user", user)], **kwargs
        )


class LLMError(RuntimeError):
    """Raised when a backend cannot produce a completion."""
