"""GitHub Copilot / GitHub Models provider.

Calls the GitHub-hosted, OpenAI-compatible inference endpoint:

    POST https://models.github.ai/inference/chat/completions
    Authorization: Bearer <GITHUB_PAT with models:read>
    X-GitHub-Api-Version: 2026-03-10

This is the same model catalogue that powers GitHub Copilot, callable
programmatically with a GitHub Personal Access Token. Reference:
https://docs.github.com/en/rest/models/inference
"""
from __future__ import annotations

import json

import requests

from .base import LLMError, LLMProvider, Message

_API_VERSION = "2026-03-10"


class GitHubCopilotProvider(LLMProvider):
    name = "github_copilot"

    def __init__(
        self,
        token: str,
        base_url: str = "https://models.github.ai/inference",
        model: str = "openai/gpt-4o",
        temperature: float = 0.1,
        max_tokens: int = 4096,
        timeout: int = 120,
    ) -> None:
        if not token:
            raise LLMError(
                "GITHUB_TOKEN is empty. Create a GitHub Personal Access Token "
                "with the 'models: read' permission and set GITHUB_TOKEN."
            )
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout

    @property
    def endpoint(self) -> str:
        # base_url already ends with '/inference' (or '/orgs/<org>/inference')
        return f"{self.base_url}/chat/completions"

    def complete(self, messages: list[Message], **kwargs) -> str:
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
        }
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": _API_VERSION,
        }
        try:
            resp = requests.post(
                self.endpoint, headers=headers, data=json.dumps(payload), timeout=self.timeout
            )
        except requests.RequestException as exc:  # network failure
            raise LLMError(f"GitHub Models request failed: {exc}") from exc

        if resp.status_code >= 400:
            raise LLMError(
                f"GitHub Models returned HTTP {resp.status_code}: {resp.text[:500]}"
            )
        try:
            data = resp.json()
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"Unexpected GitHub Models response: {resp.text[:500]}") from exc
