"""Shared run context.

A single :class:`RunContext` instance threads through the orchestrator and all
four agents. It carries the resolved configuration plus the artifacts produced
so far, so each agent can consume the previous agent's output.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import Config


@dataclass
class RunContext:
    config: Config

    # ---- Agent 1 (parser) outputs --------------------------------------
    logic_spec: dict[str, Any] | None = None          # structured business logic
    logic_json_path: Path | None = None
    logic_doc_path: Path | None = None

    # ---- Agent 2 (generator) outputs -----------------------------------
    pyspark_code: str | None = None
    pyspark_code_path: Path | None = None

    # ---- Agent 3 (mapper) outputs --------------------------------------
    mapping_rows: list[dict[str, Any]] = field(default_factory=list)
    mapping_doc_path: Path | None = None

    # ---- Agent 4 (validator) outputs -----------------------------------
    validation_result: dict[str, Any] | None = None
    validation_doc_path: Path | None = None

    # free-form notes any agent may append for the final summary
    notes: list[str] = field(default_factory=list)

    def add_note(self, message: str) -> None:
        self.notes.append(message)
