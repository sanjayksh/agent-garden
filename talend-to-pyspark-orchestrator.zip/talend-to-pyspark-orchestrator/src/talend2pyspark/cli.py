"""Command-line interface for the talend2pyspark orchestrator."""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .config import load_config
from .orchestrator import run_pipeline
from .utils.logging import configure, get_logger

log = get_logger("t2p.cli")


def _find_project_root(explicit: str | None) -> Path:
    if explicit:
        return Path(explicit).resolve()
    # default: two levels up from this file (src/talend2pyspark/cli.py -> project root)
    here = Path(__file__).resolve()
    candidate = here.parents[2]
    return candidate


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="talend2pyspark",
        description="Convert a Talend job to PySpark using four chained Copilot agents.",
    )
    p.add_argument("--talend-input", help="Folder with the Talend .properties/.item files")
    p.add_argument("--workspace", help="Folder for agent artifacts")
    p.add_argument("--input-dir", help="Folder the generated pipeline reads from")
    p.add_argument("--output-dir", help="Folder the generated pipeline writes to")
    p.add_argument("--provider", choices=["offline", "github_copilot", "openai"],
                   help="LLM backend (overrides settings.yaml / env)")
    p.add_argument("--settings", help="Path to settings.yaml")
    p.add_argument("--project-root", help="Project root (defaults to the package's parent)")
    p.add_argument("--no-validate", action="store_true",
                   help="Skip Agent 4's live execution; do a static review instead")
    p.add_argument("-v", "--verbose", action="store_true", help="Debug logging")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    configure(logging.DEBUG if args.verbose else logging.INFO)

    root = _find_project_root(args.project_root)
    overrides = {
        "talend_input": args.talend_input,
        "workspace": args.workspace,
        "input_dir": args.input_dir,
        "output_dir": args.output_dir,
        "provider": args.provider,
    }
    if args.no_validate:
        overrides["execute_validation"] = False

    cfg = load_config(project_root=root, settings_file=args.settings, **overrides)
    ctx = run_pipeline(cfg)

    # ---- summary --------------------------------------------------------
    print("\n" + "=" * 70)
    print("  CONVERSION COMPLETE")
    print("=" * 70)
    print(f"  Talend job          : {cfg.job_name}")
    print(f"  LLM backend         : {cfg.llm.provider}")
    print(f"  Business-logic doc  : {ctx.logic_doc_path}")
    print(f"  Logic JSON          : {ctx.logic_json_path}")
    print(f"  Generated PySpark   : {ctx.pyspark_code_path}")
    print(f"  Mapping doc         : {ctx.mapping_doc_path}")
    print(f"  Validation report   : {ctx.validation_doc_path}")
    if ctx.validation_result is not None:
        verdict = "PASS" if ctx.validation_result.get("passed") else "FAIL"
        print(f"  Validation verdict  : {verdict}")
    print("=" * 70)
    print("  Run the generated pipeline yourself with:")
    print(f"    python {ctx.pyspark_code_path} \\")
    print(f"        --input-dir {cfg.input_dir} --output-dir {cfg.output_dir}")
    print("=" * 70 + "\n")

    if ctx.validation_result is not None and not ctx.validation_result.get("passed"):
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
