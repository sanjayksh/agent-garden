"""The multi-agent orchestrator.

Responsibilities:
  - build the configured LLM backend,
  - prepare a clean workspace,
  - construct the four agents and wire them into a hand-off chain
        Agent 1 (Parser) -> Agent 2 (Generator) -> Agent 3 (Mapper) -> Agent 4 (Validator),
  - start Agent 1 (which then calls the next agent, and so on),
  - return the populated RunContext describing every artifact produced.
"""
from __future__ import annotations

from .agents import GeneratorAgent, MapperAgent, ParserAgent, ValidatorAgent
from .config import Config
from .context import RunContext
from .llm import build_provider
from .utils.fs import ensure_dir
from .utils.logging import get_logger

log = get_logger("t2p.orchestrator")


class Orchestrator:
    def __init__(self, config: Config):
        self.config = config
        self.llm = build_provider(config.llm)

    def _prepare_workspace(self) -> None:
        cfg = self.config
        for d in (
            cfg.workspace, cfg.extracted_logic_dir, cfg.pyspark_code_dir,
            cfg.mapping_dir, cfg.validation_dir, cfg.input_dir, cfg.output_dir,
        ):
            ensure_dir(d)

    def build_chain(self) -> ParserAgent:
        """Instantiate the agents and link them into a hand-off chain."""
        a1 = ParserAgent(self.llm)
        a2 = GeneratorAgent(self.llm)
        a3 = MapperAgent(self.llm)
        a4 = ValidatorAgent(self.llm)
        a1.set_next(a2)
        a2.set_next(a3)
        a3.set_next(a4)
        return a1

    def run(self) -> RunContext:
        cfg = self.config
        log.info("Talend job        : %s", cfg.talend_input)
        log.info("Workspace         : %s", cfg.workspace)
        log.info("LLM provider      : %s", cfg.llm.provider)
        log.info("Execute validation: %s", cfg.execute_validation)

        self._prepare_workspace()
        ctx = RunContext(config=cfg)
        first_agent = self.build_chain()

        try:
            first_agent.run(ctx)  # Agent 1 starts the chain and hands off
        except Exception as exc:  # noqa: BLE001
            if cfg.fail_fast:
                log.error("run failed: %s", exc)
                raise
            log.error("run continued past error (fail_fast=false): %s", exc)
            ctx.add_note(f"ERROR: {exc}")

        return ctx


def run_pipeline(config: Config) -> RunContext:
    """Convenience wrapper used by the CLI and tests."""
    return Orchestrator(config).run()
