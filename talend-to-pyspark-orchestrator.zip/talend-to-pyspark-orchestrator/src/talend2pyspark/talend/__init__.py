"""Talend parsing, translation, code generation and mapping."""
