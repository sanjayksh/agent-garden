"""Build the Talend -> PySpark traceability mapping from a logic spec.

Each row ties one Talend construct (a business rule, the source read, the
target write, or a post-action) to the PySpark construct that implements it,
plus a short conversion note. Agent 3 renders these rows into a Word table.
"""
from __future__ import annotations

from typing import Any

from .translate import translate_expression, translate_filter


def build_mapping(spec: dict[str, Any]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []

    # --- source read --------------------------------------------------------
    src = spec.get("source") or {}
    if src:
        rows.append(
            {
                "id": "—",
                "talend": f'{src.get("type", "")} ({src.get("component", "")})',
                "talend_detail": f'read {src.get("path_expr", "")}',
                "pyspark": "spark.read.option('header',...).schema(SOURCE_SCHEMA).csv(input_path)",
                "intent": "Read the delimited source file with an explicit schema.",
                "status": "Converted",
            }
        )

    # --- transformations (column projection) --------------------------------
    for t in spec.get("transformations", []):
        pyexpr, note = translate_expression(t["talend_expr"], t["output"])
        rows.append(
            {
                "id": t["id"],
                "talend": f'tMap out: {t["output"]}',
                "talend_detail": t["talend_expr"],
                "pyspark": f'{pyexpr}.alias("{t["output"]}")',
                "intent": t.get("intent", note),
                "status": "Review" if "TODO" in pyexpr else "Converted",
            }
        )

    # --- filters ------------------------------------------------------------
    for f in spec.get("filters", []):
        cond, note = translate_filter(f["talend_expr"])
        rows.append(
            {
                "id": f["id"],
                "talend": "tMap output filter",
                "talend_detail": f["talend_expr"],
                "pyspark": f"df.filter({cond})",
                "intent": f.get("intent", note),
                "status": "Review" if "TODO" in cond else "Converted",
            }
        )

    # --- target write -------------------------------------------------------
    tgt = spec.get("target") or {}
    if tgt:
        rows.append(
            {
                "id": "—",
                "talend": f'{tgt.get("type", "")} ({tgt.get("component", "")})',
                "talend_detail": f'write {tgt.get("path_expr", "")}',
                "pyspark": "write_single_csv(df, output_path)  # coalesce(1) + single-file rename",
                "intent": "Write a single delimited output file (Talend single-file semantics).",
                "status": "Converted",
            }
        )

    # --- post actions (move / delete) ---------------------------------------
    for pa in spec.get("post_actions", []):
        rows.append(
            {
                "id": pa["id"],
                "talend": f'{pa.get("type", "")} ({pa.get("component", "")})',
                "talend_detail": f'delete {pa.get("path_expr", "")}',
                "pyspark": "finalize_move(input_path, delete_source=True)  # os.remove(source)",
                "intent": pa.get("intent", "Delete source after write (move)."),
                "status": "Converted",
            }
        )

    return rows


def coverage(rows: list[dict[str, str]]) -> dict[str, int]:
    converted = sum(1 for r in rows if r["status"] == "Converted")
    review = sum(1 for r in rows if r["status"] == "Review")
    return {"total": len(rows), "converted": converted, "review": review}
