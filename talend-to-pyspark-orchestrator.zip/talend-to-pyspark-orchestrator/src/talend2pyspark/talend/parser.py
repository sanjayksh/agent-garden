"""Parse a Talend Standard Job export (.properties + .item) into a structured,
namespace-agnostic *logic spec* dictionary that the rest of the pipeline
consumes.

The parser is deliberately tolerant: it matches on local element/attribute
names so it is not tied to a specific Talend namespace URI version.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from ..utils.fs import find_one
from .translate import spark_type


# --------------------------------------------------------------------------
# namespace-agnostic helpers
# --------------------------------------------------------------------------
def _local(tag: str) -> str:
    return tag.split("}", 1)[-1]


def _iter(elem: ET.Element, name: str):
    for child in elem.iter():
        if _local(child.tag) == name:
            yield child


def _params(node: ET.Element) -> dict[str, str]:
    """Collect elementParameter name->value pairs for a node."""
    out: dict[str, str] = {}
    for ep in node:
        if _local(ep.tag) == "elementParameter":
            out[ep.get("name", "")] = ep.get("value", "")
    return out


def _schema(node: ET.Element, connector: str | None = None) -> list[dict[str, Any]]:
    """Read the first <metadata> block's columns (optionally a given connector)."""
    cols: list[dict[str, Any]] = []
    for md in node:
        if _local(md.tag) != "metadata":
            continue
        if connector and md.get("connector") and md.get("connector") != connector:
            continue
        for c in md:
            if _local(c.tag) != "column":
                continue
            ttype = c.get("type", "id_String")
            cols.append(
                {
                    "name": c.get("name", ""),
                    "talend_type": ttype,
                    "spark_type": spark_type(ttype),
                    "nullable": c.get("nullable", "true") == "true",
                    "pattern": (c.get("pattern", "") or "").strip('"'),
                    "comment": c.get("comment", ""),
                }
            )
        if cols:
            break
    return cols


def _unwrap(value: str) -> str:
    """Strip the outer double-quotes Talend uses around literal param values."""
    v = (value or "").strip()
    if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
        return v[1:-1]
    return v


# --------------------------------------------------------------------------
# main entry point
# --------------------------------------------------------------------------
def parse_job(job_folder: str | Path) -> dict[str, Any]:
    """Parse the Talend job in *job_folder* and return a logic-spec dict."""
    job_folder = Path(job_folder)
    item_path = find_one(job_folder, ".item")
    try:
        prop_path: Path | None = find_one(job_folder, ".properties")
    except FileNotFoundError:
        prop_path = None

    spec: dict[str, Any] = {
        "job_name": job_folder.name,
        "purpose": "",
        "description": "",
        "context": [],
        "source": None,
        "transformations": [],
        "filters": [],
        "target": None,
        "post_actions": [],
        "connections": [],
        "source_files": {
            "item": item_path.name,
            "properties": prop_path.name if prop_path else None,
        },
    }

    # ---- properties (purpose / description) -------------------------------
    if prop_path is not None:
        try:
            proot = ET.fromstring(prop_path.read_text(encoding="utf-8"))
            spec["purpose"] = proot.get("purpose", "") or spec["purpose"]
            spec["description"] = proot.get("description", "") or spec["description"]
        except ET.ParseError:
            pass  # property files occasionally carry odd namespaces; non-fatal

    # ---- item (the actual graph) ------------------------------------------
    root = ET.fromstring(item_path.read_text(encoding="utf-8"))

    # context variables
    for cp in _iter(root, "contextParameter"):
        spec["context"].append(
            {
                "name": cp.get("name", ""),
                "type": cp.get("type", ""),
                "value": cp.get("value", ""),
                "comment": cp.get("comment", ""),
            }
        )

    # nodes (components)
    br = 0  # business-rule counter
    for node in root:
        if _local(node.tag) != "node":
            continue
        comp = node.get("componentName", "")
        params = _params(node)
        uname = params.get("UNIQUE_NAME", comp)

        if comp == "tFileInputDelimited":
            spec["source"] = {
                "component": uname,
                "type": comp,
                "path_expr": params.get("FILENAME", ""),
                "field_separator": _unwrap(params.get("FIELDSEPARATOR", '","')),
                "row_separator": _unwrap(params.get("ROWSEPARATOR", r'"\n"')),
                "header": int(params.get("HEADER", "0") or "0"),
                "encoding": _unwrap(params.get("ENCODING", '"UTF-8"')),
                "schema": _schema(node, "FLOW"),
            }

        elif comp == "tMap":
            _parse_tmap(node, spec, lambda: _next_br(spec))

        elif comp == "tFileOutputDelimited":
            spec["target"] = {
                "component": uname,
                "type": comp,
                "path_expr": params.get("FILENAME", ""),
                "field_separator": _unwrap(params.get("FIELDSEPARATOR", '","')),
                "include_header": params.get("INCLUDEHEADER", "false") == "true",
                "append": params.get("APPEND", "false") == "true",
                "encoding": _unwrap(params.get("ENCODING", '"UTF-8"')),
                "schema": _schema(node),
            }

        elif comp == "tFileDelete":
            spec["post_actions"].append(
                {
                    "id": _next_br(spec),
                    "component": uname,
                    "type": comp,
                    "intent": "Delete the source file after a successful write (move semantics).",
                    "path_expr": params.get("FILENAME", ""),
                    "fail_on_error": params.get("FAIL_ON_ERROR", "false") == "true",
                }
            )

        # (other component types could be added here)

    # connections
    for conn in root:
        if _local(conn.tag) != "connection":
            continue
        spec["connections"].append(
            {
                "from": conn.get("source", ""),
                "to": conn.get("target", ""),
                "type": conn.get("connectorName", ""),
                "label": conn.get("label", ""),
            }
        )

    return spec


def _next_br(spec: dict[str, Any]) -> str:
    """Allocate the next BR-xx id based on how many rules already exist."""
    used = len(spec["transformations"]) + len(spec["filters"]) + len(spec["post_actions"])
    return f"BR-{used + 1:02d}"


def _parse_tmap(node: ET.Element, spec: dict[str, Any], _next) -> None:
    """Extract output expressions and filters from a tMap node."""
    # find the output table(s)
    for ot in _iter(node, "outputTables"):
        for entry in ot:
            ln = _local(entry.tag)
            if ln == "mapperTableEntries":
                expr = entry.get("expression", "")
                name = entry.get("name", "")
                if not name:
                    continue
                spec["transformations"].append(
                    {
                        "id": _next_br(spec),
                        "output": name,
                        "type": entry.get("type", "id_String"),
                        "spark_type": spark_type(entry.get("type", "id_String")),
                        "talend_expr": expr,
                        "intent": _intent_for(name, expr),
                    }
                )
            elif ln == "filterEntries":
                fexpr = entry.get("expression", "")
                if fexpr.strip():
                    spec["filters"].append(
                        {
                            "id": _next_br(spec),
                            "talend_expr": fexpr,
                            "intent": "Row filter: keep only rows matching the condition.",
                        }
                    )


def _intent_for(name: str, expr: str) -> str:
    e = expr
    if "TRIM" in e:
        return f"Trim leading/trailing whitespace from '{name}'."
    if "UPCASE" in e:
        return f"Standardise '{name}' to upper case."
    if "DOWNCASE" in e:
        return f"Standardise '{name}' to lower case."
    if "Math.round" in e:
        return f"Round '{name}' to a fixed number of decimal places."
    if "getCurrentDate" in e:
        return f"Stamp every row with the current load date as '{name}'."
    if expr.strip().startswith("row"):
        return f"Pass '{name}' through unchanged from the source."
    return f"Derive '{name}' using a custom expression."
