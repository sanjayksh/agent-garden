"""Templated natural-language narratives.

When the LLM backend is *offline*, these functions stand in for the model's
prose so the produced Word documents still read naturally. When a real LLM
backend is used, the model writes the narrative instead and these serve as the
deterministic fallback.
"""
from __future__ import annotations

from typing import Any


def logic_narrative(spec: dict[str, Any]) -> str:
    job = spec.get("job_name", "the job")
    src = spec.get("source") or {}
    tgt = spec.get("target") or {}
    n_rules = (
        len(spec.get("transformations", []))
        + len(spec.get("filters", []))
        + len(spec.get("post_actions", []))
    )
    lines = []
    lines.append(
        f"The Talend job '{job}' implements a file-move-with-standardisation "
        f"pattern. It reads a delimited source file, applies {n_rules} business "
        f"rule(s) in a tMap, writes a single delimited output file, and then "
        f"removes the source file to complete the move."
    )
    if src:
        cols = ", ".join(c["name"] for c in src.get("schema", []))
        lines.append(
            f"The source component {src.get('component','')} reads "
            f"{src.get('path_expr','the input path')} using '"
            f"{src.get('field_separator',',')}' as the field separator with "
            f"{'a header row' if src.get('header') else 'no header'}. The source "
            f"columns are: {cols}."
        )
    if spec.get("transformations"):
        lines.append("The tMap applies the following column-level rules:")
        for t in spec["transformations"]:
            lines.append(f"  - {t['id']}: {t['intent']} (Talend: {t['talend_expr']}).")
    if spec.get("filters"):
        for f in spec["filters"]:
            lines.append(f"  - {f['id']}: {f['intent']} (Talend: {f['talend_expr']}).")
    if tgt:
        lines.append(
            f"The result is written by {tgt.get('component','')} to "
            f"{tgt.get('path_expr','the output path')} "
            f"({'with' if tgt.get('include_header') else 'without'} a header)."
        )
    for pa in spec.get("post_actions", []):
        lines.append(f"  - {pa['id']}: {pa['intent']} (component {pa.get('component','')}).")
    return "\n".join(lines)


def validation_narrative(result: dict[str, Any]) -> str:
    status = "PASSED" if result.get("passed") else "FAILED"
    lines = [f"Validation {status}."]
    if result.get("executed"):
        lines.append(
            f"The generated PySpark pipeline was executed against the sample "
            f"input. {result.get('input_rows', '?')} source row(s) produced "
            f"{result.get('output_rows', '?')} output row(s)."
        )
    else:
        lines.append("Static review only (the pipeline was not executed).")
    for chk in result.get("checks", []):
        mark = "PASS" if chk["passed"] else "FAIL"
        lines.append(f"  [{mark}] {chk['name']}: {chk['detail']}")
    return "\n".join(lines)
