"""Translate individual Talend expressions into PySpark column expressions.

This is deliberately a small, well-understood rule set covering the constructs
used by file-move / standardisation jobs. Anything it does not recognise is
passed through verbatim as a commented TODO so a human reviewer can finish it
(the Validation agent will flag such rows).

Each translation returns a string of *PySpark column expression* source code,
assuming `from pyspark.sql import functions as F` and the source DataFrame's
columns are addressable via `F.col("<name>")`.
"""
from __future__ import annotations

import re

# Map Talend schema types -> Spark SQL types (class names from pyspark.sql.types)
TALEND_TO_SPARK_TYPE = {
    "id_Integer": "IntegerType",
    "id_Long": "LongType",
    "id_Short": "ShortType",
    "id_Byte": "ByteType",
    "id_Double": "DoubleType",
    "id_Float": "FloatType",
    "id_BigDecimal": "DecimalType",
    "id_String": "StringType",
    "id_Character": "StringType",
    "id_Boolean": "BooleanType",
    "id_Date": "DateType",
    "id_Object": "StringType",
}


def spark_type(talend_type: str) -> str:
    """Return the Spark type class name for a Talend `id_*` type."""
    return TALEND_TO_SPARK_TYPE.get(talend_type, "StringType")


def _src_col(expr: str) -> str | None:
    """Extract `<col>` from a simple `rowN.<col>` reference."""
    m = re.fullmatch(r"\s*row\d+\.(\w+)\s*", expr)
    return m.group(1) if m else None


def translate_expression(expr: str, output_name: str) -> tuple[str, str]:
    """Translate one Talend output/var expression.

    Returns a tuple ``(pyspark_expr, note)`` where *pyspark_expr* is column
    source code and *note* is a short human-readable description of how the
    translation was performed.
    """
    e = expr.strip()

    # --- direct pass-through:  row1.col -------------------------------------
    src = _src_col(e)
    if src is not None:
        return f'F.col("{src}")', "Direct column pass-through."

    # --- StringHandling.TRIM(row1.col) --------------------------------------
    m = re.fullmatch(r"StringHandling\.TRIM\(\s*row\d+\.(\w+)\s*\)", e)
    if m:
        return f'F.trim(F.col("{m.group(1)}"))', "Whitespace trim via F.trim()."

    # --- StringHandling.UPCASE(row1.col) ------------------------------------
    m = re.fullmatch(r"StringHandling\.UPCASE\(\s*row\d+\.(\w+)\s*\)", e)
    if m:
        return f'F.upper(F.col("{m.group(1)}"))', "Upper-case via F.upper()."

    # --- StringHandling.DOWNCASE(row1.col) ----------------------------------
    m = re.fullmatch(r"StringHandling\.DOWNCASE\(\s*row\d+\.(\w+)\s*\)", e)
    if m:
        return f'F.lower(F.col("{m.group(1)}"))', "Lower-case via F.lower()."

    # --- Math.round(row1.col * 100.0) / 100.0  (round to N decimals) --------
    m = re.fullmatch(
        r"Math\.round\(\s*row\d+\.(\w+)\s*\*\s*(\d+)(?:\.0)?\s*\)\s*/\s*\2(?:\.0)?", e
    )
    if m:
        scale = len(m.group(2)) - 1  # 100 -> 2, 1000 -> 3
        return (
            f'F.round(F.col("{m.group(1)}"), {scale})',
            f"Round to {scale} decimal place(s) via F.round().",
        )

    # --- TalendDate.getCurrentDate() ----------------------------------------
    if re.fullmatch(r"TalendDate\.getCurrentDate\(\s*\)", e):
        return "F.current_date()", "Current load date via F.current_date()."

    # --- string literal ------------------------------------------------------
    if re.fullmatch(r'".*"', e):
        return f"F.lit({e})", "Constant string literal."

    # --- numeric literal -----------------------------------------------------
    if re.fullmatch(r"-?\d+(\.\d+)?", e):
        return f"F.lit({e})", "Constant numeric literal."

    # --- fallback: not recognised -------------------------------------------
    safe = e.replace('"', "'")
    return (
        f'F.col("{output_name}")  # TODO review: original Talend expr was: {safe}',
        "UNRECOGNISED Talend expression - left for human review.",
    )


def translate_filter(expr: str) -> tuple[str, str]:
    """Translate a tMap output-filter expression to a PySpark boolean column.

    Handles simple comparisons and &&/|| combinations of `rowN.col <op> value`.
    """
    e = expr.strip()

    def one(cond: str) -> str | None:
        m = re.fullmatch(r"\s*row\d+\.(\w+)\s*(>=|<=|==|!=|>|<)\s*(.+?)\s*", cond)
        if not m:
            return None
        col, op, val = m.group(1), m.group(2), m.group(3).strip()
        pyop = {"==": "==", "!=": "!="}.get(op, op)
        return f'(F.col("{col}") {pyop} {val})'

    # split on Talend && / ||
    if "&&" in e or "||" in e:
        parts = re.split(r"\s*(&&|\|\|)\s*", e)
        out = []
        ok = True
        for tok in parts:
            if tok == "&&":
                out.append(" & ")
            elif tok == "||":
                out.append(" | ")
            else:
                t = one(tok)
                if t is None:
                    ok = False
                    break
                out.append(t)
        if ok:
            return "".join(out), "Compound filter translated to PySpark boolean column."

    single = one(e)
    if single is not None:
        return single, "Comparison filter translated to PySpark boolean column."

    safe = e.replace('"', "'")
    return (
        f'F.expr("true")  # TODO review original filter: {safe}',
        "UNRECOGNISED filter - left for human review.",
    )
