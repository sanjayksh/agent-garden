"""Small filesystem helpers shared across the package."""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any


def ensure_dir(path: str | os.PathLike[str]) -> Path:
    """Create a directory (and parents) if needed and return it as a Path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_text(path: str | os.PathLike[str], text: str) -> Path:
    """Write UTF-8 text, creating parent folders as needed."""
    p = Path(path)
    ensure_dir(p.parent)
    p.write_text(text, encoding="utf-8")
    return p


def read_text(path: str | os.PathLike[str]) -> str:
    return Path(path).read_text(encoding="utf-8")


def write_json(path: str | os.PathLike[str], data: Any) -> Path:
    return write_text(path, json.dumps(data, indent=2, ensure_ascii=False))


def read_json(path: str | os.PathLike[str]) -> Any:
    return json.loads(read_text(path))


def clean_dir(path: str | os.PathLike[str]) -> Path:
    """Empty a directory (remove and recreate). Safe if it does not exist."""
    p = Path(path)
    if p.exists():
        shutil.rmtree(p)
    return ensure_dir(p)


def find_one(folder: str | os.PathLike[str], suffix: str) -> Path:
    """Return the single file in *folder* ending with *suffix*.

    Raises FileNotFoundError if none, ValueError if more than one.
    """
    folder = Path(folder)
    matches = sorted(folder.glob(f"*{suffix}"))
    if not matches:
        raise FileNotFoundError(f"No '*{suffix}' file found in {folder}")
    if len(matches) > 1:
        raise ValueError(
            f"Expected exactly one '*{suffix}' file in {folder}, found {len(matches)}: "
            + ", ".join(m.name for m in matches)
        )
    return matches[0]
