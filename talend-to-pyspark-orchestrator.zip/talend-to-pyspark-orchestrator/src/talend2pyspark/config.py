"""Configuration loading.

Resolution order (lowest to highest precedence):
    1. config/settings.yaml
    2. environment variables (including those loaded from a .env file)
    3. explicit keyword overrides (e.g. from CLI flags)
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .utils.logging import get_logger

log = get_logger("t2p.config")


# --------------------------------------------------------------------------
# .env loading (no hard dependency on python-dotenv)
# --------------------------------------------------------------------------
def load_dotenv(path: str | os.PathLike[str]) -> None:
    """Minimal .env loader: KEY=VALUE lines, '#' comments, no export keyword.

    Values already present in the real environment are NOT overwritten.
    """
    p = Path(path)
    if not p.exists():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


@dataclass
class LLMConfig:
    provider: str = "offline"
    temperature: float = 0.1
    max_tokens: int = 4096
    github_base_url: str = "https://models.github.ai/inference"
    github_model: str = "openai/gpt-4o"
    github_token: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o"
    openai_api_key: str = ""


@dataclass
class Config:
    project_root: Path
    # folders
    talend_input: Path
    workspace: Path
    extracted_logic_dir: Path
    pyspark_code_dir: Path
    mapping_dir: Path
    validation_dir: Path
    # generated-pipeline IO
    input_dir: Path
    output_dir: Path
    delete_source_after_move: bool
    # behaviour
    execute_validation: bool
    fail_fast: bool
    # llm
    llm: LLMConfig = field(default_factory=LLMConfig)

    # -- convenience ------------------------------------------------------
    @property
    def job_name(self) -> str:
        """Talend job name, derived from the input folder."""
        return self.talend_input.name


def _resolve(root: Path, value: str) -> Path:
    """Resolve a possibly-relative path against the project root."""
    p = Path(value)
    return p if p.is_absolute() else (root / p)


def load_config(
    project_root: str | os.PathLike[str] | None = None,
    settings_file: str | os.PathLike[str] | None = None,
    **overrides: Any,
) -> Config:
    """Build a :class:`Config` from settings.yaml + env + overrides."""
    root = Path(project_root).resolve() if project_root else Path.cwd().resolve()

    # Load .env (if any) before reading environment-driven settings.
    load_dotenv(root / ".env")

    settings_path = Path(settings_file) if settings_file else root / "config" / "settings.yaml"
    data: dict[str, Any] = {}
    if settings_path.exists():
        data = yaml.safe_load(settings_path.read_text(encoding="utf-8")) or {}
    else:
        log.warning("settings file not found at %s; using built-in defaults", settings_path)

    paths = data.get("paths", {})
    pio = data.get("pipeline_io", {})
    llm_d = data.get("llm", {})
    rund = data.get("run", {})
    gh = (llm_d.get("github") or {})
    oa = (llm_d.get("openai") or {})

    # --- LLM (env overrides yaml) ---------------------------------------
    llm = LLMConfig(
        provider=os.environ.get("T2P_LLM_PROVIDER", llm_d.get("provider", "offline")),
        temperature=float(os.environ.get("T2P_TEMPERATURE", llm_d.get("temperature", 0.1))),
        max_tokens=int(os.environ.get("T2P_MAX_TOKENS", llm_d.get("max_tokens", 4096))),
        github_base_url=os.environ.get("T2P_GITHUB_BASE_URL", gh.get("base_url", "https://models.github.ai/inference")),
        github_model=os.environ.get("T2P_GITHUB_MODEL", gh.get("model", "openai/gpt-4o")),
        github_token=os.environ.get("GITHUB_TOKEN", ""),
        openai_base_url=os.environ.get("T2P_OPENAI_BASE_URL", oa.get("base_url", "https://api.openai.com/v1")),
        openai_model=os.environ.get("T2P_OPENAI_MODEL", oa.get("model", "gpt-4o")),
        openai_api_key=os.environ.get("OPENAI_API_KEY", ""),
    )

    cfg = Config(
        project_root=root,
        talend_input=_resolve(root, paths.get("talend_input", "sample_talend_job/MoveCsvFile")),
        workspace=_resolve(root, paths.get("workspace", "workspace")),
        extracted_logic_dir=_resolve(root, paths.get("extracted_logic_dir", "workspace/01_extracted_logic")),
        pyspark_code_dir=_resolve(root, paths.get("pyspark_code_dir", "workspace/02_pyspark_code")),
        mapping_dir=_resolve(root, paths.get("mapping_dir", "workspace/03_mapping")),
        validation_dir=_resolve(root, paths.get("validation_dir", "workspace/04_validation")),
        input_dir=_resolve(root, pio.get("input_dir", "data/input")),
        output_dir=_resolve(root, pio.get("output_dir", "data/output")),
        delete_source_after_move=bool(pio.get("delete_source_after_move", True)),
        execute_validation=bool(rund.get("execute_validation", True)),
        fail_fast=bool(rund.get("fail_fast", True)),
        llm=llm,
    )

    # --- apply explicit overrides (CLI flags etc.) -----------------------
    for key, val in overrides.items():
        if val is None:
            continue
        if key in {"talend_input", "workspace", "input_dir", "output_dir"}:
            setattr(cfg, key, _resolve(root, str(val)))
        elif key == "provider":
            cfg.llm.provider = str(val)
        elif hasattr(cfg, key):
            setattr(cfg, key, val)

    # Keep workspace sub-folders consistent if the workspace root was moved.
    return cfg
