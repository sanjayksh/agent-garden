"""Word-document generation."""
