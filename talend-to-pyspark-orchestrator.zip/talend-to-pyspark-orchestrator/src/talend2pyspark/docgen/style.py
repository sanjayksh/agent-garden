"""Shared helpers for building styled Word documents with python-docx."""
from __future__ import annotations

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

NAVY = RGBColor(0x14, 0x37, 0x5E)
BLUE = RGBColor(0x1F, 0x4E, 0x79)
GREY = RGBColor(0x59, 0x59, 0x59)
GREEN = RGBColor(0x1F, 0x8A, 0x4C)
AMBER = RGBColor(0xB7, 0x79, 0x1F)


def new_document(title: str, subtitle: str = "") -> Document:
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    h = doc.add_heading(title, level=0)
    for run in h.runs:
        run.font.color.rgb = NAVY
    if subtitle:
        p = doc.add_paragraph()
        r = p.add_run(subtitle)
        r.italic = True
        r.font.color.rgb = GREY
        r.font.size = Pt(12)
    return doc


def heading(doc: Document, text: str, level: int = 1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = BLUE if level == 1 else NAVY
    return h


def para(doc: Document, text: str = "", bold: bool = False, italic: bool = False):
    p = doc.add_paragraph()
    if text:
        r = p.add_run(text)
        r.bold = bold
        r.italic = italic
    return p


def bullet(doc: Document, text: str):
    return doc.add_paragraph(text, style="List Bullet")


def code_block(doc: Document, code: str):
    """Render code in a single shaded, monospaced paragraph."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Pt(6)
    run = p.add_run(code)
    run.font.name = "Consolas"
    run.font.size = Pt(8.5)
    # shade the paragraph background light grey
    shd = p._p.get_or_add_pPr().makeelement(qn("w:shd"), {})
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), "F2F2F2")
    p._p.get_or_add_pPr().append(shd)
    return p


def _shade_cell(cell, fill: str) -> None:
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.makeelement(qn("w:shd"), {})
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def table(doc: Document, headers: list[str], rows: list[list[str]],
          widths: list[float] | None = None, status_col: int | None = None):
    """Add a styled table. *status_col* colours Converted/Review/PASS/FAIL cells."""
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Table Grid"

    hdr = t.rows[0].cells
    for i, htext in enumerate(headers):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        r = p.add_run(htext)
        r.bold = True
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        r.font.size = Pt(9.5)
        _shade_cell(hdr[i], "14375E")

    for row in rows:
        cells = t.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(val))
            r.font.size = Pt(9)
            if status_col is not None and i == status_col:
                sval = str(val).lower()
                if sval in ("converted", "pass", "passed"):
                    r.font.color.rgb = GREEN
                    r.bold = True
                elif sval in ("review", "fail", "failed"):
                    r.font.color.rgb = AMBER
                    r.bold = True
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Pt(w)
    return t
