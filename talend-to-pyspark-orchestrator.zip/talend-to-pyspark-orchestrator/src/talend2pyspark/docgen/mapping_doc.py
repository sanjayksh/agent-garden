"""Build the Agent-3 Talend -> PySpark mapping Word document."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..talend.mapping import coverage
from . import style


def build_mapping_doc(
    spec: dict[str, Any], rows: list[dict[str, Any]], out_path: str | Path
) -> Path:
    doc = style.new_document(
        f"Talend → PySpark Mapping — {spec.get('job_name', 'Talend Job')}",
        "Agent 3 · Logic Mapping & Traceability",
    )

    cov = coverage(rows)
    style.heading(doc, "1. Conversion Coverage", 1)
    style.para(
        doc,
        f"{cov['converted']} of {cov['total']} constructs were fully converted; "
        f"{cov['review']} flagged for human review.",
    )

    style.heading(doc, "2. Traceability Matrix", 1)
    style.para(
        doc,
        "Each row ties a Talend construct to the PySpark construct that "
        "implements it, with a conversion status.",
    )
    table_rows = [
        [r["id"], r["talend"], r["talend_detail"], r["pyspark"], r["intent"], r["status"]]
        for r in rows
    ]
    style.table(
        doc,
        ["BR", "Talend", "Talend detail", "PySpark", "Intent", "Status"],
        table_rows,
        status_col=5,
    )

    style.heading(doc, "3. Notes", 1)
    if cov["review"]:
        style.para(
            doc,
            "Rows marked 'Review' contain a Talend expression the converter did "
            "not fully recognise. The generated code preserves a TODO placeholder "
            "and a copy of the original expression so an engineer can complete it.",
        )
    else:
        style.para(
            doc,
            "All Talend constructs were translated to a recognised PySpark "
            "construct. No manual intervention is required for this job.",
        )

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    return out_path
