"""Build the Agent-1 business-logic Word document."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from . import style


def build_logic_doc(spec: dict[str, Any], narrative: str, out_path: str | Path) -> Path:
    doc = style.new_document(
        f"Business Logic Specification — {spec.get('job_name', 'Talend Job')}",
        "Agent 1 · Talend Parser & Logic Extractor",
    )

    style.heading(doc, "1. Overview", 1)
    if spec.get("purpose"):
        style.para(doc, spec["purpose"])
    for line in narrative.splitlines():
        if line.strip().startswith("-"):
            style.bullet(doc, line.strip().lstrip("- ").strip())
        elif line.strip():
            style.para(doc, line.strip())

    # Context
    if spec.get("context"):
        style.heading(doc, "2. Context Variables", 1)
        style.table(
            doc,
            ["Name", "Type", "Default value", "Comment"],
            [[c["name"], c["type"], c["value"], c.get("comment", "")] for c in spec["context"]],
        )

    # Source
    src = spec.get("source") or {}
    if src:
        style.heading(doc, "3. Source (Read)", 1)
        style.para(doc, f"Component: {src.get('component','')} ({src.get('type','')})", bold=True)
        style.bullet(doc, f"Path: {src.get('path_expr','')}")
        style.bullet(doc, f"Field separator: {src.get('field_separator',',')}")
        style.bullet(doc, f"Header row: {'yes' if src.get('header') else 'no'}")
        style.bullet(doc, f"Encoding: {src.get('encoding','UTF-8')}")
        style.para(doc, "Source schema:", bold=True)
        style.table(
            doc,
            ["Column", "Talend type", "Spark type", "Nullable", "Comment"],
            [
                [c["name"], c["talend_type"], c["spark_type"],
                 "yes" if c["nullable"] else "no", c.get("comment", "")]
                for c in src.get("schema", [])
            ],
        )

    # Business rules
    style.heading(doc, "4. Business Rules (in execution order)", 1)
    rows = []
    for t in spec.get("transformations", []):
        rows.append([t["id"], "Column rule", t["intent"], t["talend_expr"]])
    for f in spec.get("filters", []):
        rows.append([f["id"], "Row filter", f["intent"], f["talend_expr"]])
    for pa in spec.get("post_actions", []):
        rows.append([pa["id"], "Post-action", pa["intent"], pa.get("path_expr", "")])
    style.table(doc, ["BR", "Kind", "Intent", "Talend expression / detail"], rows)

    # Target
    tgt = spec.get("target") or {}
    if tgt:
        style.heading(doc, "5. Target (Write)", 1)
        style.para(doc, f"Component: {tgt.get('component','')} ({tgt.get('type','')})", bold=True)
        style.bullet(doc, f"Path: {tgt.get('path_expr','')}")
        style.bullet(doc, f"Field separator: {tgt.get('field_separator',',')}")
        style.bullet(doc, f"Include header: {'yes' if tgt.get('include_header') else 'no'}")
        style.bullet(doc, f"Append: {'yes' if tgt.get('append') else 'no'}")

    # Flow
    if spec.get("connections"):
        style.heading(doc, "6. Data Flow & Triggers", 1)
        style.table(
            doc,
            ["From", "To", "Type", "Label"],
            [[c["from"], c["to"], c["type"], c["label"]] for c in spec["connections"]],
        )

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    return out_path
