"""Build the Agent-4 validation-report Word document."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from . import style


def build_validation_doc(
    spec: dict[str, Any], result: dict[str, Any], summary: str, out_path: str | Path
) -> Path:
    doc = style.new_document(
        f"Validation Report — {spec.get('job_name', 'Talend Job')}",
        "Agent 4 · Validation & Test",
    )

    verdict = "PASSED" if result.get("passed") else "FAILED"
    style.heading(doc, "1. Verdict", 1)
    p = style.para(doc)
    r = p.add_run(verdict)
    r.bold = True
    r.font.color.rgb = style.GREEN if result.get("passed") else style.AMBER

    style.heading(doc, "2. Summary", 1)
    for line in summary.splitlines():
        if line.strip().startswith(("-", "[")):
            style.bullet(doc, line.strip().lstrip("- ").strip())
        elif line.strip():
            style.para(doc, line.strip())

    style.heading(doc, "3. Checks", 1)
    rows = [
        [c["name"], "PASS" if c["passed"] else "FAIL", c["detail"]]
        for c in result.get("checks", [])
    ]
    if rows:
        style.table(doc, ["Check", "Result", "Detail"], rows, status_col=1)
    else:
        style.para(doc, "No automated checks were recorded.")

    if result.get("executed"):
        style.heading(doc, "4. Execution Evidence", 1)
        style.bullet(doc, f"Input rows read: {result.get('input_rows', '?')}")
        style.bullet(doc, f"Output rows written: {result.get('output_rows', '?')}")
        style.bullet(doc, f"Output file: {result.get('output_path', '?')}")
        if result.get("sample_output"):
            style.para(doc, "Sample of the generated output:", bold=True)
            style.code_block(doc, result["sample_output"])

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    return out_path
