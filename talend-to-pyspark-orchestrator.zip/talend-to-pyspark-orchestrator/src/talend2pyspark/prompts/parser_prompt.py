"""Prompts for Agent 1 - the Talend Parser / Logic Extractor."""
from __future__ import annotations

import json
from typing import Any

SYSTEM = (
    "You are a senior data engineer who specialises in reverse-engineering "
    "Talend Standard Jobs. You read Talend job exports (.properties and .item "
    "XML) and explain, precisely and completely, the business logic they "
    "implement. You never invent logic that is not present in the job, and you "
    "always preserve the exact order in which the job applies its rules."
)


def user(spec: dict[str, Any], raw_item_xml: str) -> str:
    """Build the Agent-1 user prompt.

    The orchestrator has already parsed the job into the structured *spec*; the
    model is asked to turn that into a clear, human-readable narrative for the
    business-logic document. The raw XML is included for grounding.
    """
    return f"""Below is (A) a structured extraction of a Talend job that an XML \
parser produced, and (B) the raw .item XML for grounding.

Write a clear, well-structured natural-language explanation of the job's \
business logic, suitable for a technical specification document. Cover, in \
this order:
  1. The overall purpose and the read -> transform -> write -> move shape.
  2. The source file read (path, separators, header, and the column schema).
  3. Every business rule (BR-xx) in the exact order shown, explaining what each
     one does in plain language and citing the original Talend expression.
  4. Any row filters and what they keep or drop.
  5. The target write and any post-actions (e.g. deleting the source file).

Be faithful to the extraction; do not add rules that are not present. Return \
prose with short bullet points where helpful. Do NOT return code.

=== (A) STRUCTURED EXTRACTION (JSON) ===
{json.dumps(spec, indent=2)}

=== (B) RAW .item XML ===
{raw_item_xml}
"""
