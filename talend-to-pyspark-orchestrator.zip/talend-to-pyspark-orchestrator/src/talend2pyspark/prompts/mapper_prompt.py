"""Prompts for Agent 3 - the Logic Mapping / Traceability agent."""
from __future__ import annotations

import json
from typing import Any

SYSTEM = (
    "You are a meticulous migration QA engineer. You produce traceability "
    "matrices that prove a Talend job was faithfully converted to PySpark. For "
    "every Talend construct you identify the exact PySpark construct that "
    "implements it and flag anything that needs human review."
)


def user(spec: dict[str, Any], pyspark_code: str) -> str:
    return f"""Using the Talend job logic (JSON) and the generated PySpark code \
below, produce a traceability mapping.

Return ONLY a JSON array. Each element MUST be an object with EXACTLY these \
string fields:
  - "id"           : the business-rule id (e.g. "BR-01") or "—" for structural rows
  - "talend"       : the Talend construct (component or tMap entry)
  - "talend_detail": the original Talend expression / path
  - "pyspark"      : the PySpark construct that implements it
  - "intent"       : a short plain-language description of the rule
  - "status"       : "Converted" if fully translated, or "Review" if a human
                     must verify it

Include one row per business rule (BR-xx), plus rows for the source read, the \
target write, and any post-actions (e.g. source delete). Preserve order. Return \
no prose outside the JSON array.

=== TALEND JOB LOGIC (JSON) ===
{json.dumps(spec, indent=2)}

=== GENERATED PYSPARK CODE ===
{pyspark_code}
"""
