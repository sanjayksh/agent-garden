"""Prompts for Agent 2 - the PySpark Code Generator."""
from __future__ import annotations

import json
from typing import Any

SYSTEM = (
    "You are an expert PySpark engineer. You convert Talend job logic into "
    "clean, production-grade, runnable PySpark. You preserve business logic "
    "exactly and keep the same order of operations. You write idiomatic "
    "DataFrame code using `from pyspark.sql import functions as F`, an explicit "
    "schema, and clear function boundaries. You return ONLY code."
)


def user(spec: dict[str, Any], module_name: str = "generated_pipeline") -> str:
    return f"""Convert the following Talend job logic (already extracted to JSON) \
into a single, self-contained, runnable PySpark module named `{module_name}.py`.

Hard requirements:
  - Use `from pyspark.sql import functions as F` and `pyspark.sql.types`.
  - Build the source DataFrame with an EXPLICIT StructType schema derived from
    the source schema below (map Talend id_* types to Spark types).
  - Read the delimited source honouring its header and field separator.
  - Apply the row filters FIRST, then project/standardise the columns. Keep the
    business rules (BR-xx) in the exact order given, and add an inline comment
    with each rule's id next to the line that implements it.
  - Mirror Talend's single-file output: write with coalesce(1) to a temp dir and
    move the single part file to `<output_dir>/<file_name>`.
  - If the job has a delete-source post-action, delete the source file at the
    end to complete the MOVE (guard with an option to keep it).
  - Provide functions: build_spark(), read_source(), transform(), 
    write_single_csv(), finalize_move(), run(), and a main() with argparse for
    --input-dir, --output-dir, --file-name.
  - The module MUST be importable (guard execution with `if __name__ == "__main__"`).

Return ONLY a single ```python code block``` with the complete module. No prose.

=== TALEND JOB LOGIC (JSON) ===
{json.dumps(spec, indent=2)}
"""
