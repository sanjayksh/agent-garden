"""Prompts for Agent 4 - the Validation / Test agent."""
from __future__ import annotations

import json
from typing import Any

SYSTEM = (
    "You are a data-quality validation engineer. You review the result of "
    "executing a converted PySpark pipeline and write a concise, factual "
    "verdict on whether the conversion preserved the Talend job's behaviour."
)


def user(spec: dict[str, Any], result: dict[str, Any]) -> str:
    return f"""A converted PySpark pipeline was checked against the original \
Talend job logic. Below are (A) the Talend logic and (B) the structured \
validation result (row counts and per-rule checks).

Write a short, factual validation summary: state PASS or FAIL, summarise the \
row-count reconciliation, and list any checks that need attention. Keep it to a \
few sentences plus a short bulleted list. Do not invent results that are not in \
the data below.

=== (A) TALEND JOB LOGIC (JSON) ===
{json.dumps(spec, indent=2)}

=== (B) VALIDATION RESULT (JSON) ===
{json.dumps(result, indent=2)}
"""
