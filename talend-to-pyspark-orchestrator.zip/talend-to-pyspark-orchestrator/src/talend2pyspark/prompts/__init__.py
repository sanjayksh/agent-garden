"""Agent prompt templates (the instructions submitted to Copilot)."""
