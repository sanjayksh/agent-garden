#!/usr/bin/env python3
"""Convenience entry point so the app runs without installation:

    python run.py --provider offline

It puts ./src on sys.path and delegates to the CLI.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from talend2pyspark.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
