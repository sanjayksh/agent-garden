# Talend → PySpark — Multi-Agent (Copilot) Orchestrator

Convert a **Talend** data-processing job into a runnable **PySpark** pipeline
using **four chained Copilot agents**, and generate the migration documentation
automatically.

```
Agent 1 Parser    →  Agent 2 Generator  →  Agent 3 Mapper   →  Agent 4 Validator
.item/.properties    logic → PySpark        Talend↔PySpark      run + verify
→ logic.json+docx    → generated_pipeline   mapping proof docx  → report docx
```

Each agent does its work and **hands off to the next agent**; an **orchestrator**
selects the AI backend, builds the chain, and starts Agent 1.

---

## Quick start (no credentials)

```bash
cd talend-to-pyspark-orchestrator
pip install -r requirements.txt          # core deps
pip install pyspark                        # optional: enables live validation
python run.py --provider offline
```

Outputs land in `workspace/`:

- `01_extracted_logic/` — `logic.json` + **business-logic Word doc** (Agent 1)
- `02_pyspark_code/generated_pipeline.py` — **runnable PySpark** (Agent 2)
- `03_mapping/` — **Talend→PySpark mapping Word doc** (Agent 3)
- `04_validation/` — **validation report Word doc** (Agent 4)

Run the converted pipeline yourself:

```bash
python workspace/02_pyspark_code/generated_pipeline.py \
    --input-dir data/input --output-dir data/output --file-name customers.csv
```

---

## AI backends (pluggable)

| Provider | Use it for | Setup |
|---|---|---|
| **offline** *(default)* | works with zero credentials; tests & demos | none |
| **github_copilot** | GitHub Models / Copilot inference API | PAT with `models: read` |
| **openai** | OpenAI / Azure / Ollama / any OpenAI-compatible | API key + base URL |

```bash
cp .env.example .env       # set T2P_LLM_PROVIDER + credentials
python run.py --provider github_copilot
```

The agents are **backend-agnostic**: the same prompts drive a real model, while
the offline engine guarantees a valid result even with no network.

---

## VS Code

- `.vscode/tasks.json` — one-click **convert / run / test**
- `.vscode/launch.json` — debug the orchestrator and the generated pipeline
- `vscode-extension/` — optional companion that uses the **native Copilot
  `vscode.lm` API** to explain a Talend job in-editor and to launch the
  orchestrator

See **`docs/DEPLOYMENT.md`** for the full VS Code + Copilot walkthrough.

---

## The sample job

`sample_talend_job/MoveCsvFile/` is a Talend Standard Job that reads
`data/input/customers.csv`, standardises and filters it, writes it to
`data/output/`, and deletes the source (a **move**). It exercises trim,
upper-case, rounding, a current-date stamp, and a `balance >= 0` filter — so the
generated PySpark and the validation are meaningful end-to-end.

---

## Documentation

- **`docs/ARCHITECTURE.md`** — package structure, components, agent model, data
  flow, extension points *(deliverable #1)*.
- **`docs/DEPLOYMENT.md`** — install, run, every backend, VS Code, the generated
  pipeline, CI, troubleshooting *(deliverable #5)*.

---

## Tests

```bash
pip install pytest
PYTHONPATH=src pytest -q
```

---

## Requirements

Python 3.10+ · `python-docx`, `PyYAML`, `requests` (core) · `pyspark` + a JDK
(optional, for executing PySpark) · VS Code + GitHub Copilot (optional, for the
companion extension).

## License

MIT.
