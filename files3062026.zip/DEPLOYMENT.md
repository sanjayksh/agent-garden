# Deploying & Running talend2pyspark

This guide covers everything needed to install the application, run the
converter in VS Code, and execute the generated PySpark pipelines locally or on
a cluster.

---

## 1. Prerequisites

| Need | For | Notes |
|------|-----|-------|
| **Python 3.8+** | the converter itself | Uses only the standard library to convert |
| **VS Code** | recommended IDE | Plus the Microsoft *Python* extension |
| **PyYAML** (optional) | custom `config.yaml` | Falls back to defaults if absent |
| **Java 8/11/17/21** (a JDK/JRE) | running the *generated* PySpark | Spark requires a JVM |
| **pyspark** (optional) | running the *generated* PySpark | Match your cluster's Spark version |
| **JDBC driver JARs** (optional) | only if your job reads/writes a database | e.g. PostgreSQL, MySQL |

> The converter never needs Java, Spark, a database, or a network connection.
> Those are only relevant when you go on to **execute** the PySpark it writes.

---

## 2. Get the code

Unzip the delivered archive (or clone your copy):

```bash
unzip talend2pyspark.zip
cd talend2pyspark
```

---

## 3. Set up a Python environment

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows (PowerShell)
.venv\Scripts\Activate.ps1

# Optional dependencies (YAML config, running generated output, tests):
pip install -r requirements.txt
```

Install the package so the `talend2pyspark` command is available (optional):

```bash
pip install -e .
talend2pyspark --input ./sample_talend_jobs/MoveCsv_0.1
```

---

## 4. Open in VS Code

```bash
code .
```

1. Install the **Python** extension if prompted.
2. **Select interpreter:** `Ctrl/Cmd+Shift+P` → *Python: Select Interpreter* →
   choose the `.venv` you created.
3. Open a terminal (`Ctrl+\``) — it should show the activated venv.

Optional `launch.json` so **F5** runs a conversion:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Convert MoveCsv sample",
      "type": "debugpy",
      "request": "launch",
      "program": "${workspaceFolder}/run.py",
      "args": ["--input", "./sample_talend_jobs/MoveCsv_0.1"],
      "console": "integratedTerminal"
    }
  ]
}
```

---

## 5. Run a conversion

### Using the bundled samples

```bash
python run.py --input ./sample_talend_jobs/MoveCsv_0.1
python run.py --input ./sample_talend_jobs/CustomerOrders_0.1
```

### Using your own Talend job

1. In Talend Studio: right-click the job → **Build Job** / **Export Job**,
   choosing the *Autonomous Job* / source export so the job's `.item` file is
   included.
2. Unzip the export and drop the job folder into `workspace/input/`
   (or point `--input` straight at it).
3. Run:

   ```bash
   python run.py --input ./workspace/input/<YourJobFolder>
   ```

### What you get

| Artifact | Location | Produced by |
|----------|----------|-------------|
| Business-logic analysis (JSON) | `workspace/extracted/<job>.analysis.json` | Parser Agent |
| PySpark pipeline (Python) | `workspace/generated/<job>_pipeline.py` | Generator Agent |
| Mapping document (Markdown) | `workspace/mapping/<job>_mapping.md` | Mapper Agent |

The console prints these paths plus a summary line:
`{'components': N, 'converted': N, 'partial': N, 'not_converted': N}`.
**Always read the mapping document** — any partial/unconverted logic is listed
in its "items requiring manual attention" section.

---

## 6. Execute the generated PySpark pipeline

The generated script is a normal, standalone PySpark program.

### Locally with `python`

```bash
pip install pyspark            # one-time; needs a JDK on PATH

# run from a directory where the job's relative data paths resolve.
# for the bundled sample that means the sample folder itself:
cd sample_talend_jobs/MoveCsv_0.1
python ../../workspace/generated/MoveCsv_0.1_pipeline.py
```

Output is written by Spark as a *directory* of part-files, e.g.
`data/output/customers_out.csv/part-00000-*.csv`.

> **Paths:** the generator preserves the paths declared in the Talend job
> (e.g. `data/input/customers.csv`). Run from a working directory where those
> resolve, or edit the paths at the top of the generated script to absolute
> locations before running.

### On a cluster with `spark-submit`

```bash
spark-submit \
  --master yarn \
  --deploy-mode client \
  workspace/generated/<job>_pipeline.py
```

### If the job uses a database (`t{DB}Input` / `t{DB}Output`)

The generated script reads the password from the `DB_PASSWORD` environment
variable and contains a `JDBC_DRIVERS` map. Supply the matching driver JAR:

```bash
export DB_PASSWORD='your-secret'
spark-submit \
  --jars /path/to/postgresql-42.7.3.jar \
  workspace/generated/<job>_pipeline.py
```

Review the JDBC URL, table name and driver near the top of the generated file
before running in production.

### If the job reads/writes XML

XML support relies on the external `spark-xml` package (the script is flagged
where this applies):

```bash
spark-submit --packages com.databricks:spark-xml_2.12:0.18.0 \
  workspace/generated/<job>_pipeline.py
```

---

## 7. Configuration (optional)

Defaults live in `src/talend2pyspark/config_loader.py`. To override paths or
logging, copy `config/config.yaml`, edit it, and pass it (requires PyYAML):

```bash
python run.py --config config/config.yaml
```

CLI flags always win over the config file, which wins over the built-in
defaults.

---

## 8. Running the tests

```bash
pip install pytest
python -m pytest tests/ -q
```

The suite parses both sample jobs, runs the full agent chain into a temporary
workspace, and compiles the generated PySpark to confirm it is valid.

---

## 9. Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `No .item file found` | The `--input` folder isn't a Talend job export. Point it at the folder containing `<Job>.item`. |
| Summary shows `partial` or `not_converted` > 0 | Expected for logic outside the supported set or an advanced expression. Open the mapping document's "manual attention" section. |
| `JAVA_HOME is not set` / `java: command not found` when running output | Install a JDK and ensure `java` is on `PATH`. Only needed to *execute* PySpark, not to convert. |
| `ModuleNotFoundError: pyspark` when running output | `pip install pyspark`. Not required for conversion. |
| Generated CSV is a folder, not a single file | Normal Spark behaviour. The data is in `…/part-*.csv`. |
| Database read/write fails | Pass the JDBC driver via `--jars` and set `DB_PASSWORD`; check the URL/table in the generated script. |
| YAML config seems ignored | PyYAML not installed, or `--config` not passed. The tool silently uses defaults when PyYAML is absent. |

---

## 10. What "supported" means

Fully rule-based parsing & generation is provided for:
`tFileInputDelimited`, `t{DB}Input`, `tFileInputJSON`, `tFileInputXML`,
`tMap`, `tFilterRow`, `tAggregateRow`, `tJoin`, `tSortRow`, `tConvertType`,
`tFileOutputDelimited`, `t{DB}Output`, `tFileOutputJSON`, `tFileOutputXML`.

Anything else is preserved as a clearly-commented placeholder in the generated
script and listed in the mapping document, so a developer can finish it by hand
— the converter never silently drops logic.
