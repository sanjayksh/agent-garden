# talend2pyspark — Technical Architecture

A rule-based, multi-agent application that converts an exported Talend data
pipeline into an equivalent PySpark pipeline, plus a Markdown document mapping
every piece of Talend logic to its PySpark counterpart.

> **No LLM at runtime.** Every parsing and code-generation rule in this
> application was authored ahead of time (during development) and baked into
> the source as deterministic Python: dispatch tables, regular expressions and
> explicit emitters. Running the tool requires only Python; it never calls an
> external model. The "intelligence" lives in the rules under
> `parsers/` and `generators/`.

---

## 1. Design goals

| Goal | How it is met |
|------|---------------|
| Convert any Talend job containing filtering, aggregation/grouping, cleansing/quality, and join/lookup logic | A component-parser per Talend type produces a tool-agnostic Intermediate Representation (IR); a generator turns the IR into PySpark |
| Four cooperating agents | Orchestrator (Agent 4) drives Parser (1) → Generator (2) → Mapper (3) |
| Deterministic, no runtime LLM | All rules are hand-written `dict` dispatch + regex in `component_parsers.py`, `type_mapping.py`, `pyspark_generator.py` |
| Working & deployable in VS Code | Pure-stdlib core, single `run.py` entry point, `pip install -e .` console script, sample jobs, pytest suite |
| Nothing silently dropped | Anything not fully understood is flagged on the component and surfaced in the mapping document's "manual attention" section |

---

## 2. Agent model

The application is an **orchestrated chain of four agents**. Agents do not call
each other directly across the network; the Orchestrator owns the sequence and
a shared in-memory `AgentContext`, while each agent also leaves a durable
on-disk artifact so the stages are independently inspectable and restartable.

```
                          ┌──────────────────────────────────────┐
                          │   Orchestrator Agent  (Agent 4)       │
                          │   orchestrator/orchestrator.py        │
                          │   - prepares workspace folders        │
                          │   - runs the chain, aggregates report │
                          └───────────────┬──────────────────────┘
                                          │ shared AgentContext
        ┌─────────────────────────────────┼─────────────────────────────────┐
        ▼                                 ▼                                 ▼
┌────────────────┐   analysis.json ┌────────────────┐  _pipeline.py ┌────────────────┐
│ Parser Agent   │ ───────────────▶│ Generator Agent│ ─────────────▶│ Mapper Agent   │
│ (Agent 1)      │                 │ (Agent 2)      │               │ (Agent 3)      │
│ Talend → IR    │                 │ IR → PySpark   │               │ → mapping.md   │
└──────┬─────────┘                 └──────┬─────────┘               └──────┬─────────┘
       │                                  │                                │
   workspace/extracted/             workspace/generated/             workspace/mapping/
   <job>.analysis.json              <job>_pipeline.py                <job>_mapping.md
```

### Agent responsibilities

- **Parser Agent (Agent 1)** — `agents/parser_agent.py`
  Locates the job's `.item` file in the exported folder, parses the XML
  (namespaces stripped, stdlib `xml.etree.ElementTree`), classifies each Talend
  component, and extracts its business logic into the IR. Writes
  `workspace/extracted/<job>.analysis.json`.

- **Generator Agent (Agent 2)** — `agents/generator_agent.py`
  Reads the IR (from context or JSON), walks the components in topological
  execution order, and emits a runnable PySpark script. Records a per-component
  translation log (CONVERTED / PARTIAL / NOT CONVERTED). Writes
  `workspace/generated/<job>_pipeline.py`, then hands control back so the
  Mapper can run.

- **Mapper Agent (Agent 3)** — `agents/mapper_agent.py`
  Turns the IR + translation log into a human-readable Markdown report: a
  summary, the execution order, a component mapping table (Talend → PySpark with
  ✅ / ⚠️ / ❌ status), detailed per-logic tables (filters, aggregations, joins,
  mappings, sorts), and an explicit "items requiring manual attention" section
  so nothing unconverted is hidden. Writes
  `workspace/mapping/<job>_mapping.md`.

- **Orchestrator Agent (Agent 4)** — `orchestrator/orchestrator.py`
  Prepares/cleans the workspace, constructs the shared `AgentContext`, runs the
  three agents in order, catches and reports failures, and produces an
  `OrchestratorReport` (paths + summary counts).

---

## 3. Package structure

```
talend2pyspark/
├── run.py                         # CLI entry point (no install required)
├── setup.py                       # pip-installable; exposes `talend2pyspark` command
├── requirements.txt               # core = stdlib; PyYAML & pyspark are optional
├── README.md                      # quick start
├── ARCHITECTURE.md                # this document
├── DEPLOYMENT.md                  # full deploy & run guide
│
├── config/
│   └── config.yaml                # optional; built-in defaults used otherwise
│
├── src/talend2pyspark/
│   ├── cli.py                     # entry point used by the installed console script
│   ├── config_loader.py           # defaults + optional YAML merge
│   │
│   ├── models/                    # the Intermediate Representation (IR)
│   │   ├── schema.py              # dataclasses: Component, FilterCondition, …, PipelineIR
│   │   └── deserialize.py         # rebuild IR from analysis.json
│   │
│   ├── parsers/                   # ── Agent 1 capability (Talend → IR) ──
│   │   ├── talend_job_loader.py   # locate & parse the .item XML into raw nodes
│   │   ├── component_parsers.py   # one parser per Talend component + dispatch table
│   │   └── graph.py               # topological ordering of the component graph
│   │
│   ├── generators/                # ── Agent 2 capability (IR → PySpark) ──
│   │   ├── type_mapping.py        # Talend types/ops/exprs → Spark equivalents
│   │   └── pyspark_generator.py   # emits the runnable PySpark script
│   │
│   ├── agents/
│   │   ├── base_agent.py          # AgentContext, AgentResult, BaseAgent
│   │   ├── parser_agent.py        # Agent 1
│   │   ├── generator_agent.py     # Agent 2
│   │   └── mapper_agent.py        # Agent 3
│   │
│   ├── orchestrator/
│   │   └── orchestrator.py        # Agent 4 + OrchestratorReport
│   │
│   └── utils/
│       ├── logging_utils.py
│       └── file_utils.py
│
├── sample_talend_jobs/
│   ├── MoveCsv_0.1/               # required simple sample: CSV in → CSV out
│   └── CustomerOrders_0.1/        # richer sample: filter→lookup→aggregate→sort
│
├── tests/
│   ├── test_parser.py
│   └── test_generator.py
│
└── workspace/                     # runtime I/O (created/cleaned per run)
    ├── input/                     # default location to drop a Talend job
    ├── extracted/                 # Agent 1 output
    ├── generated/                 # Agent 2 output
    └── mapping/                   # Agent 3 output
```

---

## 4. The Intermediate Representation (IR)

The IR is the contract between agents and the reason the design is
tool-agnostic: parsers only ever populate the IR, and the generator only ever
reads it. Adding a new source tool or a new target engine touches just one side.

Key dataclasses (`models/schema.py`):

- `PipelineIR` — `job_name`, `components`, `connections`, `execution_order`, `metadata`
- `Component` — `unique_name`, `talend_component`, `kind` (`ComponentKind`), `schema`, and logic slots: `filters`, `aggregations`, `group_by`, `mappings`, `joins`, `sort_keys`, plus `parsed` / `unsupported_notes`
- `ComponentKind` — `SOURCE, SINK, TRANSFORM, FILTER, AGGREGATE, JOIN, SORT, TYPE_CAST, MAP, UNKNOWN`
- Supporting records: `FilterCondition`, `AggregateOperation`, `ColumnMapping`, `JoinSpec`, `Column`, `Connection`

The IR serialises to `analysis.json` (Agent 1's deliverable) and is rebuilt by
`deserialize.py` when the Generator runs from the file rather than memory.

---

## 5. Data & control flow

1. **Input** — an exported Talend job folder is placed at `workspace/input`
   (or passed with `--input`). The parseable artifact is the job's `.item`
   XML file.
2. **Agent 1** parses the `.item` into raw nodes/connections, classifies each
   node, extracts logic into the IR, and writes `analysis.json`.
3. **Agent 2** loads the IR, computes topological order, and emits
   `<job>_pipeline.py` (a self-contained PySpark script), recording a
   translation status per component.
4. **Agent 3** writes `<job>_mapping.md` from the IR + translation log.
5. **Agent 4** returns an `OrchestratorReport` and the CLI prints the artifact
   paths and the summary counts (`components / converted / partial / not_converted`).

---

## 6. How the Talend components map to PySpark

| Talend component(s) | IR kind | PySpark output |
|---|---|---|
| `tFileInputDelimited` | SOURCE | `spark.read…csv(...)` with an explicit `StructType` |
| `tFileInputJSON` / `tFileInputXML` | SOURCE | `spark.read.json(...)` / XML reader (flagged for the `spark-xml` package) |
| `t{DB}Input` (regex‑matched) | SOURCE | `spark.read.format("jdbc")…load()` |
| `tFilterRow` | FILTER | `df.filter("<conditions>")` (cleansing/quality) |
| `tAggregateRow` | AGGREGATE | `df.groupBy(...).agg(F…)` (aggregation/grouping) |
| `tJoin` / `tMap` lookups | JOIN / MAP | `df.join(other, on=…, how=…)` (+ `.select` for tMap expressions) |
| `tSortRow` | SORT | `df.orderBy(F.col(...).asc()/desc())` |
| `tConvertType` | TYPE_CAST | `df.withColumn(c, F.col(c).cast(...))` |
| `tFileOutputDelimited` | SINK | `df.coalesce(1).write…csv(...)` |
| `tFileOutputJSON` / `tFileOutputXML` | SINK | `.write.json(...)` / XML writer |
| `t{DB}Output` (regex‑matched) | SINK | `.write.format("jdbc")…save()` |

Expression translation (`type_mapping.py`) rewrites common Talend/Java idioms
into Spark SQL (e.g. string concatenation, `StringHandling.UPCASE`,
`relationalLogic`), and **returns a "fully understood" flag**. When a rule is
only partial, the component is marked PARTIAL and the original expression is
preserved in the mapping document for human review.

---

## 7. The "no LLM at runtime" guarantee

- The parsing rules are explicit Python: an exact-match dispatch table
  (`_EXACT_PARSERS`) plus two regexes for the `t{DB}Input` / `t{DB}Output`
  families in `component_parsers.py`.
- The type/operator/expression rules are plain lookup tables and regex
  rewrites in `type_mapping.py`.
- The code emitters in `pyspark_generator.py` are ordinary string-building
  functions keyed by `ComponentKind`.
- The core import set is the standard library only; `import`-ing the package
  pulls in nothing that reaches a network or a model.

This is what the task means by "built with your inbuilt LLM during initial
building": the knowledge was encoded into deterministic rules at authoring
time, so conversion at runtime is fast, repeatable, offline, and auditable.

---

## 8. Extension points

- **New Talend component** → add a parser function and register it in
  `_EXACT_PARSERS` (or extend a regex family). Populate the right IR slot.
- **New expression idiom** → add a rule to `translate_expression` in
  `type_mapping.py`.
- **New target engine** (e.g. Snowpark, plain pandas) → add a sibling of
  `pyspark_generator.py` that consumes the same IR; the parser layer is
  untouched.
- **New report format** → add an emitter alongside the Mapper agent.

---

## 9. Error handling & observability

- Each agent returns an `AgentResult` (ok / message / artifacts); the
  Orchestrator stops the chain on the first failure and reports it.
- Unknown components do not crash the run: they are recorded as `UNKNOWN`,
  emitted as a clearly commented placeholder in the PySpark script, and listed
  under "items requiring manual attention" in the mapping document.
- Logging is centralised in `utils/logging_utils.py`; verbosity is set with
  `--log-level`.
